import uuid
from collections import defaultdict
from datetime import timedelta
from decimal import Decimal

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.accounting import service as acc
from app.accounting.models import Account, JournalEntry, JournalLine
from app.billing.models import RECEIVABLE, ClientBill
from app.billing.routes import retention_held, revised_contract_value
from app.dailylogs import service as log_service
from app.dailylogs.models import DailyLog, LogStatus
from app.dashboards import service as ds
from app.dashboards.service import LIVE, S, ZERO
from app.finance.models import ApprovalState, Expense, InvoiceException, InvoiceStatus, Payment, SupplierInvoice
from app.inventory.models import InventoryItem, MovementType as MT, StockBalance, StockTransaction, Warehouse
from app.labour.models import AttendanceSheet
from app.models import User
from app.procurement.models import (POLine, POStatus, PurchaseOrder, PurchaseRequisition, ReqStatus, RequisitionLine,
                                    Supplier, SupplierQuote)
from app.projects.models import Project, ProjectStatus
from app.reports import service as rs
from app.reports.routes import bucket, BUCKETS
from app.timeutil import day_bounds_utc, local_today

OPEN_INV = (InvoiceStatus.POSTED, InvoiceStatus.PARTIALLY_PAID)
OPEN_PO = (POStatus.APPROVED, POStatus.PARTIALLY_RECEIVED)


def _cash_balance(db, org, today) -> tuple[Decimal, list[dict]]:
    accounts = acc.ensure_accounts(db, org)
    rows = [{"code": a.code, "name": a.name, "balance": S(acc.balance(db, org, a.id, as_of=today))}
            for a in sorted(accounts.values(), key=lambda a: a.code) if a.is_cash]
    return sum((Decimal(r["balance"]) for r in rows), ZERO), rows


def _payables(db, org, today):
    total = overdue = ZERO
    for i in db.scalars(select(SupplierInvoice).where(SupplierInvoice.organization_id == org, SupplierInvoice.status.in_(OPEN_INV))):
        out = i.total_amount - i.paid_amount
        total += out
        overdue += out if i.due_date < today else ZERO
    return total, overdue


def _receivables(db, org, today):
    total = overdue = ZERO
    for b in db.scalars(select(ClientBill).where(ClientBill.organization_id == org, ClientBill.status.in_(RECEIVABLE))):
        out = b.net_payable - b.received_amount
        total += out
        overdue += out if b.due_date < today else ZERO
    return total, overdue


# ------------------------------------------------------------------ CEO
def ceo(db: Session, user: User) -> dict:
    org, today = user.organization_id, local_today()
    everything = list(db.scalars(select(Project).where(Project.organization_id == org, Project.deleted_at.is_(None))))
    by_status = {s.value: 0 for s in ProjectStatus}
    for p in everything:
        by_status[p.status.value] += 1
    contracted = [p for p in everything if p.status in (*LIVE, ProjectStatus.COMPLETED)]
    sums = ds.budget_sums(db, org, [p.id for p in contracted])
    revised = {p.id: revised_contract_value(db, org, p) for p in contracted}
    cash, cash_accounts = _cash_balance(db, org, today)
    receivable, recv_overdue = _receivables(db, org, today)
    payable, pay_overdue = _payables(db, org, today)
    planned_margin = sum((revised[p.id] - sums[p.id][0] for p in contracted if p.id in sums), ZERO)
    profit_to_date = sum((rs.project_figures(db, org, pid)["gross_profit"] for pid in rs.active_project_ids(db, org)), ZERO)
    unalloc = rs.unallocated_costs(db, org)
    cards = ds.project_cards(db, user, [p for p in everything if p.status in LIVE][:50], money=True)
    attention = sorted((c for c in cards if c["risk"] != "OK"),
                       key=lambda c: (-ds.SEVERITY[c["risk"]], -Decimal((c["budget"] or {}).get("cost_minus_progress_points", "0"))))[:5]
    return {
        "role": "CEO", "as_of": S(today),
        "projects": {"total": len(everything), "active": by_status["ACTIVE"], "completed": by_status["COMPLETED"],
                     "by_status": by_status},
        "portfolio": {"contract_value": S(sum(revised.values(), ZERO)),
                      "total_budget": S(sum((v[0] for v in sums.values()), ZERO)),
                      "committed_cost": S(sum((v[1] for v in sums.values()), ZERO)),
                      "actual_cost": S(sum((v[2] for v in sums.values()), ZERO)),
                      "paid_cost": S(sum((v[3] for v in sums.values()), ZERO)),
                      "cost_variance": S(sum((v[0] - v[2] for v in sums.values()), ZERO)),
                      "planned_margin": S(planned_margin), "profit_to_date": S(profit_to_date - unalloc),
                      "profit_to_date_basis": "net revenue - direct cost - unallocated costs, from the journal"},
        "money": {"cash": S(cash), "cash_accounts": cash_accounts, "receivables": S(receivable),
                  "receivables_overdue": S(recv_overdue), "payables": S(payable), "payables_overdue": S(pay_overdue),
                  "net_position": S(cash + receivable - payable)},
        "approvals": ds.pending_approvals(db, user, None),
        "attention": [{"project": c["code"], "risk": c["risk"], "reasons": [f["message"] for f in c["flags"][:3]],
                       "flags": c["flags"][:3]} for c in attention],
        "project_table": cards,
    }


# ------------------------------------------------------------------ project manager
def manager(db: Session, user: User) -> dict:
    org, today = user.organization_id, local_today()
    projects = ds.scoped_projects(db, user, "manager")
    ids = [p.id for p in projects]
    cards = ds.project_cards(db, user, projects, money=True)
    window = [today - timedelta(days=i) for i in range(6, -1, -1)]
    submitted = defaultdict(set)
    for pid, d in db.execute(select(DailyLog.project_id, DailyLog.log_date).where(
            DailyLog.organization_id == org, DailyLog.project_id.in_(ids or [None]), DailyLog.status == LogStatus.SUBMITTED,
            DailyLog.log_date >= window[0])):
        submitted[pid].add(d)
    sheets = {pid: st for pid, st in db.execute(select(AttendanceSheet.project_id, AttendanceSheet.status).where(
        AttendanceSheet.organization_id == org, AttendanceSheet.project_id.in_(ids or [None]), AttendanceSheet.work_date == today))}
    open_req = dict(db.execute(select(PurchaseRequisition.project_id, func.count()).where(
        PurchaseRequisition.organization_id == org, PurchaseRequisition.project_id.in_(ids or [None]),
        PurchaseRequisition.status.in_([ReqStatus.SUBMITTED, ReqStatus.APPROVED])).group_by(PurchaseRequisition.project_id)).all())
    for c in cards:
        pid = uuid.UUID(c["id"])
        c["missing_daily_reports_last_7_days"] = ([S(d) for d in window if d not in submitted[pid]]
                                                  if c["status"] == "ACTIVE" else [])
        c["attendance_today"] = sheets[pid].value if pid in sheets else "NOT_STARTED"
        c["open_requisitions"] = open_req.get(pid, 0)
    return {"role": "PROJECT_MANAGER", "as_of": S(today), "scope": "all projects" if "dashboard.ceo" in ds.perms(user) else "assigned projects",
            "projects": cards, "approvals": ds.pending_approvals(db, user, ids),
            "totals": {"projects": len(cards), "high_risk": sum(1 for c in cards if c["risk"] == "HIGH"),
                       "open_requisitions": sum(open_req.values())}}


# ------------------------------------------------------------------ site engineer (no financial data)
def engineer(db: Session, user: User) -> dict:
    org, today = user.organization_id, local_today()
    projects = ds.scoped_projects(db, user, "engineer")
    ids = [p.id for p in projects]
    logs = ds.last_report_dates(db, org, ids)
    out = []
    for p in projects:
        prog = log_service.project_progress(db, org, p.id)
        today_log = db.scalar(select(DailyLog.status).where(DailyLog.organization_id == org, DailyLog.project_id == p.id,
                                                            DailyLog.log_date == today))
        sheet = db.scalar(select(AttendanceSheet.status).where(AttendanceSheet.organization_id == org,
                                                              AttendanceSheet.project_id == p.id, AttendanceSheet.work_date == today))
        low = ds.low_stock_items(db, org, project_id=p.id)
        flags = ds.project_flags(p, today, money=False, budget=None, progress=Decimal(prog["overall_percent"]),
                                 last_log=logs.get(p.id), low_stock=len(low), receivable_overdue=ZERO)
        out.append({
            "id": S(p.id), "code": p.code, "name": p.name, "status": p.status.value,
            "planned_end_date": S(p.planned_end_date) if p.planned_end_date else None,
            "today": {"daily_report": today_log.value if today_log else "NOT_STARTED",
                      "attendance": sheet.value if sheet else "NOT_STARTED",
                      "workforce": log_service.workforce(db, org, p.id, today), "materials": log_service.materials(db, org, p.id, today)},
            "progress": {"overall_percent": prog["overall_percent"],
                         "items": [{k: v for k, v in i.items() if k != "amount"} for i in prog["items"]]},   # quantities, never rates/amounts
            "low_stock": low, "flags": flags})
    mine = db.execute(select(PurchaseRequisition.status, func.count()).where(
        PurchaseRequisition.organization_id == org, PurchaseRequisition.requested_by == user.id).group_by(PurchaseRequisition.status)).all()
    recent = db.scalars(select(PurchaseRequisition).where(PurchaseRequisition.organization_id == org, PurchaseRequisition.requested_by == user.id)
                        .order_by(PurchaseRequisition.created_at.desc()).limit(5))
    return {"role": "SITE_ENGINEER", "as_of": S(today), "projects": out,
            "my_requisitions": {"by_status": {s.value: n for s, n in mine},
                                "recent": [{"id": S(r.id), "number": r.number, "status": r.status.value} for r in recent]},
            "todo": [f"Submit daily report for {p['code']}" for p in out if p["status"] == "ACTIVE" and p["today"]["daily_report"] != "SUBMITTED"]}


# ------------------------------------------------------------------ storekeeper (quantities only)
def store(db: Session, user: User) -> dict:
    org, today = user.organization_id, local_today()
    start, end = day_bounds_utc(today)
    items = {i.id: i for i in db.scalars(select(InventoryItem).where(InventoryItem.organization_id == org))}
    stores = []
    for w in db.scalars(select(Warehouse).where(Warehouse.organization_id == org).order_by(Warehouse.name)):
        bal = list(db.scalars(select(StockBalance).where(StockBalance.organization_id == org, StockBalance.warehouse_id == w.id)))
        stores.append({"id": S(w.id), "name": w.name, "project_id": S(w.project_id) if w.project_id else None,
                       "items_in_stock": sum(1 for b in bal if b.quantity > 0), "out_of_stock": [items[b.item_id].code for b in bal if b.quantity <= 0],
                       "below_reorder": ds.low_stock_items(db, org, warehouse_id=w.id)})
    incoming = []
    q = (select(PurchaseOrder, POLine, Supplier).join(POLine, POLine.po_id == PurchaseOrder.id)
         .join(Supplier, Supplier.id == PurchaseOrder.supplier_id)
         .where(PurchaseOrder.organization_id == org, PurchaseOrder.status.in_(OPEN_PO), POLine.quantity > POLine.received_qty)
         .order_by(PurchaseOrder.created_at))
    wh = {w["id"]: w["name"] for w in stores}
    for po, line, sup in db.execute(q.limit(30)):
        incoming.append({"po": po.number, "po_id": S(po.id), "supplier": sup.name, "warehouse": wh.get(S(po.warehouse_id)),
                         "item_code": items[line.item_id].code, "ordered": S(line.quantity), "received": S(line.received_qty),
                         "remaining": S(line.quantity - line.received_qty)})
    moves = defaultdict(lambda: {"count": 0, "quantity": ZERO})
    for t in db.scalars(select(StockTransaction).where(StockTransaction.organization_id == org, StockTransaction.created_at >= start,
                                                        StockTransaction.created_at < end)):
        m = moves[t.type.value]
        m["count"] += 1
        m["quantity"] += abs(t.quantity)
    return {"role": "STOREKEEPER", "as_of": S(today), "warehouses": stores, "expected_deliveries": incoming,
            "movements_today": {k: {"count": v["count"], "quantity": S(v["quantity"])} for k, v in sorted(moves.items())},
            "totals": {"below_reorder": sum(len(s["below_reorder"]) for s in stores), "deliveries_pending": len(incoming)}}


# ------------------------------------------------------------------ procurement
def procurement(db: Session, user: User) -> dict:
    org, today = user.organization_id, local_today()
    projects = {p.id: p.code for p in db.scalars(select(Project).where(Project.organization_id == org))}
    req_counts = {s.value: 0 for s in ReqStatus}
    for st, n in db.execute(select(PurchaseRequisition.status, func.count()).where(PurchaseRequisition.organization_id == org)
                            .group_by(PurchaseRequisition.status)):
        req_counts[st.value] = n
    ordered = set(db.scalars(select(PurchaseOrder.requisition_id).where(
        PurchaseOrder.organization_id == org, PurchaseOrder.requisition_id.is_not(None),
        PurchaseOrder.status.notin_([POStatus.CANCELLED, POStatus.REJECTED]))))
    quoted = set(db.scalars(select(SupplierQuote.requisition_id).where(SupplierQuote.organization_id == org)))
    awaiting_quotes, awaiting_po = [], []
    for r in db.scalars(select(PurchaseRequisition).where(PurchaseRequisition.organization_id == org,
                                                           PurchaseRequisition.status == ReqStatus.APPROVED).order_by(PurchaseRequisition.created_at)):
        row = {"id": S(r.id), "number": r.number, "project": projects[r.project_id],
               "age_days": (today - r.created_at.date()).days}
        (awaiting_po if r.id in quoted else awaiting_quotes).append(row)
    po_counts = {s.value: 0 for s in POStatus}
    for st, n in db.execute(select(PurchaseOrder.status, func.count()).where(PurchaseOrder.organization_id == org).group_by(PurchaseOrder.status)):
        po_counts[st.value] = n
    sup = {s.id: s.name for s in db.scalars(select(Supplier).where(Supplier.organization_id == org))}
    pending_pos = [{"id": S(p.id), "number": p.number, "supplier": sup[p.supplier_id], "amount": S(p.total_amount), "project": projects[p.project_id]}
                   for p in db.scalars(select(PurchaseOrder).where(PurchaseOrder.organization_id == org, PurchaseOrder.status == POStatus.PENDING_APPROVAL)
                                       .order_by(PurchaseOrder.created_at).limit(10))]
    committed_by_supplier: dict = defaultdict(lambda: ZERO)
    open_value = ZERO
    for p in db.scalars(select(PurchaseOrder).where(PurchaseOrder.organization_id == org, PurchaseOrder.status.in_((*OPEN_PO, POStatus.RECEIVED)))):
        committed_by_supplier[p.supplier_id] += p.total_amount
    for l in db.execute(select(POLine.quantity, POLine.received_qty, POLine.unit_rate).join(PurchaseOrder, PurchaseOrder.id == POLine.po_id)
                        .where(PurchaseOrder.organization_id == org, PurchaseOrder.status.in_(OPEN_PO))):
        open_value += (l[0] - l[1]) * l[2]
    shortages = db.scalar(select(func.count()).select_from(RequisitionLine).join(PurchaseRequisition, PurchaseRequisition.id == RequisitionLine.requisition_id)
                          .where(RequisitionLine.organization_id == org, RequisitionLine.shortage_qty > 0,
                                 PurchaseRequisition.status.in_([ReqStatus.SUBMITTED, ReqStatus.APPROVED])))
    return {"role": "PROCUREMENT_OFFICER", "as_of": S(today), "requisitions": {"by_status": req_counts, "awaiting_quotes": awaiting_quotes,
                                                                                 "quoted_awaiting_po": awaiting_po},
            "purchase_orders": {"by_status": po_counts, "pending_approval": pending_pos, "open_value_to_receive": S(boq_round(open_value))},
            "suppliers": {"unapproved": sum(1 for s in db.scalars(select(Supplier).where(Supplier.organization_id == org, Supplier.is_approved.is_(False)))),
                          "top_by_committed": [{"supplier": sup[k], "committed": S(v)} for k, v in
                                               sorted(committed_by_supplier.items(), key=lambda kv: -kv[1])[:5]]},
            "open_shortage_lines": shortages,
            "totals": {"to_quote": len(awaiting_quotes), "to_order": len(awaiting_po), "awaiting_approval": len(pending_pos)}}


def boq_round(x: Decimal) -> Decimal:
    return x.quantize(Decimal("0.01"))


# ------------------------------------------------------------------ accountant
def accountant(db: Session, user: User) -> dict:
    org, today = user.organization_id, local_today()
    cash, cash_accounts = _cash_balance(db, org, today)
    accounts = acc.ensure_accounts(db, org)
    db.commit()
    recv, recv_over = _receivables(db, org, today)
    pay, pay_over = _payables(db, org, today)
    aging = {"receivables": {k: ZERO for k in BUCKETS}, "payables": {k: ZERO for k in BUCKETS}}
    for b in db.scalars(select(ClientBill).where(ClientBill.organization_id == org, ClientBill.status.in_(RECEIVABLE))):
        aging["receivables"][bucket((today - b.due_date).days)] += b.net_payable - b.received_amount
    for i in db.scalars(select(SupplierInvoice).where(SupplierInvoice.organization_id == org, SupplierInvoice.status.in_(OPEN_INV))):
        aging["payables"][bucket((today - i.due_date).days)] += i.total_amount - i.paid_amount
    sup = {s.id: s.name for s in db.scalars(select(Supplier).where(Supplier.organization_id == org))}
    exceptions = []
    for i in db.scalars(select(SupplierInvoice).where(SupplierInvoice.organization_id == org, SupplierInvoice.status == InvoiceStatus.MATCH_EXCEPTION)
                        .order_by(SupplierInvoice.created_at).limit(10)):
        msgs = [e.message for e in db.scalars(select(InvoiceException).where(InvoiceException.invoice_id == i.id))]
        exceptions.append({"id": S(i.id), "number": i.number, "supplier": sup[i.supplier_id], "amount": S(i.total_amount), "problems": msgs})
    n_exc = db.scalar(select(func.count()).select_from(SupplierInvoice).where(SupplierInvoice.organization_id == org,
                                                                              SupplierInvoice.status == InvoiceStatus.MATCH_EXCEPTION))
    approvals = {}
    for key, model, status_col, amt in (("supplier_payments", Payment, Payment.status, Payment.amount), ("expenses", Expense, Expense.status, Expense.amount)):
        n, total = db.execute(select(func.count(), func.coalesce(func.sum(amt), 0)).where(model.organization_id == org,
                                                                                          status_col == ApprovalState.PENDING_APPROVAL)).one()
        approvals[key] = {"count": n, "amount": S(Decimal(total))}
    from app.billing.models import BillStatus, ClientReceipt
    n, total = db.execute(select(func.count(), func.coalesce(func.sum(ClientReceipt.amount), 0)).where(
        ClientReceipt.organization_id == org, ClientReceipt.status == ApprovalState.PENDING_APPROVAL)).one()
    approvals["client_receipts"] = {"count": n, "amount": S(Decimal(total))}
    n, total = db.execute(select(func.count(), func.coalesce(func.sum(ClientBill.net_payable), 0)).where(
        ClientBill.organization_id == org, ClientBill.status == BillStatus.PENDING_APPROVAL)).one()
    approvals["client_bills"] = {"count": n, "amount": S(Decimal(total))}
    month_start = today.replace(day=1)
    cash_ids = [a.id for a in accounts.values() if a.is_cash]
    inflow = outflow = ZERO
    for d, c in db.execute(select(JournalLine.debit, JournalLine.credit).join(JournalEntry, JournalEntry.id == JournalLine.entry_id)
                           .where(JournalLine.organization_id == org, JournalLine.account_id.in_(cash_ids or [None]),
                                  JournalEntry.entry_date >= month_start, JournalEntry.entry_date <= today)):
        inflow += d
        outflow += c
    tb_debit = tb_credit = ZERO
    for a_id, d, c in db.execute(select(JournalLine.account_id, func.sum(JournalLine.debit), func.sum(JournalLine.credit))
                                 .where(JournalLine.organization_id == org).group_by(JournalLine.account_id)):
        net = Decimal(d or 0) - Decimal(c or 0)
        tb_debit += net if net > 0 else ZERO
        tb_credit += -net if net < 0 else ZERO
    ctl = {k: S(acc.balance(db, org, accounts[code].id)) for k, code in (("goods_received_not_invoiced", "2100"), ("wages_payable", "2200"),
                                                                       ("retention_receivable", "1300"), ("customer_advances", "2300"),
                                                                       ("tax_withheld_recoverable", "1400"))}
    return {"role": "ACCOUNTANT", "as_of": S(today),
            "cash": {"total": S(cash), "accounts": cash_accounts, "month_to_date_in": S(inflow), "month_to_date_out": S(outflow)},
            "receivables": {"total": S(recv), "overdue": S(recv_over), "aging": {k: S(v) for k, v in aging["receivables"].items()}},
            "payables": {"total": S(pay), "overdue": S(pay_over), "aging": {k: S(v) for k, v in aging["payables"].items()}},
            "invoice_exceptions": {"count": n_exc, "items": exceptions},
            "pending_approvals": approvals, "control_accounts": ctl,
            "ledger_check": {"balanced": tb_debit == tb_credit, "total_debit": S(tb_debit), "total_credit": S(tb_credit)}}
