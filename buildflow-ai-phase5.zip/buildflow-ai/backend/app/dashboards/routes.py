from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.dashboards import views
from app.dashboards.service import perms
from app.db import get_db
from app.deps import get_current_user, require_permission
from app.models import User

router = APIRouter(prefix="/dashboards", tags=["dashboards"])
AVAILABLE = {"ceo": "dashboard.ceo", "manager": "dashboard.manager", "engineer": "dashboard.engineer",
             "store": "dashboard.store", "procurement": "dashboard.procurement", "accountant": "dashboard.accountant"}
DEFAULT_ORDER = ["ceo", "manager", "engineer", "store", "procurement", "accountant"]


@router.get("")
def my_dashboards(user: User = Depends(get_current_user)):
    p = perms(user)
    mine = [k for k in DEFAULT_ORDER if AVAILABLE[k] in p]
    return {"available": mine, "default": mine[0] if mine else None}


@router.get("/ceo")
def ceo(user: User = Depends(require_permission("dashboard.ceo")), db: Session = Depends(get_db)):
    return views.ceo(db, user)


@router.get("/manager")
def manager(user: User = Depends(require_permission("dashboard.manager")), db: Session = Depends(get_db)):
    return views.manager(db, user)


@router.get("/engineer")
def engineer(user: User = Depends(require_permission("dashboard.engineer")), db: Session = Depends(get_db)):
    return views.engineer(db, user)


@router.get("/store")
def store(user: User = Depends(require_permission("dashboard.store")), db: Session = Depends(get_db)):
    return views.store(db, user)


@router.get("/procurement")
def procurement(user: User = Depends(require_permission("dashboard.procurement")), db: Session = Depends(get_db)):
    return views.procurement(db, user)


@router.get("/accountant")
def accountant(user: User = Depends(require_permission("dashboard.accountant")), db: Session = Depends(get_db)):
    return views.accountant(db, user)
