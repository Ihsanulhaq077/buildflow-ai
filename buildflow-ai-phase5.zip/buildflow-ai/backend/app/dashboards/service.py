"""Role dashboards. Every figure is a deterministic query over the system of record (no LLM, no hardcoded values).
Risk flags are rule-based and carry their evidence so a reader can verify them."""
import uuid
from collections import defaultdict
from datetime import date, timedelta
from decimal import Decimal

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.accounting import service as acc
from app.accounting.models import Account, JournalEntry, JournalLine
from app.billing.models import RECEIVABLE, ClientBill, ClientReceipt, ClientVariation, VariationStatus
from app.billing.routes import billed_gross, revised_contract_value
from app.boq import calculations as boq_calc
from app.boq.models import ApprovalStatus
from app.budgets.models import Budget, BudgetLine
from app.config import settings
from app.dailylogs import service as log_service
from app.dailylogs.models import DailyLog, LogStatus
from app.finance.models import ApprovalState, Expense, InvoiceException, InvoiceStatus, Payment, SupplierInvoice
from app.inventory.models import InventoryItem, MovementType as MT, StockBalance, StockTransaction, Warehouse
from app.labour.models import AttendanceSheet, SheetStatus
from app.models import User
from app.procurement.models import (POLine, POStatus, PurchaseOrder, PurchaseRequisition, ReqStatus, RequisitionLine,
                                    Supplier, SupplierQuote)
from app.projects.models import Project, ProjectStatus
from app.reports import service as rs
from app.timeutil import day_bounds_utc, local_today

ZERO = Decimal("0")
LIVE = (ProjectStatus.APPROVED, ProjectStatus.ACTIVE, ProjectStatus.ON_HOLD)
SEVERITY = {"HIGH": 3, "MEDIUM": 2, "LOW": 1}
S = str


def perms(user: User) -> set[str]:
    return {p.code for p in user.role.permissions}


def pct(a: Decimal, b: Decimal) -> Decimal:
    return boq_calc.q2(a / b * 100) if b else Decimal("0.00")


# ------------------------------------------------------------------ scoping
def scoped_projects(db: Session, user: User, mode: str, statuses=LIVE) -> list[Project]:
    """Owners see the portfolio. Managers see projects where they are project_manager; engineers where they are engineer."""
    q = select(Project).where(Project.organization_id == user.organization_id, Project.deleted_at.is_(None))
    if statuses:
        q = q.where(Project.status.in_(statuses))
    if "dashboard.ceo" not in perms(user):
        q = q.where((Project.project_manager_id if mode == "manager" else Project.engineer_id) == user.id)
    return list(db.scalars(q.order_by(Project.code)))


# ------------------------------------------------------------------ building blocks
def budget_sums(db: Session, org_id, ids) -> dict:
    q = (select(Budget.project_id, func.sum(BudgetLine.revised_amount), func.sum(BudgetLine.committed_amount),
                func.sum(BudgetLine.actual_amount), func.sum(BudgetLine.paid_amount))
         .join(BudgetLine, BudgetLine.budget_id == Budget.id)
         .where(Budget.organization_id == org_id, Budget.project_id.in_(ids or [None])).group_by(Budget.project_id))
    return {pid: tuple(Decimal(x or 0) for x in rest) for pid, *rest in db.execute(q)}


def last_report_dates(db: Session, org_id, ids) -> dict:
    q = (select(DailyLog.project_id, func.max(DailyLog.log_date)).where(
        DailyLog.organization_id == org_id, DailyLog.project_id.in_(ids or [None]), DailyLog.status == LogStatus.SUBMITTED)
         .group_by(DailyLog.project_id))
    return dict(db.execute(q).all())


def low_stock_items(db: Session, org_id, project_id=None, warehouse_id=None) -> list[dict]:
    q = (select(StockBalance, InventoryItem, Warehouse).join(InventoryItem, InventoryItem.id == StockBalance.item_id)
         .join(Warehouse, Warehouse.id == StockBalance.warehouse_id)
         .where(StockBalance.organization_id == org_id, InventoryItem.reorder_level > 0,
                StockBalance.quantity <= InventoryItem.reorder_level))
    if project_id:
        q = q.where(Warehouse.project_id == project_id)
    if warehouse_id:
        q = q.where(Warehouse.id == warehouse_id)
    return [{"warehouse": w.name, "warehouse_id": S(w.id), "item_code": i.code, "item_name": i.name,
             "quantity": S(b.quantity), "reorder_level": S(i.reorder_level)}
            for b, i, w in db.execute(q.order_by(Warehouse.name, InventoryItem.code))]


def overdue_receivable(db: Session, org_id, project_id, today: date) -> Decimal:
    v = db.scalar(select(func.coalesce(func.sum(ClientBill.net_payable - ClientBill.received_amount), 0)).where(
        ClientBill.organization_id == org_id, ClientBill.project_id == project_id, ClientBill.status.in_(RECEIVABLE),
        ClientBill.due_date < today))
    return Decimal(v)


def project_flags(p: Project, today: date, *, money: bool, budget: tuple | None, progress: Decimal, last_log: date | None,
                  low_stock: int, receivable_overdue: Decimal) -> list[dict]:
    """Rule-based flags. Thresholds live in settings; every flag carries the numbers behind it."""
    flags = []
    gap_limit = Decimal(settings.dashboard_cost_gap_pct)
    if money and budget and budget[0] > 0:
        revised, committed, actual, _paid = budget
        cost_pct = pct(actual, revised)
        if actual > revised:
            flags.append({"code": "BUDGET_EXCEEDED", "severity": "HIGH", "message": "Actual cost exceeds the revised budget",
                          "evidence": {"actual": S(actual), "revised_budget": S(revised)}})
        elif committed * 100 >= revised * 90:
            flags.append({"code": "COMMITMENT_NEAR_LIMIT", "severity": "MEDIUM",
                          "message": "Committed cost has reached 90% of the revised budget",
                          "evidence": {"committed": S(committed), "revised_budget": S(revised)}})
        gap = cost_pct - progress
        if actual > 0 and gap > gap_limit:
            flags.append({"code": "COST_AHEAD_OF_PROGRESS", "severity": "HIGH" if gap > 2 * gap_limit else "MEDIUM",
                          "message": "Cost consumption is ahead of physical progress",
                          "evidence": {"cost_percent": S(cost_pct), "progress_percent": S(progress), "gap_points": S(gap),
                                       "threshold_points": S(gap_limit)}})
    if p.planned_end_date and p.planned_end_date < today and p.status in LIVE:
        flags.append({"code": "OVERDUE", "severity": "HIGH", "message": "Planned completion date has passed",
                      "evidence": {"planned_end_date": S(p.planned_end_date), "days_late": (today - p.planned_end_date).days}})
    if p.status == ProjectStatus.ACTIVE:
        limit = settings.dashboard_missing_report_days
        base = last_log or p.start_date
        if base and (today - base).days >= limit:
            flags.append({"code": "NO_RECENT_DAILY_REPORT", "severity": "MEDIUM",
                          "message": f"No submitted daily report for {limit}+ days",
                          "evidence": {"last_report": S(last_log) if last_log else None, "days": (today - base).days}})
    if low_stock:
        flags.append({"code": "LOW_STOCK", "severity": "LOW", "message": "Items at or below reorder level at the project store",
                      "evidence": {"items": low_stock}})
    if money and receivable_overdue > 0:
        flags.append({"code": "RECEIVABLE_OVERDUE", "severity": "MEDIUM", "message": "Certified bills are past their due date",
                      "evidence": {"overdue_amount": S(receivable_overdue)}})
    return sorted(flags, key=lambda f: -SEVERITY[f["severity"]])


def risk_level(flags: list[dict]) -> str:
    return max((f["severity"] for f in flags), key=lambda x: SEVERITY[x], default="OK")


def schedule_risk(flags: list[dict]) -> dict:
    codes = {f["code"] for f in flags}
    level = "HIGH" if "OVERDUE" in codes else "MEDIUM" if "NO_RECENT_DAILY_REPORT" in codes else "LOW"
    return {"level": level, "basis": "planned end date and daily-report cadence (no task schedule exists yet)"}


def project_cards(db: Session, user: User, projects: list[Project], *, money: bool) -> list[dict]:
    org, today = user.organization_id, local_today()
    ids = [p.id for p in projects]
    budgets, logs = budget_sums(db, org, ids), last_report_dates(db, org, ids)
    cards = []
    for p in projects:
        progress = Decimal(log_service.project_progress(db, org, p.id)["overall_percent"])
        b = budgets.get(p.id)
        low = len(low_stock_items(db, org, project_id=p.id))
        recv = overdue_receivable(db, org, p.id, today) if money else ZERO
        flags = project_flags(p, today, money=money, budget=b, progress=progress, last_log=logs.get(p.id),
                              low_stock=low, receivable_overdue=recv)
        card = {"id": S(p.id), "code": p.code, "name": p.name, "status": p.status.value, "start_date": S(p.start_date) if p.start_date else None,
                "planned_end_date": S(p.planned_end_date) if p.planned_end_date else None, "physical_progress_percent": S(progress),
                "last_daily_report": S(logs[p.id]) if p.id in logs else None, "risk": risk_level(flags),
                "schedule_risk": schedule_risk(flags), "flags": flags}
        if money:
            revised_contract = revised_contract_value(db, org, p)
            billed = billed_gross(db, org, p.id)
            card.update({"contract_value": S(revised_contract), "billed_percent": S(pct(billed, revised_contract)),
                         "budget": None if not b else {"revised": S(b[0]), "committed": S(b[1]), "actual": S(b[2]), "paid": S(b[3]),
                                                       "remaining": S(b[0] - b[1]), "variance": S(b[0] - b[2]),
                                                       "cost_percent": S(pct(b[2], b[0])),
                                                       "cost_minus_progress_points": S(pct(b[2], b[0]) - progress),
                                                       "planned_margin": S(revised_contract - b[0])}})
        cards.append(card)
    return cards


# ------------------------------------------------------------------ approvals queue (permission- and scope-aware)
def pending_approvals(db: Session, user: User, scope_ids: list[uuid.UUID] | None) -> dict:
    org, P, limit = user.organization_id, perms(user), user.role.approval_limit
    projects = {p.id: p for p in db.scalars(select(Project).where(Project.organization_id == org))}
    out: dict[str, dict] = {}

    def add(key, rows, amount_of=None):
        rows = list(rows)
        out[key] = {"count": len(rows), "amount": S(sum((amount_of(r) for r in rows), ZERO)) if amount_of else None,
                    "items": [{"id": S(r.id), "number": getattr(r, "number", None), "created_at": r.created_at.isoformat(),
                               "project": projects[r.project_id].code if getattr(r, "project_id", None) else None,
                               **({"amount": S(amount_of(r)), "within_my_limit": amount_of(r) <= limit} if amount_of else {})}
                              for r in rows[:10]]}

    def q(model, status_col, status, project_col=None):
        stmt = select(model).where(model.organization_id == org, status_col == status).order_by(model.created_at)
        if scope_ids is not None and project_col is not None:
            stmt = stmt.where(project_col.in_(scope_ids or [None]))
        return db.scalars(stmt)

    if "procurement.approve" in P:
        add("requisitions", q(PurchaseRequisition, PurchaseRequisition.status, ReqStatus.SUBMITTED, PurchaseRequisition.project_id))
        add("purchase_orders", q(PurchaseOrder, PurchaseOrder.status, POStatus.PENDING_APPROVAL, PurchaseOrder.project_id),
            lambda r: r.total_amount)
    if "expenses.approve" in P:
        add("expenses", q(Expense, Expense.status, ApprovalState.PENDING_APPROVAL, Expense.project_id), lambda r: r.amount)
    if "attendance.approve" in P:
        add("attendance_sheets", q(AttendanceSheet, AttendanceSheet.status, SheetStatus.SUBMITTED, AttendanceSheet.project_id))
    if scope_ids is None:   # company-level money approvals are not project-scoped
        if "finance.approve" in P:
            add("payments", q(Payment, Payment.status, ApprovalState.PENDING_APPROVAL), lambda r: r.amount)
            add("client_receipts", q(ClientReceipt, ClientReceipt.status, ApprovalState.PENDING_APPROVAL), lambda r: r.amount)
        if "billing.approve" in P:
            from app.billing.models import BillStatus
            add("client_bills", q(ClientBill, ClientBill.status, BillStatus.PENDING_APPROVAL, ClientBill.project_id), lambda r: r.net_payable)
            add("variations", q(ClientVariation, ClientVariation.status, VariationStatus.PENDING_APPROVAL, ClientVariation.project_id),
                lambda r: r.amount)
        if "budgets.approve" in P:
            add("budgets", q(Budget, Budget.status, ApprovalStatus.DRAFT, Budget.project_id))
    return {"total_pending": sum(v["count"] for v in out.values()), "approval_limit": S(limit), "queues": out}
