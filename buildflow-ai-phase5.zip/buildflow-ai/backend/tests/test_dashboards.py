from datetime import timedelta
from decimal import Decimal as D

from app.timeutil import local_today
from tests import test_billing as tbill
from tests.helpers import accounts, add_user, closing, grn, invoice, mk_project, post, received_po, register

TODAY = local_today()
T = str(TODAY)
MONEY_WORDS = {"budget", "amount", "cost", "avg_cost", "unit_cost", "value", "rate", "revised", "committed", "actual", "contract_value",
               "price", "net_payable", "paid", "profit", "margin", "receivable", "payable", "cash"}


def world(client, **extra_project):
    """Active project with PM + engineer assigned, a client/contract, an accountant, and a labour+cement budget."""
    ctx = tbill.setup(client, labour=True)
    h = ctx["h"]
    ctx["pm_id"] = client.get("/users/me", headers=ctx["pm"]).json()["id"]
    ctx["eng"] = ctx["u"]["SITE_ENGINEER"]
    ctx["eng_id"] = client.get("/users/me", headers=ctx["eng"]).json()["id"]
    body = {"project_manager_id": ctx["pm_id"], "engineer_id": ctx["eng_id"], "start_date": str(TODAY - timedelta(days=10)),
            "planned_end_date": str(TODAY + timedelta(days=60)), **extra_project}
    assert client.patch(f"/projects/{ctx['project']['id']}", headers=h, json=body).status_code == 200
    for st in ("APPROVED", "ACTIVE"):
        post(client, h, f"/projects/{ctx['project']['id']}/status", {"status": st})
    return ctx


def keys(obj):
    if isinstance(obj, dict):
        for k, v in obj.items():
            yield k.lower()
            yield from keys(v)
    elif isinstance(obj, list):
        for v in obj:
            yield from keys(v)


def dash(client, who, name, expect=200):
    r = client.get(f"/dashboards/{name}", headers=who)
    assert r.status_code == expect, r.text
    return r.json()


def flag(card, code):
    return next((f for f in card["flags"] if f["code"] == code), None)


def test_ceo_numbers_match_the_underlying_reports(client):
    ctx = world(client)
    h, A = ctx["h"], ctx["A"]
    post(client, ctx["acct"], "/journal-entries", {"entry_date": T, "description": "Opening capital", "lines": [
        {"account_id": A["1010"], "debit": "1000000"}, {"account_id": A["3000"], "credit": "1000000"}]}, 201)
    po, s = received_po(client, ctx, "100", "1000", "100")
    invoice(client, ctx, po, "100", "1000", "SI-1", due=str(TODAY + timedelta(days=20)), date=T)
    bill = tbill.certify(client, ctx, tbill.mk_bill(client, ctx, tbill.milestone("1000000"), bill_type="MILESTONE",
                                                    date="2025-01-01", due=str(TODAY - timedelta(days=5))))
    d = dash(client, h, "ceo")
    assert d["projects"]["total"] == 1 and d["projects"]["active"] == 1 and d["projects"]["by_status"]["ACTIVE"] == 1
    pf = d["portfolio"]
    assert D(pf["contract_value"]) == 5000000 and D(pf["total_budget"]) == 2750000          # cement 2.0M + labour 0.75M
    assert D(pf["committed_cost"]) == 100000 and D(pf["actual_cost"]) == 100000 and D(pf["paid_cost"]) == 0
    assert D(pf["cost_variance"]) == 2650000 and D(pf["planned_margin"]) == 2250000
    m = d["money"]
    assert D(m["cash"]) == 1000000 and D(m["receivables"]) == 950000 and D(m["receivables_overdue"]) == 950000
    assert D(m["payables"]) == 100000 and D(m["payables_overdue"]) == 0 and D(m["net_position"]) == 1000000 + 950000 - 100000
    # one source of truth: dashboard == the dedicated report endpoints
    pid = ctx["project"]["id"]
    budget = client.get(f"/projects/{pid}/budget", headers=h).json()["totals"]
    row = d["project_table"][0]["budget"]
    assert (D(row["revised"]), D(row["committed"]), D(row["actual"]), D(row["paid"])) == (
        D(budget["revised"]), D(budget["committed"]), D(budget["actual"]), D(budget["paid"]))
    pnl = client.get(f"/projects/{pid}/pnl", headers=h).json()
    assert D(pf["profit_to_date"]) == D(pnl["gross_profit"]) == 1000000 - 100000 and D(pf["profit_to_date"]) == D(
        client.get("/reports/pnl", headers=h).json()["totals"]["company_net_profit"])
    cf = client.get("/reports/cash-flow", headers=h).json()
    assert D(m["cash"]) == D(cf["closing_cash"])
    assert D(client.get("/reports/receivables-aging", headers=h).json()["totals"]["total"]) == D(m["receivables"])
    assert D(client.get("/reports/payables-aging", headers=h).json()["totals"]["total"]) == D(m["payables"])
    summ = client.get(f"/projects/{pid}/billing-summary", headers=h).json()
    assert D(d["project_table"][0]["billed_percent"]) == D(summ["billed_percent"])


def test_risk_flags_carry_evidence_and_clear_when_resolved(client):
    ctx = world(client)
    h, eng = ctx["h"], ctx["eng"]
    po, _ = received_po(client, ctx, "1000", "1500", "1000")                                   # 1.5M of cement received
    c = dash(client, h, "ceo")["project_table"][0]
    f = flag(c, "COST_AHEAD_OF_PROGRESS")
    assert f["severity"] == "HIGH" and D(f["evidence"]["cost_percent"]) == D("54.55") and D(f["evidence"]["progress_percent"]) == 0
    assert D(f["evidence"]["gap_points"]) == D("54.55") and f["evidence"]["threshold_points"] == "10"
    nr = flag(c, "NO_RECENT_DAILY_REPORT")
    assert nr["evidence"]["days"] == 10 and nr["evidence"]["last_report"] is None
    assert c["risk"] == "HIGH" and c["schedule_risk"]["level"] == "MEDIUM"
    # report 600 of 1000 bags: weighted progress 43.64% -> gap 10.91 pts -> MEDIUM, and the missing-report flag clears
    log = post(client, eng, "/daily-logs", {"project_id": ctx["project"]["id"], "log_date": T, "work_completed": "Columns",
                                            "progress": [{"boq_item_id": ctx["boq_item"]["id"], "quantity": "600"}]}, 201)
    post(client, eng, f"/daily-logs/{log['id']}/submit")
    c = dash(client, h, "ceo")["project_table"][0]
    f = flag(c, "COST_AHEAD_OF_PROGRESS")
    assert D(c["physical_progress_percent"]) == D("43.64") and f["severity"] == "MEDIUM" and D(f["evidence"]["gap_points"]) == D("10.91")
    assert flag(c, "NO_RECENT_DAILY_REPORT") is None and c["last_daily_report"] == T
    # progress catches up -> flag disappears
    log2 = post(client, eng, "/daily-logs", {"project_id": ctx["project"]["id"], "log_date": str(TODAY - timedelta(days=1)),
                                             "work_completed": "More", "progress": [{"boq_item_id": ctx["boq_item"]["id"], "quantity": "200"}]}, 201)
    post(client, eng, f"/daily-logs/{log2['id']}/submit")
    assert flag(dash(client, h, "ceo")["project_table"][0], "COST_AHEAD_OF_PROGRESS") is None


def test_overdue_budget_exceeded_low_stock_and_receivable_flags(client):
    ctx = world(client)
    h = ctx["h"]
    client.patch(f"/projects/{ctx['project']['id']}", headers=h, json={"planned_end_date": str(TODAY - timedelta(days=4))})
    hr = add_user(client, h, "hr@alpha.pk", "HR_ADMIN")
    fm = add_user(client, h, "fm@alpha.pk", "FOREMAN")
    w = post(client, hr, "/workers", {"code": "BIG", "name": "Big Earner", "daily_rate": "3000000", "cost_code_id": ctx["lab_cc"]}, 201)
    s = post(client, fm, "/attendance-sheets", {"project_id": ctx["project"]["id"], "work_date": T,
                                                "entries": [{"worker_id": w["id"], "status": "PRESENT"}]}, 201)
    post(client, fm, f"/attendance-sheets/{s['id']}/submit")
    post(client, ctx["pm"], f"/attendance-sheets/{s['id']}/approve")                            # labour is not PO-capped: 3.0M > 2.75M budget
    post(client, h, "/inventory/adjustments", {"warehouse_id": ctx["wh"]["id"], "item_id": ctx["item"]["id"], "kind": "OPENING_STOCK",
                                              "quantity": "50", "unit_cost": "1000", "reason": "opening balance"}, 201)    # reorder level is 100
    tbill.certify(client, ctx, tbill.mk_bill(client, ctx, tbill.milestone("100000"), bill_type="MILESTONE",
                                             date="2025-01-01", due=str(TODAY - timedelta(days=1))))
    c = dash(client, h, "ceo")["project_table"][0]
    assert flag(c, "OVERDUE")["evidence"]["days_late"] == 4
    be = flag(c, "BUDGET_EXCEEDED")
    assert be["severity"] == "HIGH" and D(be["evidence"]["actual"]) == 3000000 and D(be["evidence"]["revised_budget"]) == 2750000
    assert flag(c, "LOW_STOCK")["evidence"]["items"] == 1
    assert D(flag(c, "RECEIVABLE_OVERDUE")["evidence"]["overdue_amount"]) == 95000          # 100,000 less 5% retention
    assert c["risk"] == "HIGH" and c["schedule_risk"]["level"] == "HIGH"
    sev = [f["severity"] for f in c["flags"]]
    assert sev == sorted(sev, key={"HIGH": 0, "MEDIUM": 1, "LOW": 2}.get)                   # most severe first
    att = dash(client, h, "ceo")["attention"]
    assert att[0]["project"] == "ABC-01" and att[0]["risk"] == "HIGH" and len(att[0]["reasons"]) == 3


def test_approvals_queue_and_manager_scoping(client):
    ctx = world(client)
    h, pm, proc = ctx["h"], ctx["pm"], ctx["u"]["PROCUREMENT_OFFICER"]
    other = mk_project(client, h, code="OTHER", contract_value="1000000")                         # a second project the PM is NOT assigned to
    for st in ("APPROVED", "ACTIVE"):
        post(client, h, f"/projects/{other['id']}/status", {"status": st})
    sup = post(client, proc, "/suppliers", {"name": "S1"}, 201)
    post(client, h, f"/suppliers/{sup['id']}/approve")
    po = post(client, proc, "/purchase-orders", {"project_id": ctx["project"]["id"], "warehouse_id": ctx["wh"]["id"], "supplier_id": sup["id"],
                                                 "lines": [{"item_id": ctx["item"]["id"], "quantity": "400", "unit_rate": "1000"}]}, 201)
    post(client, proc, f"/purchase-orders/{po['id']}/submit")
    r = post(client, ctx["eng"], "/requisitions", {"project_id": ctx["project"]["id"], "warehouse_id": ctx["wh"]["id"],
                                                  "lines": [{"item_id": ctx["item"]["id"], "quantity": "10"}]}, 201)
    post(client, ctx["eng"], f"/requisitions/{r['id']}/submit")
    m = dash(client, pm, "manager")
    assert [p["code"] for p in m["projects"]] == ["ABC-01"] and m["scope"] == "assigned projects"   # OTHER is not visible
    q = m["approvals"]["queues"]
    assert q["purchase_orders"]["count"] == 1 and q["purchase_orders"]["items"][0]["within_my_limit"] is False   # 400,000 > PM limit 50,000
    assert q["requisitions"]["count"] == 1 and "payments" not in q and "client_bills" not in q            # only what a PM can act on
    assert m["approvals"]["approval_limit"] == "50000"
    own = dash(client, h, "manager")
    assert {p["code"] for p in own["projects"]} == {"ABC-01", "OTHER"} and own["scope"] == "all projects"
    # a requisition in the unassigned project does not reach the PM's queue
    r2 = post(client, h, "/requisitions", {"project_id": other["id"], "warehouse_id": post(client, h, "/warehouses", {"name": "Other Store", "project_id": other["id"]}, 201)["id"],
                                          "lines": [{"item_id": ctx["item"]["id"], "quantity": "5"}]}, 201)
    post(client, h, f"/requisitions/{r2['id']}/submit")
    assert dash(client, pm, "manager")["approvals"]["queues"]["requisitions"]["count"] == 1
    assert dash(client, h, "ceo")["approvals"]["queues"]["requisitions"]["count"] == 2
    ceo_q = dash(client, h, "ceo")["approvals"]
    assert ceo_q["queues"]["purchase_orders"]["amount"] == "400000.00" and ceo_q["total_pending"] >= 3
    # missing reports: 7-day window for the ACTIVE project, minus submitted days
    log = post(client, ctx["eng"], "/daily-logs", {"project_id": ctx["project"]["id"], "log_date": str(TODAY - timedelta(days=2)),
                                                  "work_completed": "Work"}, 201)
    post(client, ctx["eng"], f"/daily-logs/{log['id']}/submit")
    card = dash(client, pm, "manager")["projects"][0]
    assert len(card["missing_daily_reports_last_7_days"]) == 6 and str(TODAY - timedelta(days=2)) not in card["missing_daily_reports_last_7_days"]
    assert card["attendance_today"] == "NOT_STARTED" and card["open_requisitions"] == 1
    unassigned = add_user(client, h, "pm2@alpha.pk", "PROJECT_MANAGER")
    assert dash(client, unassigned, "manager")["projects"] == []                                   # a PM with no projects sees none


def test_engineer_dashboard_is_scoped_and_contains_no_financial_data(client):
    ctx = world(client)
    h, eng = ctx["h"], ctx["eng"]
    other = mk_project(client, h, code="OTHER")
    for st in ("APPROVED", "ACTIVE"):
        post(client, h, f"/projects/{other['id']}/status", {"status": st})
    po, _ = received_po(client, ctx, "100", "1000", "100")
    d = dash(client, eng, "engineer")
    assert [p["code"] for p in d["projects"]] == ["ABC-01"]
    p = d["projects"][0]
    assert p["today"]["daily_report"] == "NOT_STARTED" and p["today"]["attendance"] == "NOT_STARTED"
    assert d["todo"] == ["Submit daily report for ABC-01"]
    received = p["today"]["materials"]["received"]
    assert received == [{"item_code": "CEMENT", "item_name": "Cement 50kg", "quantity": "100.0000"}]
    assert p["progress"]["items"][0]["item_code"] == "CEM" and "amount" not in p["progress"]["items"][0]
    leaked = MONEY_WORDS & set(keys(d))
    assert not leaked, leaked                                                                       # no money anywhere in the payload
    assert not {f["code"] for f in p["flags"]} & {"BUDGET_EXCEEDED", "COST_AHEAD_OF_PROGRESS", "RECEIVABLE_OVERDUE", "COMMITMENT_NEAR_LIMIT"}
    log = post(client, eng, "/daily-logs", {"project_id": ctx["project"]["id"], "log_date": T, "work_completed": "Slab"}, 201)
    assert dash(client, eng, "engineer")["projects"][0]["today"]["daily_report"] == "DRAFT"
    post(client, eng, f"/daily-logs/{log['id']}/submit")
    d = dash(client, eng, "engineer")
    assert d["projects"][0]["today"]["daily_report"] == "SUBMITTED" and d["todo"] == []
    r = post(client, eng, "/requisitions", {"project_id": ctx["project"]["id"], "warehouse_id": ctx["wh"]["id"],
                                           "lines": [{"item_id": ctx["item"]["id"], "quantity": "500"}]}, 201)
    mine = dash(client, eng, "engineer")["my_requisitions"]
    assert mine["by_status"] == {"DRAFT": 1} and mine["recent"][0]["number"] == r["number"]


def test_store_dashboard_quantities_only(client):
    ctx = world(client)
    h, store = ctx["h"], ctx["u"]["STOREKEEPER"]
    po, _ = received_po(client, ctx, "300", "1000", "100")                                          # 200 still to come
    post(client, ctx["eng"], "/inventory/issues", {"warehouse_id": ctx["wh"]["id"], "project_id": ctx["project"]["id"],
                                                  "lines": [{"item_id": ctx["item"]["id"], "quantity": "60"}]}, 201)
    d = dash(client, store, "store")
    w = d["warehouses"][0]
    assert w["name"] == "ABC Site Store" and w["items_in_stock"] == 1
    assert [i["item_code"] for i in w["below_reorder"]] == ["CEMENT"] and w["below_reorder"][0]["quantity"] == "40.0000"   # 100 - 60 <= 100
    dl = d["expected_deliveries"][0]
    assert dl["remaining"] == "200.0000" and dl["ordered"] == "300.0000" and dl["warehouse"] == "ABC Site Store"
    mv = d["movements_today"]
    assert mv["PURCHASE_RECEIPT"]["count"] == 1 and mv["MATERIAL_ISSUE"] == {"count": 1, "quantity": "60.0000"}
    assert d["totals"] == {"below_reorder": 1, "deliveries_pending": 1}
    assert not (MONEY_WORDS - {"value"}) & set(keys(d)) and "avg_cost" not in set(keys(d))
    assert dash(client, ctx["eng"], "store", expect=403) and dash(client, ctx["acct"], "store", expect=403)


def test_procurement_pipeline_dashboard(client):
    ctx = world(client)
    h, proc, eng, pm = ctx["h"], ctx["u"]["PROCUREMENT_OFFICER"], ctx["eng"], ctx["pm"]
    post(client, h, "/inventory/adjustments", {"warehouse_id": ctx["wh"]["id"], "item_id": ctx["item"]["id"], "kind": "OPENING_STOCK",
                                              "quantity": "20", "unit_cost": "1000", "reason": "opening balance"}, 201)
    r = post(client, eng, "/requisitions", {"project_id": ctx["project"]["id"], "warehouse_id": ctx["wh"]["id"],
                                           "lines": [{"item_id": ctx["item"]["id"], "quantity": "120"}]}, 201)
    post(client, eng, f"/requisitions/{r['id']}/submit")
    d = dash(client, proc, "procurement")
    assert d["open_shortage_lines"] == 1 and d["requisitions"]["by_status"]["SUBMITTED"] == 1 and d["totals"]["to_quote"] == 0
    r = post(client, pm, f"/requisitions/{r['id']}/approve", {"comment": "ok"})
    d = dash(client, proc, "procurement")
    assert [x["number"] for x in d["requisitions"]["awaiting_quotes"]] == [r["number"]]
    sup = post(client, proc, "/suppliers", {"name": "Quick Supplier"}, 201)
    assert dash(client, proc, "procurement")["suppliers"]["unapproved"] == 1
    post(client, proc, f"/requisitions/{r['id']}/quotes", {"supplier_id": sup["id"], "lines": [
        {"requisition_line_id": r["lines"][0]["id"], "unit_rate": "1200"}]}, 201)
    d = dash(client, proc, "procurement")
    assert d["requisitions"]["awaiting_quotes"] == [] and [x["number"] for x in d["requisitions"]["quoted_awaiting_po"]] == [r["number"]]
    post(client, h, f"/suppliers/{sup['id']}/approve")
    po = post(client, proc, "/purchase-orders/from-quote", {"quote_id": client.get(f"/requisitions/{r['id']}/comparison", headers=proc)
                                                            .json()["suppliers"][0]["quote_id"]}, 201)
    post(client, proc, f"/purchase-orders/{po['id']}/submit")
    d = dash(client, proc, "procurement")
    assert d["totals"] == {"to_quote": 0, "to_order": 0, "awaiting_approval": 1}
    pend = d["purchase_orders"]["pending_approval"][0]
    assert pend["supplier"] == "Quick Supplier" and D(pend["amount"]) == 120000                      # shortage = 120 - 20 in stock = 100 bags x 1,200
    post(client, h, f"/purchase-orders/{po['id']}/approve")
    d = dash(client, proc, "procurement")
    assert D(d["purchase_orders"]["open_value_to_receive"]) == 120000 and d["purchase_orders"]["by_status"]["APPROVED"] == 1
    assert d["suppliers"]["top_by_committed"][0]["supplier"] == "Quick Supplier"


def test_accountant_dashboard(client):
    ctx = world(client)
    h, acct, A = ctx["h"], ctx["acct"], ctx["A"]
    post(client, acct, "/journal-entries", {"entry_date": T, "description": "Opening capital", "lines": [
        {"account_id": A["1010"], "debit": "500000"}, {"account_id": A["3000"], "credit": "500000"}]}, 201)
    po, s = received_po(client, ctx, "100", "1000", "100")
    bad = invoice(client, ctx, po, "120", "1000", "SI-120")
    good_po, _ = received_po(client, ctx, "10", "1000", "10", supplier="S2")
    inv = invoice(client, ctx, good_po, "10", "1000", "SI-OK", due=str(TODAY - timedelta(days=40)), date="2025-01-01")
    pay = post(client, acct, "/payments", {"supplier_id": good_po["supplier_id"], "account_id": A["1010"], "payment_date": T,
                                           "allocations": [{"invoice_id": inv["id"], "amount": "4000"}]}, 201)
    tbill.certify(client, ctx, tbill.mk_bill(client, ctx, tbill.milestone("200000"), bill_type="MILESTONE", due=str(TODAY + timedelta(days=5))))
    d = dash(client, acct, "accountant")
    assert D(d["cash"]["total"]) == 500000 and D(d["cash"]["month_to_date_in"]) == 500000 and D(d["cash"]["month_to_date_out"]) == 0
    assert d["invoice_exceptions"]["count"] == 1 and d["invoice_exceptions"]["items"][0]["problems"] == [
        "Invoice quantity exceeds received quantity by 20"]
    assert D(d["payables"]["total"]) == 10000 and D(d["payables"]["aging"]["d31_60"]) == 10000 and D(d["payables"]["overdue"]) == 10000
    assert D(d["receivables"]["total"]) == 190000 and D(d["receivables"]["aging"]["not_due"]) == 190000
    assert d["pending_approvals"]["supplier_payments"] == {"count": 1, "amount": "4000.00"}
    assert D(d["control_accounts"]["goods_received_not_invoiced"]) == 100000 + 0 and D(d["control_accounts"]["retention_receivable"]) == 10000
    assert d["ledger_check"]["balanced"] is True and d["ledger_check"]["total_debit"] == d["ledger_check"]["total_credit"]
    assert D(d["payables"]["total"]) == closing(client, h, A["2000"])                                   # sub-ledger == control account
    post(client, h, f"/payments/{pay['id']}/approve")
    d2 = dash(client, acct, "accountant")
    assert D(d2["cash"]["month_to_date_out"]) == 4000 and D(d2["payables"]["total"]) == 6000 and d2["pending_approvals"]["supplier_payments"]["count"] == 0


def test_dashboard_access_control_and_tenant_isolation(client):
    ctx = world(client)
    h = ctx["h"]
    assert client.get("/dashboards", headers=h).json() == {"available": ["ceo", "manager", "engineer", "store", "procurement", "accountant"], "default": "ceo"}
    expect = {"PROJECT_MANAGER": ("manager",), "SITE_ENGINEER": ("engineer",), "STOREKEEPER": ("store",),
              "PROCUREMENT_OFFICER": ("procurement",)}
    allnames = {"ceo", "manager", "engineer", "store", "procurement", "accountant"}
    for role, own in expect.items():
        who = ctx["u"][role]
        assert client.get("/dashboards", headers=who).json()["available"] == list(own)
        for name in allnames - set(own):
            assert client.get(f"/dashboards/{name}", headers=who).status_code == 403, (role, name)
    assert client.get("/dashboards", headers=ctx["acct"]).json()["default"] == "accountant"
    assert client.get("/dashboards/ceo", headers=ctx["acct"]).status_code == 403
    foreman = add_user(client, h, "fm@alpha.pk", "FOREMAN")
    assert client.get("/dashboards", headers=foreman).json() == {"available": [], "default": None}
    assert all(client.get(f"/dashboards/{n}", headers=foreman).status_code == 403 for n in allnames)
    assert client.get("/dashboards/ceo").status_code == 401
    received_po(client, ctx, "100", "1000", "100")
    hb = register(client, "Beta", "b@beta.pk")
    b = client.get("/dashboards/ceo", headers=hb).json()
    assert b["projects"]["total"] == 0 and b["project_table"] == [] and D(b["portfolio"]["actual_cost"]) == 0
    assert D(b["money"]["cash"]) == 0 and b["approvals"]["total_pending"] == 0 and b["attention"] == []
    assert client.get("/dashboards/accountant", headers=hb).status_code == 200
    assert client.get("/dashboards/store", headers=hb).json()["warehouses"] == []
