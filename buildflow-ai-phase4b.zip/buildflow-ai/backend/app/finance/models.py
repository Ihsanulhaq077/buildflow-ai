import enum
import uuid
from datetime import date, datetime
from decimal import Decimal

from sqlalchemy import Date, DateTime, Enum, ForeignKey, Numeric, String, UniqueConstraint, Uuid
from sqlalchemy.orm import Mapped, mapped_column

from app.models import Base, BaseMixin

MONEY = Numeric(18, 2)
QTY = Numeric(18, 4)


class InvoiceStatus(str, enum.Enum):
    MATCH_EXCEPTION = "MATCH_EXCEPTION"
    POSTED = "POSTED"
    PARTIALLY_PAID = "PARTIALLY_PAID"
    PAID = "PAID"
    REJECTED = "REJECTED"


class ApprovalState(str, enum.Enum):
    PENDING_APPROVAL = "PENDING_APPROVAL"
    APPROVED = "APPROVED"
    REJECTED = "REJECTED"
    CANCELLED = "CANCELLED"


class PayMethod(str, enum.Enum):
    CASH = "CASH"
    BANK_TRANSFER = "BANK_TRANSFER"
    CHEQUE = "CHEQUE"
    OTHER = "OTHER"


def _enum(e):
    return Enum(e, native_enum=False, length=24)


class SupplierInvoice(BaseMixin, Base):
    __tablename__ = "supplier_invoices"
    __table_args__ = (UniqueConstraint("organization_id", "supplier_id", "supplier_invoice_no"),
                      UniqueConstraint("organization_id", "number"))
    organization_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("organizations.id"), index=True)
    number: Mapped[str] = mapped_column(String(30))
    supplier_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("suppliers.id"), index=True)
    po_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("purchase_orders.id"), index=True)
    supplier_invoice_no: Mapped[str] = mapped_column(String(80))
    invoice_date: Mapped[date] = mapped_column(Date)
    due_date: Mapped[date] = mapped_column(Date)
    stated_total: Mapped[Decimal] = mapped_column(MONEY)          # what the supplier's document says
    total_amount: Mapped[Decimal] = mapped_column(MONEY)          # what the lines compute to
    paid_amount: Mapped[Decimal] = mapped_column(MONEY, default=Decimal("0"))
    status: Mapped[InvoiceStatus] = mapped_column(_enum(InvoiceStatus))
    created_by: Mapped[uuid.UUID | None] = mapped_column(Uuid, nullable=True)
    resolved_by: Mapped[uuid.UUID | None] = mapped_column(Uuid, nullable=True)
    resolution_comment: Mapped[str] = mapped_column(String(500), default="")
    journal_entry_id: Mapped[uuid.UUID | None] = mapped_column(Uuid, nullable=True)


class InvoiceLine(BaseMixin, Base):
    __tablename__ = "invoice_lines"
    organization_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("organizations.id"), index=True)
    invoice_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("supplier_invoices.id"), index=True)
    po_line_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("po_lines.id"), index=True)
    quantity: Mapped[Decimal] = mapped_column(QTY)
    unit_rate: Mapped[Decimal] = mapped_column(MONEY)
    amount: Mapped[Decimal] = mapped_column(MONEY)


class InvoiceException(BaseMixin, Base):
    __tablename__ = "invoice_exceptions"
    organization_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("organizations.id"), index=True)
    invoice_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("supplier_invoices.id"), index=True)
    type: Mapped[str] = mapped_column(String(30))      # QTY_EXCEEDS_RECEIVED | RATE_MISMATCH | TOTAL_MISMATCH
    po_line_id: Mapped[uuid.UUID | None] = mapped_column(Uuid, nullable=True)
    message: Mapped[str] = mapped_column(String(300))


class Payment(BaseMixin, Base):
    __tablename__ = "payments"
    __table_args__ = (UniqueConstraint("organization_id", "number"),)
    organization_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("organizations.id"), index=True)
    number: Mapped[str] = mapped_column(String(30))
    supplier_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("suppliers.id"), index=True)
    account_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("accounts.id"))
    amount: Mapped[Decimal] = mapped_column(MONEY)
    payment_date: Mapped[date] = mapped_column(Date)
    method: Mapped[PayMethod] = mapped_column(_enum(PayMethod), default=PayMethod.BANK_TRANSFER)
    reference: Mapped[str] = mapped_column(String(100), default="")
    status: Mapped[ApprovalState] = mapped_column(_enum(ApprovalState), default=ApprovalState.PENDING_APPROVAL)
    created_by: Mapped[uuid.UUID | None] = mapped_column(Uuid, nullable=True)
    decided_by: Mapped[uuid.UUID | None] = mapped_column(Uuid, nullable=True)
    decided_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    decision_comment: Mapped[str] = mapped_column(String(500), default="")
    journal_entry_id: Mapped[uuid.UUID | None] = mapped_column(Uuid, nullable=True)


class PaymentAllocation(BaseMixin, Base):
    __tablename__ = "payment_allocations"
    organization_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("organizations.id"), index=True)
    payment_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("payments.id"), index=True)
    invoice_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("supplier_invoices.id"), index=True)
    amount: Mapped[Decimal] = mapped_column(MONEY)


class Expense(BaseMixin, Base):
    __tablename__ = "expenses"
    __table_args__ = (UniqueConstraint("organization_id", "number"),)
    organization_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("organizations.id"), index=True)
    number: Mapped[str] = mapped_column(String(30))
    project_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("projects.id"), index=True)
    cost_code_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("cost_codes.id"))
    expense_date: Mapped[date] = mapped_column(Date)
    amount: Mapped[Decimal] = mapped_column(MONEY)
    payee: Mapped[str] = mapped_column(String(200), default="")
    description: Mapped[str] = mapped_column(String(500))
    paid_from_account_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("accounts.id"))
    status: Mapped[ApprovalState] = mapped_column(_enum(ApprovalState), default=ApprovalState.PENDING_APPROVAL)
    created_by: Mapped[uuid.UUID | None] = mapped_column(Uuid, nullable=True)
    decided_by: Mapped[uuid.UUID | None] = mapped_column(Uuid, nullable=True)
    decision_comment: Mapped[str] = mapped_column(String(500), default="")
    journal_entry_id: Mapped[uuid.UUID | None] = mapped_column(Uuid, nullable=True)
