"""Supplier invoices (three-way match), payments (approval-gated), project expenses, payables aging."""
import uuid
from datetime import date, datetime, timezone
from decimal import Decimal

from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.accounting import postings
from app.accounting import service as acc
from app.accounting.models import Account
from app.audit import log_action
from app.boq.models import CostCode
from app.budgets import service as budget_service
from app.db import get_db
from app.deps import get_owned, org_scoped, require_permission
from app.finance import matching
from app.finance.models import (ApprovalState, Expense, InvoiceException, InvoiceLine, InvoiceStatus, Payment,
                                PaymentAllocation, SupplierInvoice)
from app.finance.schemas import (DecisionIn, ExceptionOut, ExpenseIn, ExpenseOut, InvLineOut, InvoiceIn, InvoiceOut,
                                 PaymentIn, PaymentOut, AllocIn, RejectIn, ResolveIn)
from app.inventory.models import InventoryItem
from app.inventory.service import next_number
from app.models import User
from app.procurement.models import POLine, POStatus, PurchaseOrder, Supplier
from app.projects.models import Project
from app.timeutil import local_today

router = APIRouter(tags=["finance"])
READ = require_permission("finance.read")
MANAGE = require_permission("finance.manage")
APPROVE = require_permission("finance.approve")
EXP_CREATE = require_permission("expenses.create")
EXP_APPROVE = require_permission("expenses.approve")
OPEN = (InvoiceStatus.POSTED, InvoiceStatus.PARTIALLY_PAID)


def _perms(user: User) -> set[str]:
    return {p.code for p in user.role.permissions}


# ------------------------------------------------------------------ supplier invoices
def _inv_out(db, inv: SupplierInvoice) -> InvoiceOut:
    lines = db.scalars(select(InvoiceLine).where(InvoiceLine.invoice_id == inv.id).order_by(InvoiceLine.created_at))
    exc = db.scalars(select(InvoiceException).where(InvoiceException.invoice_id == inv.id).order_by(InvoiceException.created_at))
    return InvoiceOut(
        id=inv.id, number=inv.number, supplier_id=inv.supplier_id, po_id=inv.po_id,
        supplier_invoice_no=inv.supplier_invoice_no, invoice_date=inv.invoice_date, due_date=inv.due_date,
        stated_total=inv.stated_total, total_amount=inv.total_amount, paid_amount=inv.paid_amount,
        outstanding=inv.total_amount - inv.paid_amount if inv.status in OPEN else Decimal("0"), status=inv.status,
        resolution_comment=inv.resolution_comment, lines=[InvLineOut.model_validate(l) for l in lines],
        exceptions=[ExceptionOut.model_validate(e) for e in exc])


def _line_cost_code(db, po_line: POLine):
    cc = db.get(InventoryItem, po_line.item_id).cost_code_id
    if not cc:
        raise HTTPException(422, "PO item has no cost code")
    return cc


def _post_invoice(db, user, inv: SupplierInvoice, lines: list[InvoiceLine], po_lines: dict) -> None:
    """Dr GRNI (at PO rate) [+/- Dr/Cr project cost for rate variance] / Cr Accounts Payable (at invoice amount)."""
    po = db.get(PurchaseOrder, inv.po_id)
    accounts = acc.ensure_accounts(db, user.organization_id)
    relief, variance_pairs = Decimal("0"), []
    for l in lines:
        pl = po_lines[l.po_line_id]
        po_amount = acc.q2(l.quantity * pl.unit_rate)
        relief += po_amount
        if l.amount != po_amount:
            variance_pairs.append((_line_cost_code(db, pl), l.amount - po_amount))
    jl = [{"account_id": accounts["2100"].id, "debit": relief, "project_id": po.project_id, "supplier_id": inv.supplier_id}]
    if variance_pairs:
        jl += postings.cost_debit_lines(db, user.organization_id, po.project_id, variance_pairs)
        budget_service.record_direct_cost(db, user.organization_id, po.project_id, budget_service.group(variance_pairs))
    jl.append({"account_id": accounts["2000"].id, "credit": inv.total_amount, "supplier_id": inv.supplier_id,
               "project_id": po.project_id, "memo": inv.supplier_invoice_no})
    e = acc.post_entry(db, org_id=user.organization_id, user_id=user.id, entry_date=inv.invoice_date,
                       description=f"Supplier invoice {inv.supplier_invoice_no} ({inv.number})", lines=jl,
                       source_type="INVOICE", source_id=inv.id)
    inv.journal_entry_id, inv.status = e.id, InvoiceStatus.POSTED


@router.post("/supplier-invoices", response_model=InvoiceOut, status_code=201)
def create_invoice(body: InvoiceIn, request: Request, user: User = Depends(MANAGE), db: Session = Depends(get_db)):
    po = get_owned(db, PurchaseOrder, body.po_id, user, code=422)
    if po.status not in (POStatus.APPROVED, POStatus.PARTIALLY_RECEIVED, POStatus.RECEIVED):
        raise HTTPException(409, f"PO is {po.status.value}; invoices can only be matched to approved POs")
    po_lines = {l.id: l for l in db.scalars(select(POLine).where(POLine.po_id == po.id))}
    ids = [l.po_line_id for l in body.lines]
    if len(set(ids)) != len(ids) or any(i not in po_lines for i in ids):
        raise HTTPException(422, "Lines must be unique and belong to the PO")
    if body.due_date < body.invoice_date:
        raise HTTPException(422, "due_date cannot be before invoice_date")
    if db.scalar(org_scoped(SupplierInvoice, user).where(SupplierInvoice.supplier_id == po.supplier_id,
                                                         SupplierInvoice.supplier_invoice_no == body.supplier_invoice_no)):
        raise HTTPException(409, "This supplier invoice number was already entered (duplicate invoice)")
    excs = matching.run_match(db, user.organization_id, po_lines, body.lines, body.stated_total)
    total = sum((acc.q2(l.quantity * l.unit_rate) for l in body.lines), Decimal("0"))
    inv = SupplierInvoice(organization_id=user.organization_id, number=next_number(db, SupplierInvoice, user.organization_id, "INV"),
                          supplier_id=po.supplier_id, po_id=po.id, supplier_invoice_no=body.supplier_invoice_no,
                          invoice_date=body.invoice_date, due_date=body.due_date, stated_total=body.stated_total,
                          total_amount=total, status=InvoiceStatus.MATCH_EXCEPTION, created_by=user.id)
    db.add(inv)
    try:
        db.flush()
        lines = []
        for l in body.lines:
            row = InvoiceLine(organization_id=user.organization_id, invoice_id=inv.id, po_line_id=l.po_line_id,
                              quantity=l.quantity, unit_rate=l.unit_rate, amount=acc.q2(l.quantity * l.unit_rate))
            db.add(row)
            lines.append(row)
        for e in excs:
            db.add(InvoiceException(organization_id=user.organization_id, invoice_id=inv.id, **e))
        if not excs:
            _post_invoice(db, user, inv, lines, po_lines)
        db.commit()
    except HTTPException:
        db.rollback()
        raise
    except IntegrityError:
        db.rollback()
        raise HTTPException(409, "This supplier invoice number was already entered (duplicate invoice)")
    log_action(db, action="invoice.create", org_id=user.organization_id, user_id=user.id, entity="supplier_invoice",
               entity_id=inv.id, request=request, detail={"status": inv.status.value, "exceptions": [e["type"] for e in excs]})
    return _inv_out(db, inv)


@router.get("/supplier-invoices", response_model=list[InvoiceOut])
def list_invoices(status: InvoiceStatus | None = None, supplier_id: uuid.UUID | None = None, limit: int = 100,
                  user: User = Depends(READ), db: Session = Depends(get_db)):
    q = org_scoped(SupplierInvoice, user)
    if status:
        q = q.where(SupplierInvoice.status == status)
    if supplier_id:
        q = q.where(SupplierInvoice.supplier_id == supplier_id)
    return [_inv_out(db, i) for i in db.scalars(q.order_by(SupplierInvoice.created_at.desc()).limit(min(limit, 200)))]


@router.get("/supplier-invoices/{invoice_id}", response_model=InvoiceOut)
def get_invoice(invoice_id: uuid.UUID, user: User = Depends(READ), db: Session = Depends(get_db)):
    return _inv_out(db, get_owned(db, SupplierInvoice, invoice_id, user))


@router.post("/supplier-invoices/{invoice_id}/resolve", response_model=InvoiceOut)
def resolve_invoice(invoice_id: uuid.UUID, body: ResolveIn, request: Request, user: User = Depends(APPROVE),
                    db: Session = Depends(get_db)):
    inv = get_owned(db, SupplierInvoice, invoice_id, user)
    if inv.status != InvoiceStatus.MATCH_EXCEPTION:
        raise HTTPException(409, f"Invoice is {inv.status.value}; only invoices with match exceptions can be resolved")
    inv.resolved_by, inv.resolution_comment = user.id, body.comment
    if body.action == "REJECT":
        inv.status = InvoiceStatus.REJECTED
    else:
        types = {e.type for e in db.scalars(select(InvoiceException).where(InvoiceException.invoice_id == inv.id))}
        if types - {"RATE_MISMATCH"}:
            raise HTTPException(409, "Only rate differences can be accepted. Quantity/total mismatches must be "
                                     "corrected (receive the goods or get a corrected invoice) or rejected")
        po_lines = {l.id: l for l in db.scalars(select(POLine).where(POLine.po_id == inv.po_id))}
        lines = list(db.scalars(select(InvoiceLine).where(InvoiceLine.invoice_id == inv.id)))
        try:
            _post_invoice(db, user, inv, lines, po_lines)
        except HTTPException:
            db.rollback()
            raise
    db.commit()
    log_action(db, action=f"invoice.{body.action.lower()}", org_id=user.organization_id, user_id=user.id,
               entity="supplier_invoice", entity_id=inv.id, request=request, detail={"comment": body.comment})
    return _inv_out(db, inv)


# ------------------------------------------------------------------ payments
def _pending_reserved(db, org_id, invoice_id, exclude_payment_id=None) -> Decimal:
    q = (select(func.coalesce(func.sum(PaymentAllocation.amount), 0)).join(Payment, Payment.id == PaymentAllocation.payment_id)
         .where(PaymentAllocation.organization_id == org_id, PaymentAllocation.invoice_id == invoice_id,
                Payment.status == ApprovalState.PENDING_APPROVAL))
    if exclude_payment_id:
        q = q.where(Payment.id != exclude_payment_id)
    return Decimal(db.scalar(q))


def _pay_out(db, p: Payment) -> PaymentOut:
    al = db.scalars(select(PaymentAllocation).where(PaymentAllocation.payment_id == p.id).order_by(PaymentAllocation.created_at))
    return PaymentOut(id=p.id, number=p.number, supplier_id=p.supplier_id, account_id=p.account_id, amount=p.amount,
                      payment_date=p.payment_date, method=p.method, reference=p.reference, status=p.status,
                      decision_comment=p.decision_comment,
                      allocations=[AllocIn(invoice_id=a.invoice_id, amount=a.amount) for a in al])


def _check_allocations(db, user, supplier_id, allocs: list[tuple[uuid.UUID, Decimal]], exclude_payment_id=None):
    seen = set()
    for inv_id, amt in allocs:
        if inv_id in seen:
            raise HTTPException(422, "An invoice can appear once per payment")
        seen.add(inv_id)
        inv = get_owned(db, SupplierInvoice, inv_id, user, code=422)
        if inv.supplier_id != supplier_id:
            raise HTTPException(422, f"Invoice {inv.number} belongs to a different supplier")
        if inv.status not in OPEN:
            raise HTTPException(409, f"Invoice {inv.number} is {inv.status.value}; only matched/posted invoices can be paid")
        available = inv.total_amount - inv.paid_amount - _pending_reserved(db, user.organization_id, inv.id, exclude_payment_id)
        if amt > available:
            raise HTTPException(409, f"Payment of {amt} exceeds the outstanding amount of invoice {inv.number} ({available})")


@router.post("/payments", response_model=PaymentOut, status_code=201)
def create_payment(body: PaymentIn, request: Request, user: User = Depends(MANAGE), db: Session = Depends(get_db)):
    supplier = get_owned(db, Supplier, body.supplier_id, user, code=422)
    acc.ensure_accounts(db, user.organization_id)
    account = get_owned(db, Account, body.account_id, user, code=422)
    if not account.is_cash:
        raise HTTPException(422, "Payments must be made from a cash or bank account")
    _check_allocations(db, user, supplier.id, [(a.invoice_id, a.amount) for a in body.allocations])
    p = Payment(organization_id=user.organization_id, number=next_number(db, Payment, user.organization_id, "PAY"),
                supplier_id=supplier.id, account_id=account.id, amount=sum((a.amount for a in body.allocations), Decimal("0")),
                payment_date=body.payment_date, method=body.method, reference=body.reference, created_by=user.id)
    db.add(p)
    db.flush()
    for a in body.allocations:
        db.add(PaymentAllocation(organization_id=user.organization_id, payment_id=p.id, invoice_id=a.invoice_id, amount=a.amount))
    db.commit()
    log_action(db, action="payment.create", org_id=user.organization_id, user_id=user.id, entity="payment",
               entity_id=p.id, request=request, detail={"amount": str(p.amount)})
    return _pay_out(db, p)


@router.get("/payments", response_model=list[PaymentOut])
def list_payments(status: ApprovalState | None = None, supplier_id: uuid.UUID | None = None, limit: int = 100,
                  user: User = Depends(READ), db: Session = Depends(get_db)):
    q = org_scoped(Payment, user)
    if status:
        q = q.where(Payment.status == status)
    if supplier_id:
        q = q.where(Payment.supplier_id == supplier_id)
    return [_pay_out(db, p) for p in db.scalars(q.order_by(Payment.created_at.desc()).limit(min(limit, 200)))]


@router.get("/payments/{payment_id}", response_model=PaymentOut)
def get_payment(payment_id: uuid.UUID, user: User = Depends(READ), db: Session = Depends(get_db)):
    return _pay_out(db, get_owned(db, Payment, payment_id, user))


def _pending(p: Payment):
    if p.status != ApprovalState.PENDING_APPROVAL:
        raise HTTPException(409, f"Payment is {p.status.value}; expected PENDING_APPROVAL")


@router.post("/payments/{payment_id}/approve", response_model=PaymentOut)
def approve_payment(payment_id: uuid.UUID, body: DecisionIn, request: Request, user: User = Depends(APPROVE),
                    db: Session = Depends(get_db)):
    p = get_owned(db, Payment, payment_id, user)
    _pending(p)
    if p.created_by == user.id:
        raise HTTPException(403, "A payment cannot be approved by the person who created it")
    if p.amount > user.role.approval_limit:
        raise HTTPException(403, f"Payment of {p.amount} exceeds your approval limit ({user.role.approval_limit})")
    allocs = list(db.scalars(select(PaymentAllocation).where(PaymentAllocation.payment_id == p.id)))
    try:
        _check_allocations(db, user, p.supplier_id, [(a.invoice_id, a.amount) for a in allocs], exclude_payment_id=p.id)
        accounts = acc.ensure_accounts(db, user.organization_id)
        paid_by_cc: dict[uuid.UUID, Decimal] = {}
        project_of: dict[uuid.UUID, uuid.UUID] = {}
        for a in allocs:
            inv = db.get(SupplierInvoice, a.invoice_id)
            po = db.get(PurchaseOrder, inv.po_id)
            lines = list(db.scalars(select(InvoiceLine).where(InvoiceLine.invoice_id == inv.id)))
            weights: dict[uuid.UUID, Decimal] = {}
            for l in lines:
                cc = _line_cost_code(db, db.get(POLine, l.po_line_id))
                weights[cc] = weights.get(cc, Decimal("0")) + l.amount
            for cc, share in acc.allocate_pro_rata(a.amount, weights).items():
                paid_by_cc.setdefault(po.project_id, {})
                paid_by_cc[po.project_id][cc] = paid_by_cc[po.project_id].get(cc, Decimal("0")) + share
            inv.paid_amount += a.amount
            inv.status = InvoiceStatus.PAID if inv.paid_amount == inv.total_amount else InvoiceStatus.PARTIALLY_PAID
        for project_id, amounts in paid_by_cc.items():
            budget_service.record_paid(db, user.organization_id, project_id, amounts)
        e = acc.post_entry(db, org_id=user.organization_id, user_id=user.id, entry_date=p.payment_date,
                           description=f"Payment {p.number}", source_type="PAYMENT", source_id=p.id, lines=[
                               {"account_id": accounts["2000"].id, "debit": p.amount, "supplier_id": p.supplier_id},
                               {"account_id": p.account_id, "credit": p.amount, "supplier_id": p.supplier_id,
                                "memo": p.reference}])
        p.status, p.decided_by, p.decided_at, p.decision_comment = (ApprovalState.APPROVED, user.id,
                                                                    datetime.now(timezone.utc), body.comment)
        p.journal_entry_id = e.id
        db.commit()
    except HTTPException:
        db.rollback()
        raise
    log_action(db, action="payment.approve", org_id=user.organization_id, user_id=user.id, entity="payment",
               entity_id=p.id, request=request, detail={"amount": str(p.amount), "number": p.number})
    return _pay_out(db, p)


@router.post("/payments/{payment_id}/reject", response_model=PaymentOut)
def reject_payment(payment_id: uuid.UUID, body: RejectIn, request: Request, user: User = Depends(APPROVE),
                   db: Session = Depends(get_db)):
    p = get_owned(db, Payment, payment_id, user)
    _pending(p)
    p.status, p.decided_by, p.decided_at, p.decision_comment = (ApprovalState.REJECTED, user.id,
                                                                datetime.now(timezone.utc), body.comment)
    db.commit()
    log_action(db, action="payment.reject", org_id=user.organization_id, user_id=user.id, entity="payment",
               entity_id=p.id, request=request, detail={"comment": body.comment})
    return _pay_out(db, p)


@router.post("/payments/{payment_id}/cancel", response_model=PaymentOut)
def cancel_payment(payment_id: uuid.UUID, request: Request, user: User = Depends(MANAGE), db: Session = Depends(get_db)):
    p = get_owned(db, Payment, payment_id, user)
    _pending(p)
    p.status = ApprovalState.CANCELLED
    db.commit()
    log_action(db, action="payment.cancel", org_id=user.organization_id, user_id=user.id, entity="payment",
               entity_id=p.id, request=request)
    return _pay_out(db, p)


# ------------------------------------------------------------------ project expenses
def _check_expense_refs(db, user, body: ExpenseIn):
    get_owned(db, Project, body.project_id, user, code=422)
    get_owned(db, CostCode, body.cost_code_id, user, code=422)
    acc.ensure_accounts(db, user.organization_id)
    a = get_owned(db, Account, body.paid_from_account_id, user, code=422)
    if not a.is_cash:
        raise HTTPException(422, "Expenses must be paid from a cash or bank account")


@router.post("/expenses", response_model=ExpenseOut, status_code=201)
def create_expense(body: ExpenseIn, request: Request, user: User = Depends(EXP_CREATE), db: Session = Depends(get_db)):
    _check_expense_refs(db, user, body)
    x = Expense(organization_id=user.organization_id, number=next_number(db, Expense, user.organization_id, "EXP"),
                created_by=user.id, **body.model_dump())
    db.add(x)
    db.commit()
    log_action(db, action="expense.create", org_id=user.organization_id, user_id=user.id, entity="expense",
               entity_id=x.id, request=request, detail={"amount": str(x.amount)})
    return x


@router.get("/expenses", response_model=list[ExpenseOut])
def list_expenses(project_id: uuid.UUID | None = None, status: ApprovalState | None = None, limit: int = 100,
                  user: User = Depends(READ), db: Session = Depends(get_db)):
    q = org_scoped(Expense, user)
    if project_id:
        q = q.where(Expense.project_id == project_id)
    if status:
        q = q.where(Expense.status == status)
    return db.scalars(q.order_by(Expense.created_at.desc()).limit(min(limit, 200))).all()


def _exp_pending(x: Expense):
    if x.status != ApprovalState.PENDING_APPROVAL:
        raise HTTPException(409, f"Expense is {x.status.value}; expected PENDING_APPROVAL")


@router.post("/expenses/{expense_id}/approve", response_model=ExpenseOut)
def approve_expense(expense_id: uuid.UUID, body: DecisionIn, request: Request, user: User = Depends(EXP_APPROVE),
                    db: Session = Depends(get_db)):
    x = get_owned(db, Expense, expense_id, user)
    _exp_pending(x)
    if x.amount > user.role.approval_limit:
        raise HTTPException(403, f"Expense of {x.amount} exceeds your approval limit ({user.role.approval_limit})")
    try:
        pairs = {x.cost_code_id: x.amount}
        budget_service.record_direct_cost(db, user.organization_id, x.project_id, pairs)   # committed + actual
        budget_service.record_paid(db, user.organization_id, x.project_id, pairs)           # paid immediately
        debit = postings.cost_debit_lines(db, user.organization_id, x.project_id, list(pairs.items()))
        e = acc.post_entry(db, org_id=user.organization_id, user_id=user.id, entry_date=x.expense_date,
                           description=f"Expense {x.number}: {x.description}", source_type="EXPENSE", source_id=x.id,
                           lines=debit + [{"account_id": x.paid_from_account_id, "credit": x.amount,
                                           "project_id": x.project_id, "memo": x.payee}])
        x.status, x.decided_by, x.decision_comment, x.journal_entry_id = ApprovalState.APPROVED, user.id, body.comment, e.id
        db.commit()
    except HTTPException:
        db.rollback()
        raise
    log_action(db, action="expense.approve", org_id=user.organization_id, user_id=user.id, entity="expense",
               entity_id=x.id, request=request, detail={"amount": str(x.amount)})
    return x


@router.post("/expenses/{expense_id}/reject", response_model=ExpenseOut)
def reject_expense(expense_id: uuid.UUID, body: RejectIn, request: Request, user: User = Depends(EXP_APPROVE),
                   db: Session = Depends(get_db)):
    x = get_owned(db, Expense, expense_id, user)
    _exp_pending(x)
    x.status, x.decided_by, x.decision_comment = ApprovalState.REJECTED, user.id, body.comment
    db.commit()
    log_action(db, action="expense.reject", org_id=user.organization_id, user_id=user.id, entity="expense",
               entity_id=x.id, request=request, detail={"comment": body.comment})
    return x


@router.post("/expenses/{expense_id}/cancel", response_model=ExpenseOut)
def cancel_expense(expense_id: uuid.UUID, request: Request, user: User = Depends(EXP_CREATE), db: Session = Depends(get_db)):
    x = get_owned(db, Expense, expense_id, user)
    _exp_pending(x)
    if x.created_by != user.id and "expenses.approve" not in _perms(user):
        raise HTTPException(403, "Only the creator or an approver can cancel")
    x.status = ApprovalState.CANCELLED
    db.commit()
    log_action(db, action="expense.cancel", org_id=user.organization_id, user_id=user.id, entity="expense",
               entity_id=x.id, request=request)
    return x


# ------------------------------------------------------------------ payables aging
@router.get("/reports/payables-aging")
def payables_aging(as_of: date | None = None, user: User = Depends(READ), db: Session = Depends(get_db)):
    as_of = as_of or local_today()
    suppliers = {s.id: s for s in db.scalars(org_scoped(Supplier, user))}
    buckets = ("not_due", "d1_30", "d31_60", "d61_90", "d90_plus")
    rows: dict[uuid.UUID, dict] = {}
    for inv in db.scalars(org_scoped(SupplierInvoice, user).where(SupplierInvoice.status.in_(OPEN))):
        out = inv.total_amount - inv.paid_amount
        late = (as_of - inv.due_date).days
        b = buckets[0] if late <= 0 else buckets[1] if late <= 30 else buckets[2] if late <= 60 else buckets[3] if late <= 90 else buckets[4]
        r = rows.setdefault(inv.supplier_id, {"supplier_id": str(inv.supplier_id), "supplier": suppliers[inv.supplier_id].name,
                                              **{k: Decimal("0") for k in buckets}, "total": Decimal("0")})
        r[b] += out
        r["total"] += out
    fmt = [{k: (str(v) if isinstance(v, Decimal) else v) for k, v in r.items()} for r in sorted(rows.values(), key=lambda r: r["supplier"])]
    tot = {k: str(sum((Decimal(r[k]) for r in fmt), Decimal("0"))) for k in (*buckets, "total")}
    return {"as_of": str(as_of), "suppliers": fmt, "totals": tot}
