import uuid
from datetime import date
from decimal import Decimal
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

from app.finance.models import ApprovalState, InvoiceStatus, PayMethod

AMT = dict(gt=0, max_digits=18, decimal_places=2)
RATE = dict(ge=0, max_digits=18, decimal_places=2)
QTY = dict(gt=0, max_digits=18, decimal_places=4)


class InvLineIn(BaseModel):
    po_line_id: uuid.UUID
    quantity: Decimal = Field(**QTY)
    unit_rate: Decimal = Field(**RATE)


class InvoiceIn(BaseModel):
    po_id: uuid.UUID
    supplier_invoice_no: str = Field(min_length=1, max_length=80)
    invoice_date: date
    due_date: date
    stated_total: Decimal = Field(ge=0, max_digits=18, decimal_places=2)
    lines: list[InvLineIn] = Field(min_length=1, max_length=100)


class ResolveIn(BaseModel):
    action: Literal["ACCEPT", "REJECT"]
    comment: str = Field(min_length=3, max_length=500)


class InvLineOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    po_line_id: uuid.UUID
    quantity: Decimal
    unit_rate: Decimal
    amount: Decimal


class ExceptionOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    type: str
    po_line_id: uuid.UUID | None
    message: str


class InvoiceOut(BaseModel):
    id: uuid.UUID
    number: str
    supplier_id: uuid.UUID
    po_id: uuid.UUID
    supplier_invoice_no: str
    invoice_date: date
    due_date: date
    stated_total: Decimal
    total_amount: Decimal
    paid_amount: Decimal
    outstanding: Decimal
    status: InvoiceStatus
    resolution_comment: str
    lines: list[InvLineOut]
    exceptions: list[ExceptionOut]


class AllocIn(BaseModel):
    invoice_id: uuid.UUID
    amount: Decimal = Field(**AMT)


class PaymentIn(BaseModel):
    supplier_id: uuid.UUID
    account_id: uuid.UUID
    payment_date: date
    method: PayMethod = PayMethod.BANK_TRANSFER
    reference: str = Field(default="", max_length=100)
    allocations: list[AllocIn] = Field(min_length=1, max_length=50)


class DecisionIn(BaseModel):
    comment: str = Field(default="", max_length=500)


class RejectIn(BaseModel):
    comment: str = Field(min_length=3, max_length=500)


class PaymentOut(BaseModel):
    id: uuid.UUID
    number: str
    supplier_id: uuid.UUID
    account_id: uuid.UUID
    amount: Decimal
    payment_date: date
    method: PayMethod
    reference: str
    status: ApprovalState
    decision_comment: str
    allocations: list[AllocIn]


class ExpenseIn(BaseModel):
    project_id: uuid.UUID
    cost_code_id: uuid.UUID
    expense_date: date
    amount: Decimal = Field(**AMT)
    payee: str = Field(default="", max_length=200)
    description: str = Field(min_length=3, max_length=500)
    paid_from_account_id: uuid.UUID


class ExpenseOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    number: str
    project_id: uuid.UUID
    cost_code_id: uuid.UUID
    expense_date: date
    amount: Decimal
    payee: str
    description: str
    paid_from_account_id: uuid.UUID
    status: ApprovalState
    decision_comment: str
