"""Three-way match: PO x GRN (accepted quantity) x supplier invoice. Deterministic; any mismatch is an exception.
Nothing here pays anything."""
from decimal import Decimal

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.accounting.service import q2
from app.finance.models import InvoiceLine, InvoiceStatus, SupplierInvoice
from app.procurement.models import POLine

COUNTED = (InvoiceStatus.POSTED, InvoiceStatus.PARTIALLY_PAID, InvoiceStatus.PAID)


def already_invoiced(db: Session, org_id, po_line_id, exclude_invoice_id=None) -> Decimal:
    q = (select(func.coalesce(func.sum(InvoiceLine.quantity), 0))
         .join(SupplierInvoice, SupplierInvoice.id == InvoiceLine.invoice_id)
         .where(InvoiceLine.organization_id == org_id, InvoiceLine.po_line_id == po_line_id,
                SupplierInvoice.status.in_(COUNTED)))
    if exclude_invoice_id:
        q = q.where(SupplierInvoice.id != exclude_invoice_id)
    return Decimal(db.scalar(q))


def run_match(db: Session, org_id, po_lines: dict, lines, stated_total: Decimal, exclude_invoice_id=None) -> list[dict]:
    """lines: objects with po_line_id, quantity, unit_rate. Returns exception dicts (empty list = clean match)."""
    exceptions, total = [], Decimal("0")
    for l in lines:
        pl: POLine = po_lines[l.po_line_id]
        total += q2(l.quantity * l.unit_rate)
        allowed = pl.received_qty - already_invoiced(db, org_id, pl.id, exclude_invoice_id)
        if l.quantity > allowed:
            over = l.quantity - max(allowed, Decimal("0"))
            exceptions.append({"type": "QTY_EXCEEDS_RECEIVED", "po_line_id": pl.id,
                               "message": f"Invoice quantity exceeds received quantity by {over.normalize():f}"})
        if l.unit_rate != pl.unit_rate:
            exceptions.append({"type": "RATE_MISMATCH", "po_line_id": pl.id,
                               "message": f"Invoice rate {l.unit_rate} differs from PO rate {pl.unit_rate}"})
    if total != stated_total:
        exceptions.append({"type": "TOTAL_MISMATCH", "po_line_id": None,
                           "message": f"Stated total {stated_total} differs from the sum of lines {total}"})
    return exceptions
