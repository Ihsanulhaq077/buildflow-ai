"""Deterministic client-billing maths (Decimal only).
amount(line) = this-bill quantity x contract rate;  gross = sum(lines)
retention = gross x retention%;  net payable = gross - retention - deductions."""
from decimal import Decimal

from app.boq.calculations import q2


def line_amount(quantity: Decimal, rate: Decimal) -> Decimal:
    return q2(quantity * rate)


def bill_totals(gross: Decimal, retention_pct: Decimal, deductions: list[Decimal]) -> dict:
    retention = q2(gross * retention_pct / Decimal("100"))
    ded = sum(deductions, Decimal("0"))
    return {"gross": gross, "retention": retention, "deductions": ded, "net": gross - retention - ded}


def default_contract_rate(unit_rate: Decimal, selling_price: Decimal, direct_cost: Decimal) -> Decimal:
    """Contract rate when none is stated: BOQ unit cost rate marked up by the BOQ's own selling/direct ratio."""
    factor = selling_price / direct_cost if direct_cost else Decimal("1")
    return q2(unit_rate * factor)
