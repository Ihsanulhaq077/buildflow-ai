from io import BytesIO
from xml.sax.saxutils import escape

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle


def build_certificate(*, org_name: str, project: str, client: str, bill: dict) -> bytes:
    ss = getSampleStyleSheet()
    body = ParagraphStyle("b", parent=ss["BodyText"], fontSize=9.5, leading=12)
    P = lambda t: Paragraph(escape(str(t)), body)  # noqa: E731

    def table(rows, widths, right_from=None):
        t = Table(rows, colWidths=widths, repeatRows=1)
        st = [("GRID", (0, 0), (-1, -1), 0.4, colors.grey), ("FONTSIZE", (0, 0), (-1, -1), 9),
              ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#e8eef6")), ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold")]
        if right_from is not None:
            st.append(("ALIGN", (right_from, 0), (-1, -1), "RIGHT"))
        t.setStyle(TableStyle(st))
        return t

    buf = BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, leftMargin=18 * mm, rightMargin=18 * mm, topMargin=16 * mm, bottomMargin=16 * mm,
                            title=f"Payment Certificate {bill['certificate_no']}", author=org_name)
    story = [Paragraph(escape(org_name), ss["Title"]), Paragraph("Payment Certificate", ss["Heading3"]),
             table([["Certificate no.", bill["certificate_no"]], ["Bill", f"{bill['number']} (bill no. {bill['bill_no']}, {bill['bill_type']})"],
                    ["Project", project], ["Client", client], ["Bill date", bill["bill_date"]], ["Due date", bill["due_date"]]],
                   [40 * mm, 130 * mm]), Spacer(1, 6 * mm)]
    rows = [["Description", "Prev. qty", "Cum. qty", "This bill", "Rate", "Amount"]]
    for l in bill["lines"]:
        rows.append([Paragraph(escape(l["description"]), body), l["previous_quantity"] or "-", l["cumulative_quantity"] or "-",
                     l["quantity"] or "-", l["contract_rate"] or "-", l["amount"]])
    story.append(table(rows, [62 * mm, 20 * mm, 22 * mm, 22 * mm, 22 * mm, 22 * mm], right_from=1))
    story.append(Spacer(1, 5 * mm))
    summ = [["Gross value of work this bill", bill["gross_amount"]],
            [f"Less retention ({bill['retention_pct']}%)", f"-{bill['retention_amount']}"]]
    for d in bill["deductions"]:
        summ.append([f"Less {d['type'].replace('_', ' ').title()}: {d['description']}".strip(": "), f"-{d['amount']}"])
    summ.append(["NET PAYABLE (PKR)", bill["net_payable"]])
    t = Table(summ, colWidths=[120 * mm, 50 * mm])
    t.setStyle(TableStyle([("FONTSIZE", (0, 0), (-1, -1), 10), ("ALIGN", (1, 0), (1, -1), "RIGHT"), ("LINEABOVE", (0, -1), (-1, -1), 0.8, colors.black),
                           ("FONTNAME", (0, -1), (-1, -1), "Helvetica-Bold")]))
    story += [t, Spacer(1, 22 * mm), table([["Certified by (Contractor)", "Accepted by (Client)"], ["\n\n", "\n\n"]], [85 * mm, 85 * mm])]
    doc.build(story)
    return buf.getvalue()
