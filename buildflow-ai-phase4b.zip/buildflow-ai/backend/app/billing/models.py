import enum
import uuid
from datetime import date, datetime
from decimal import Decimal

from sqlalchemy import Date, DateTime, Enum, ForeignKey, Integer, Numeric, String, Text, UniqueConstraint, Uuid
from sqlalchemy.orm import Mapped, mapped_column

from app.finance.models import ApprovalState, PayMethod
from app.models import Base, BaseMixin

MONEY = Numeric(18, 2)
QTY = Numeric(18, 4)


def _enum(e):
    return Enum(e, native_enum=False, length=24)


class BillType(str, enum.Enum):
    RUNNING = "RUNNING"        # cumulative measured quantities against BOQ items
    MILESTONE = "MILESTONE"    # fixed amounts for completed milestones


class BillStatus(str, enum.Enum):
    DRAFT = "DRAFT"
    PENDING_APPROVAL = "PENDING_APPROVAL"
    APPROVED = "APPROVED"      # certified: a receivable exists
    PARTIALLY_PAID = "PARTIALLY_PAID"
    PAID = "PAID"
    REJECTED = "REJECTED"
    CANCELLED = "CANCELLED"


BILLED = (BillStatus.APPROVED, BillStatus.PARTIALLY_PAID, BillStatus.PAID)
OPEN_BILLS = (BillStatus.DRAFT, BillStatus.PENDING_APPROVAL)
RECEIVABLE = (BillStatus.APPROVED, BillStatus.PARTIALLY_PAID)


class DeductionType(str, enum.Enum):
    ADVANCE_RECOVERY = "ADVANCE_RECOVERY"
    TAX_WITHHELD = "TAX_WITHHELD"     # amount as stated by the client; tax rules are not computed here
    PENALTY = "PENALTY"
    OTHER = "OTHER"


class ReceiptKind(str, enum.Enum):
    PAYMENT = "PAYMENT"                       # settles certified bills
    ADVANCE = "ADVANCE"                       # mobilisation advance, recovered through bill deductions
    RETENTION_RELEASE = "RETENTION_RELEASE"   # client releases held retention


class VariationStatus(str, enum.Enum):
    PENDING_APPROVAL = "PENDING_APPROVAL"
    APPROVED = "APPROVED"
    REJECTED = "REJECTED"


class ClientVariation(BaseMixin, Base):
    __tablename__ = "client_variations"
    __table_args__ = (UniqueConstraint("organization_id", "number"),)
    organization_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("organizations.id"), index=True)
    number: Mapped[str] = mapped_column(String(30))
    project_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("projects.id"), index=True)
    title: Mapped[str] = mapped_column(String(200))
    description: Mapped[str] = mapped_column(Text, default="")
    amount: Mapped[Decimal] = mapped_column(MONEY)          # + adds to contract value, - omits work
    status: Mapped[VariationStatus] = mapped_column(_enum(VariationStatus), default=VariationStatus.PENDING_APPROVAL)
    created_by: Mapped[uuid.UUID | None] = mapped_column(Uuid, nullable=True)
    decided_by: Mapped[uuid.UUID | None] = mapped_column(Uuid, nullable=True)
    decision_comment: Mapped[str] = mapped_column(String(500), default="")


class ClientBill(BaseMixin, Base):
    __tablename__ = "client_bills"
    __table_args__ = (UniqueConstraint("organization_id", "number"),)
    organization_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("organizations.id"), index=True)
    number: Mapped[str] = mapped_column(String(30))
    project_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("projects.id"), index=True)
    client_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("clients.id"), index=True)
    bill_type: Mapped[BillType] = mapped_column(_enum(BillType))
    bill_no: Mapped[int] = mapped_column(Integer)               # sequence within the project
    bill_date: Mapped[date] = mapped_column(Date)
    due_date: Mapped[date] = mapped_column(Date)
    status: Mapped[BillStatus] = mapped_column(_enum(BillStatus), default=BillStatus.DRAFT)
    gross_amount: Mapped[Decimal] = mapped_column(MONEY, default=Decimal("0"))
    retention_pct: Mapped[Decimal] = mapped_column(Numeric(6, 2), default=Decimal("0"))   # snapshot from the contract
    retention_amount: Mapped[Decimal] = mapped_column(MONEY, default=Decimal("0"))
    deductions_total: Mapped[Decimal] = mapped_column(MONEY, default=Decimal("0"))
    net_payable: Mapped[Decimal] = mapped_column(MONEY, default=Decimal("0"))
    received_amount: Mapped[Decimal] = mapped_column(MONEY, default=Decimal("0"))
    certificate_no: Mapped[str] = mapped_column(String(60), default="")
    created_by: Mapped[uuid.UUID | None] = mapped_column(Uuid, nullable=True)
    decided_by: Mapped[uuid.UUID | None] = mapped_column(Uuid, nullable=True)
    decided_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    decision_comment: Mapped[str] = mapped_column(String(500), default="")
    journal_entry_id: Mapped[uuid.UUID | None] = mapped_column(Uuid, nullable=True)


class ClientBillLine(BaseMixin, Base):
    __tablename__ = "client_bill_lines"
    organization_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("organizations.id"), index=True)
    bill_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("client_bills.id"), index=True)
    boq_item_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("boq_items.id"), nullable=True)
    description: Mapped[str] = mapped_column(String(500))
    previous_quantity: Mapped[Decimal | None] = mapped_column(QTY, nullable=True)
    cumulative_quantity: Mapped[Decimal | None] = mapped_column(QTY, nullable=True)
    quantity: Mapped[Decimal | None] = mapped_column(QTY, nullable=True)       # this bill = cumulative - previous
    contract_rate: Mapped[Decimal | None] = mapped_column(MONEY, nullable=True)
    amount: Mapped[Decimal] = mapped_column(MONEY)


class ClientBillDeduction(BaseMixin, Base):
    __tablename__ = "client_bill_deductions"
    organization_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("organizations.id"), index=True)
    bill_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("client_bills.id"), index=True)
    type: Mapped[DeductionType] = mapped_column(_enum(DeductionType))
    description: Mapped[str] = mapped_column(String(300), default="")
    amount: Mapped[Decimal] = mapped_column(MONEY)


class ClientReceipt(BaseMixin, Base):
    __tablename__ = "client_receipts"
    __table_args__ = (UniqueConstraint("organization_id", "number"),)
    organization_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("organizations.id"), index=True)
    number: Mapped[str] = mapped_column(String(30))
    client_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("clients.id"), index=True)
    project_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("projects.id"), nullable=True)
    kind: Mapped[ReceiptKind] = mapped_column(_enum(ReceiptKind))
    account_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("accounts.id"))
    amount: Mapped[Decimal] = mapped_column(MONEY)
    receipt_date: Mapped[date] = mapped_column(Date)
    method: Mapped[PayMethod] = mapped_column(_enum(PayMethod), default=PayMethod.BANK_TRANSFER)
    reference: Mapped[str] = mapped_column(String(100), default="")
    status: Mapped[ApprovalState] = mapped_column(_enum(ApprovalState), default=ApprovalState.PENDING_APPROVAL)
    created_by: Mapped[uuid.UUID | None] = mapped_column(Uuid, nullable=True)
    decided_by: Mapped[uuid.UUID | None] = mapped_column(Uuid, nullable=True)
    decision_comment: Mapped[str] = mapped_column(String(500), default="")
    journal_entry_id: Mapped[uuid.UUID | None] = mapped_column(Uuid, nullable=True)


class ReceiptAllocation(BaseMixin, Base):
    __tablename__ = "receipt_allocations"
    organization_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("organizations.id"), index=True)
    receipt_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("client_receipts.id"), index=True)
    bill_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("client_bills.id"), index=True)
    amount: Mapped[Decimal] = mapped_column(MONEY)
