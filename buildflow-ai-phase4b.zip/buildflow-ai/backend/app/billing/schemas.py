import uuid
from datetime import date
from decimal import Decimal

from pydantic import BaseModel, Field, model_validator

from app.billing.models import BillStatus, BillType, DeductionType, ReceiptKind, VariationStatus
from app.finance.models import ApprovalState, PayMethod

POS = dict(gt=0, max_digits=18, decimal_places=2)


class BillLineIn(BaseModel):
    boq_item_id: uuid.UUID | None = None                       # RUNNING bills
    cumulative_quantity: Decimal | None = Field(default=None, gt=0, max_digits=18, decimal_places=4)
    contract_rate: Decimal | None = Field(default=None, ge=0, max_digits=18, decimal_places=2)
    description: str = Field(default="", max_length=500)       # MILESTONE bills
    amount: Decimal | None = Field(default=None, **POS)


class DeductionIn(BaseModel):
    type: DeductionType
    description: str = Field(default="", max_length=300)
    amount: Decimal = Field(**POS)


class BillIn(BaseModel):
    project_id: uuid.UUID
    bill_type: BillType
    bill_date: date
    due_date: date
    lines: list[BillLineIn] = Field(min_length=1, max_length=200)
    deductions: list[DeductionIn] = Field(default_factory=list, max_length=20)

    @model_validator(mode="after")
    def _dates(self):
        if self.due_date < self.bill_date:
            raise ValueError("due_date cannot be before bill_date")
        return self


class BillUpdate(BaseModel):
    bill_date: date | None = None
    due_date: date | None = None
    lines: list[BillLineIn] = Field(min_length=1, max_length=200)
    deductions: list[DeductionIn] = Field(default_factory=list, max_length=20)


class DecisionIn(BaseModel):
    comment: str = Field(default="", max_length=500)


class RejectIn(BaseModel):
    comment: str = Field(min_length=3, max_length=500)


class BillLineOut(BaseModel):
    boq_item_id: uuid.UUID | None
    description: str
    previous_quantity: Decimal | None
    cumulative_quantity: Decimal | None
    quantity: Decimal | None
    contract_rate: Decimal | None
    amount: Decimal


class DeductionOut(BaseModel):
    type: DeductionType
    description: str
    amount: Decimal


class BillOut(BaseModel):
    id: uuid.UUID
    number: str
    certificate_no: str
    project_id: uuid.UUID
    client_id: uuid.UUID
    bill_type: BillType
    bill_no: int
    bill_date: date
    due_date: date
    status: BillStatus
    gross_amount: Decimal
    retention_pct: Decimal
    retention_amount: Decimal
    deductions_total: Decimal
    net_payable: Decimal
    received_amount: Decimal
    outstanding: Decimal
    decision_comment: str
    lines: list[BillLineOut]
    deductions: list[DeductionOut]


class VariationIn(BaseModel):
    project_id: uuid.UUID
    title: str = Field(min_length=3, max_length=200)
    description: str = Field(default="", max_length=2000)
    amount: Decimal = Field(max_digits=18, decimal_places=2)

    @model_validator(mode="after")
    def _nonzero(self):
        if self.amount == 0:
            raise ValueError("amount cannot be zero")
        return self


class VariationOut(BaseModel):
    id: uuid.UUID
    number: str
    project_id: uuid.UUID
    title: str
    description: str
    amount: Decimal
    status: VariationStatus
    decision_comment: str


class RecAllocIn(BaseModel):
    bill_id: uuid.UUID
    amount: Decimal = Field(**POS)


class ReceiptIn(BaseModel):
    client_id: uuid.UUID
    project_id: uuid.UUID | None = None
    kind: ReceiptKind
    account_id: uuid.UUID
    receipt_date: date
    method: PayMethod = PayMethod.BANK_TRANSFER
    reference: str = Field(default="", max_length=100)
    amount: Decimal | None = Field(default=None, **POS)      # ADVANCE / RETENTION_RELEASE
    allocations: list[RecAllocIn] = Field(default_factory=list, max_length=50)   # PAYMENT


class ReceiptOut(BaseModel):
    id: uuid.UUID
    number: str
    client_id: uuid.UUID
    project_id: uuid.UUID | None
    kind: ReceiptKind
    account_id: uuid.UUID
    amount: Decimal
    receipt_date: date
    status: ApprovalState
    decision_comment: str
    allocations: list[RecAllocIn]
