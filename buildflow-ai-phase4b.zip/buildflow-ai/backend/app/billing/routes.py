"""Client billing: variations, running/milestone bills with retention and deductions, certification,
payment certificates (PDF), and client receipts (payment / advance / retention release).
All maths is deterministic Decimal; certification and receipts need a human with the right permission."""
import uuid
from datetime import datetime, timezone
from decimal import Decimal

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import Response
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.accounting import service as acc
from app.accounting.models import Account
from app.audit import log_action
from app.billing import calculations as calc
from app.billing.models import (BILLED, RECEIVABLE, BillStatus, BillType, ClientBill, ClientBillDeduction, ClientBillLine,
                                ClientReceipt, ClientVariation, DeductionType, ReceiptAllocation, ReceiptKind,
                                VariationStatus)
from app.billing.pdf import build_certificate
from app.billing.schemas import (BillIn, BillLineOut, BillOut, BillUpdate, DecisionIn, DeductionOut, RecAllocIn, ReceiptIn,
                                 ReceiptOut, RejectIn, VariationIn, VariationOut)
from app.boq import calculations as boq_calc
from app.boq.models import BOQ, ApprovalStatus, BOQItem
from app.db import get_db
from app.deps import get_owned, org_scoped, require_permission
from app.finance.models import ApprovalState
from app.inventory.service import next_number
from app.models import Organization, User
from app.projects.models import Client, Contract, Project

router = APIRouter(tags=["client-billing"])
READ = require_permission("finance.read")
MANAGE = require_permission("billing.manage")
APPROVE = require_permission("billing.approve")
FIN_MANAGE = require_permission("finance.manage")
FIN_APPROVE = require_permission("finance.approve")


# ------------------------------------------------------------------ shared figures
def revised_contract_value(db: Session, org_id, project: Project) -> Decimal:
    extra = db.scalar(select(func.coalesce(func.sum(ClientVariation.amount), 0)).where(
        ClientVariation.organization_id == org_id, ClientVariation.project_id == project.id,
        ClientVariation.status == VariationStatus.APPROVED))
    return project.contract_value + Decimal(extra)


def billed_gross(db: Session, org_id, project_id, exclude_bill_id=None) -> Decimal:
    q = select(func.coalesce(func.sum(ClientBill.gross_amount), 0)).where(
        ClientBill.organization_id == org_id, ClientBill.project_id == project_id, ClientBill.status.in_(BILLED))
    if exclude_bill_id:
        q = q.where(ClientBill.id != exclude_bill_id)
    return Decimal(db.scalar(q))


def retention_held(db: Session, org_id, project_id) -> Decimal:
    held = db.scalar(select(func.coalesce(func.sum(ClientBill.retention_amount), 0)).where(
        ClientBill.organization_id == org_id, ClientBill.project_id == project_id, ClientBill.status.in_(BILLED)))
    released = db.scalar(select(func.coalesce(func.sum(ClientReceipt.amount), 0)).where(
        ClientReceipt.organization_id == org_id, ClientReceipt.project_id == project_id,
        ClientReceipt.kind == ReceiptKind.RETENTION_RELEASE, ClientReceipt.status == ApprovalState.APPROVED))
    return Decimal(held) - Decimal(released)


def previous_quantity(db: Session, org_id, project_id, boq_item_id, exclude_bill_id=None) -> Decimal:
    q = (select(func.coalesce(func.sum(ClientBillLine.quantity), 0))
         .join(ClientBill, ClientBill.id == ClientBillLine.bill_id)
         .where(ClientBillLine.organization_id == org_id, ClientBill.project_id == project_id,
                ClientBillLine.boq_item_id == boq_item_id, ClientBill.status.in_(BILLED)))
    if exclude_bill_id:
        q = q.where(ClientBill.id != exclude_bill_id)
    return Decimal(db.scalar(q))


def _default_rate(db: Session, item: BOQItem) -> Decimal:
    boq = db.get(BOQ, item.boq_id)
    items = list(db.scalars(select(BOQItem).where(BOQItem.boq_id == boq.id)))
    s = boq_calc.summarize(items, boq.overhead_pct, boq.contingency_pct, boq.profit_pct)
    unit = boq_calc.unit_rate(item.material_rate, item.waste_pct, item.labour_rate, item.equipment_rate)
    return calc.default_contract_rate(unit, s["selling_price"], s["direct_cost"])


# ------------------------------------------------------------------ output
def _bill_out(db: Session, b: ClientBill) -> BillOut:
    lines = db.scalars(select(ClientBillLine).where(ClientBillLine.bill_id == b.id).order_by(ClientBillLine.created_at))
    ded = db.scalars(select(ClientBillDeduction).where(ClientBillDeduction.bill_id == b.id).order_by(ClientBillDeduction.created_at))
    return BillOut(
        id=b.id, number=b.number, certificate_no=b.certificate_no, project_id=b.project_id, client_id=b.client_id,
        bill_type=b.bill_type, bill_no=b.bill_no, bill_date=b.bill_date, due_date=b.due_date, status=b.status,
        gross_amount=b.gross_amount, retention_pct=b.retention_pct, retention_amount=b.retention_amount,
        deductions_total=b.deductions_total, net_payable=b.net_payable, received_amount=b.received_amount,
        outstanding=b.net_payable - b.received_amount if b.status in RECEIVABLE else Decimal("0"),
        decision_comment=b.decision_comment,
        lines=[BillLineOut(boq_item_id=l.boq_item_id, description=l.description, previous_quantity=l.previous_quantity,
                           cumulative_quantity=l.cumulative_quantity, quantity=l.quantity, contract_rate=l.contract_rate,
                           amount=l.amount) for l in lines],
        deductions=[DeductionOut(type=d.type, description=d.description, amount=d.amount) for d in ded])


# ------------------------------------------------------------------ building a bill
def _prepare_lines(db, user, project: Project, bill_type: BillType, lines_in, exclude_bill_id=None) -> list[dict]:
    out, seen = [], set()
    for l in lines_in:
        if bill_type == BillType.MILESTONE:
            if l.amount is None or not l.description.strip():
                raise HTTPException(422, "Milestone lines need a description and an amount")
            out.append({"boq_item_id": None, "description": l.description, "amount": l.amount})
            continue
        if l.boq_item_id is None or l.cumulative_quantity is None:
            raise HTTPException(422, "Running bill lines need boq_item_id and cumulative_quantity")
        if l.boq_item_id in seen:
            raise HTTPException(422, "Each BOQ item can appear once per bill")
        seen.add(l.boq_item_id)
        item = get_owned(db, BOQItem, l.boq_item_id, user, code=422)
        boq = db.get(BOQ, item.boq_id)
        if boq.project_id != project.id or boq.status != ApprovalStatus.APPROVED:
            raise HTTPException(422, f"BOQ item {item.item_code} is not in an approved BOQ of this project")
        if l.cumulative_quantity > item.quantity:
            raise HTTPException(422, f"Cumulative quantity for {item.item_code} exceeds the BOQ quantity ({item.quantity}); "
                                     "additional work needs an approved variation")
        prev = previous_quantity(db, user.organization_id, project.id, item.id, exclude_bill_id)
        if l.cumulative_quantity <= prev:
            raise HTTPException(422, f"Nothing new to bill for {item.item_code}: cumulative {l.cumulative_quantity} "
                                     f"is not above the {prev} already certified")
        qty = l.cumulative_quantity - prev
        rate = l.contract_rate if l.contract_rate is not None else _default_rate(db, item)
        out.append({"boq_item_id": item.id, "description": f"{item.item_code} - {item.description}",
                    "previous_quantity": prev, "cumulative_quantity": l.cumulative_quantity, "quantity": qty,
                    "contract_rate": rate, "amount": calc.line_amount(qty, rate)})
    return out


def _fill(db, user, bill: ClientBill, project: Project, lines: list[dict], deductions) -> None:
    for old in db.scalars(select(ClientBillLine).where(ClientBillLine.bill_id == bill.id)):
        db.delete(old)
    for old in db.scalars(select(ClientBillDeduction).where(ClientBillDeduction.bill_id == bill.id)):
        db.delete(old)
    db.flush()
    gross = sum((l["amount"] for l in lines), Decimal("0"))
    t = calc.bill_totals(gross, bill.retention_pct, [d.amount for d in deductions])
    if t["net"] < 0:
        raise HTTPException(422, f"Retention and deductions ({t['retention'] + t['deductions']}) exceed the gross amount ({gross})")
    for l in lines:
        db.add(ClientBillLine(organization_id=user.organization_id, bill_id=bill.id, **l))
    for d in deductions:
        db.add(ClientBillDeduction(organization_id=user.organization_id, bill_id=bill.id, type=d.type,
                                   description=d.description, amount=d.amount))
    bill.gross_amount, bill.retention_amount, bill.deductions_total, bill.net_payable = (
        t["gross"], t["retention"], t["deductions"], t["net"])


def _check_ceiling(db, user, bill: ClientBill, project: Project):
    ceiling = revised_contract_value(db, user.organization_id, project)
    total = billed_gross(db, user.organization_id, project.id, bill.id) + bill.gross_amount
    if total > ceiling:
        raise HTTPException(409, f"Total billing {total} would exceed the contract value including approved variations ({ceiling})")


def _check_not_stale(db, user, bill: ClientBill):
    for l in db.scalars(select(ClientBillLine).where(ClientBillLine.bill_id == bill.id, ClientBillLine.boq_item_id.is_not(None))):
        if previous_quantity(db, user.organization_id, bill.project_id, l.boq_item_id, bill.id) != l.previous_quantity:
            raise HTTPException(409, "Another bill was certified for the same work after this one was prepared; "
                                     "edit the bill so its quantities are recalculated")


@router.post("/client-bills", response_model=BillOut, status_code=201)
def create_bill(body: BillIn, request: Request, user: User = Depends(MANAGE), db: Session = Depends(get_db)):
    project = get_owned(db, Project, body.project_id, user, code=422)
    if not project.client_id:
        raise HTTPException(422, "Assign a client to the project before billing")
    lines = _prepare_lines(db, user, project, body.bill_type, body.lines)
    contract = db.scalar(org_scoped(Contract, user).where(Contract.project_id == project.id).order_by(Contract.created_at.desc()))
    last_no = db.scalar(select(func.coalesce(func.max(ClientBill.bill_no), 0)).where(
        ClientBill.organization_id == user.organization_id, ClientBill.project_id == project.id))
    bill = ClientBill(organization_id=user.organization_id, number=next_number(db, ClientBill, user.organization_id, "BILL"),
                      project_id=project.id, client_id=project.client_id, bill_type=body.bill_type, bill_no=last_no + 1,
                      bill_date=body.bill_date, due_date=body.due_date, created_by=user.id,
                      retention_pct=contract.retention_pct if contract else Decimal("0"))
    db.add(bill)
    try:
        db.flush()
        _fill(db, user, bill, project, lines, body.deductions)
        db.commit()
    except HTTPException:
        db.rollback()
        raise
    log_action(db, action="clientbill.create", org_id=user.organization_id, user_id=user.id, entity="client_bill",
               entity_id=bill.id, request=request, detail={"gross": str(bill.gross_amount)})
    return _bill_out(db, bill)


@router.put("/client-bills/{bill_id}", response_model=BillOut)
def update_bill(bill_id: uuid.UUID, body: BillUpdate, request: Request, user: User = Depends(MANAGE),
                db: Session = Depends(get_db)):
    bill = get_owned(db, ClientBill, bill_id, user)
    if bill.status != BillStatus.DRAFT:
        raise HTTPException(409, f"Bill is {bill.status.value}; only DRAFT bills can be edited")
    project = db.get(Project, bill.project_id)
    lines = _prepare_lines(db, user, project, bill.bill_type, body.lines, exclude_bill_id=bill.id)
    if body.bill_date:
        bill.bill_date = body.bill_date
    if body.due_date:
        bill.due_date = body.due_date
    if bill.due_date < bill.bill_date:
        raise HTTPException(422, "due_date cannot be before bill_date")
    try:
        _fill(db, user, bill, project, lines, body.deductions)
        db.commit()
    except HTTPException:
        db.rollback()
        raise
    log_action(db, action="clientbill.update", org_id=user.organization_id, user_id=user.id, entity="client_bill",
               entity_id=bill.id, request=request)
    return _bill_out(db, bill)


@router.get("/client-bills", response_model=list[BillOut])
def list_bills(project_id: uuid.UUID | None = None, status: BillStatus | None = None, limit: int = 100,
               user: User = Depends(READ), db: Session = Depends(get_db)):
    q = org_scoped(ClientBill, user)
    if project_id:
        q = q.where(ClientBill.project_id == project_id)
    if status:
        q = q.where(ClientBill.status == status)
    return [_bill_out(db, b) for b in db.scalars(q.order_by(ClientBill.created_at.desc()).limit(min(limit, 200)))]


@router.get("/client-bills/{bill_id}", response_model=BillOut)
def get_bill(bill_id: uuid.UUID, user: User = Depends(READ), db: Session = Depends(get_db)):
    return _bill_out(db, get_owned(db, ClientBill, bill_id, user))


@router.post("/client-bills/{bill_id}/submit", response_model=BillOut)
def submit_bill(bill_id: uuid.UUID, request: Request, user: User = Depends(MANAGE), db: Session = Depends(get_db)):
    bill = get_owned(db, ClientBill, bill_id, user)
    if bill.status != BillStatus.DRAFT:
        raise HTTPException(409, f"Bill is {bill.status.value}; expected DRAFT")
    project = db.get(Project, bill.project_id)
    _check_not_stale(db, user, bill)
    _check_ceiling(db, user, bill, project)
    bill.status = BillStatus.PENDING_APPROVAL
    db.commit()
    log_action(db, action="clientbill.submit", org_id=user.organization_id, user_id=user.id, entity="client_bill",
               entity_id=bill.id, request=request)
    return _bill_out(db, bill)


@router.post("/client-bills/{bill_id}/approve", response_model=BillOut)
def approve_bill(bill_id: uuid.UUID, body: DecisionIn, request: Request, user: User = Depends(APPROVE),
                 db: Session = Depends(get_db)):
    bill = get_owned(db, ClientBill, bill_id, user)
    if bill.status != BillStatus.PENDING_APPROVAL:
        raise HTTPException(409, f"Bill is {bill.status.value}; expected PENDING_APPROVAL")
    project = db.get(Project, bill.project_id)
    try:
        _check_not_stale(db, user, bill)
        _check_ceiling(db, user, bill, project)
        accounts = acc.ensure_accounts(db, user.organization_id)
        ded = {t: Decimal("0") for t in DeductionType}
        for d in db.scalars(select(ClientBillDeduction).where(ClientBillDeduction.bill_id == bill.id)):
            ded[d.type] += d.amount
        if ded[DeductionType.ADVANCE_RECOVERY] > acc.balance(db, user.organization_id, accounts["2300"].id, client_id=bill.client_id):
            raise HTTPException(409, "Advance recovery exceeds the advance received from this client")
        keys = dict(project_id=bill.project_id, client_id=bill.client_id)
        debits = [("1100", bill.net_payable), ("1300", bill.retention_amount), ("1400", ded[DeductionType.TAX_WITHHELD]),
                  ("2300", ded[DeductionType.ADVANCE_RECOVERY]),
                  ("4900", ded[DeductionType.PENALTY] + ded[DeductionType.OTHER])]
        lines = [{"account_id": accounts[c].id, "debit": a, **keys, "memo": f"Bill {bill.number}"} for c, a in debits if a > 0]
        lines.append({"account_id": accounts["4000"].id, "credit": bill.gross_amount, **keys, "memo": f"Bill {bill.number}"})
        e = acc.post_entry(db, org_id=user.organization_id, user_id=user.id, entry_date=bill.bill_date,
                           description=f"Client bill {bill.number} ({project.code} #{bill.bill_no})", lines=lines,
                           source_type="CLIENT_BILL", source_id=bill.id)
        bill.status, bill.decided_by, bill.decided_at, bill.decision_comment = (
            BillStatus.APPROVED, user.id, datetime.now(timezone.utc), body.comment)
        bill.certificate_no, bill.journal_entry_id = f"CERT-{project.code}-{bill.bill_no:03d}", e.id
        db.commit()
    except HTTPException:
        db.rollback()
        raise
    log_action(db, action="clientbill.approve", org_id=user.organization_id, user_id=user.id, entity="client_bill",
               entity_id=bill.id, request=request, detail={"certificate": bill.certificate_no, "net": str(bill.net_payable)})
    return _bill_out(db, bill)


@router.post("/client-bills/{bill_id}/reject", response_model=BillOut)
def reject_bill(bill_id: uuid.UUID, body: RejectIn, request: Request, user: User = Depends(APPROVE), db: Session = Depends(get_db)):
    bill = get_owned(db, ClientBill, bill_id, user)
    if bill.status != BillStatus.PENDING_APPROVAL:
        raise HTTPException(409, f"Bill is {bill.status.value}; expected PENDING_APPROVAL")
    bill.status, bill.decided_by, bill.decided_at, bill.decision_comment = (
        BillStatus.REJECTED, user.id, datetime.now(timezone.utc), body.comment)
    db.commit()
    log_action(db, action="clientbill.reject", org_id=user.organization_id, user_id=user.id, entity="client_bill",
               entity_id=bill.id, request=request, detail={"comment": body.comment})
    return _bill_out(db, bill)


@router.post("/client-bills/{bill_id}/cancel", response_model=BillOut)
def cancel_bill(bill_id: uuid.UUID, request: Request, user: User = Depends(MANAGE), db: Session = Depends(get_db)):
    bill = get_owned(db, ClientBill, bill_id, user)
    if bill.status not in (BillStatus.DRAFT, BillStatus.PENDING_APPROVAL):
        raise HTTPException(409, f"Bill is {bill.status.value}; certified bills cannot be cancelled")
    bill.status = BillStatus.CANCELLED
    db.commit()
    log_action(db, action="clientbill.cancel", org_id=user.organization_id, user_id=user.id, entity="client_bill",
               entity_id=bill.id, request=request)
    return _bill_out(db, bill)


@router.get("/client-bills/{bill_id}/certificate")
def certificate_pdf(bill_id: uuid.UUID, request: Request, user: User = Depends(READ), db: Session = Depends(get_db)):
    bill = get_owned(db, ClientBill, bill_id, user)
    if bill.status not in BILLED:
        raise HTTPException(409, "A payment certificate exists only for certified bills")
    project, client = db.get(Project, bill.project_id), db.get(Client, bill.client_id)
    org = db.get(Organization, user.organization_id)
    pdf = build_certificate(org_name=org.name, project=f"{project.code} - {project.name}", client=client.name,
                            bill=_bill_out(db, bill).model_dump(mode="json"))
    log_action(db, action="clientbill.certificate", org_id=user.organization_id, user_id=user.id, entity="client_bill",
               entity_id=bill.id, request=request)
    return Response(pdf, media_type="application/pdf",
                    headers={"Content-Disposition": f'attachment; filename="{bill.certificate_no}.pdf"'})


# ------------------------------------------------------------------ variations
def _var_out(v: ClientVariation) -> VariationOut:
    return VariationOut(id=v.id, number=v.number, project_id=v.project_id, title=v.title, description=v.description,
                        amount=v.amount, status=v.status, decision_comment=v.decision_comment)


@router.post("/client-variations", response_model=VariationOut, status_code=201)
def create_variation(body: VariationIn, request: Request, user: User = Depends(MANAGE), db: Session = Depends(get_db)):
    project = get_owned(db, Project, body.project_id, user, code=422)
    v = ClientVariation(organization_id=user.organization_id, number=next_number(db, ClientVariation, user.organization_id, "VAR"),
                        project_id=project.id, title=body.title, description=body.description, amount=body.amount,
                        created_by=user.id)
    db.add(v)
    db.commit()
    log_action(db, action="variation.create", org_id=user.organization_id, user_id=user.id, entity="client_variation",
               entity_id=v.id, request=request, detail={"amount": str(v.amount)})
    return _var_out(v)


@router.get("/client-variations", response_model=list[VariationOut])
def list_variations(project_id: uuid.UUID | None = None, user: User = Depends(READ), db: Session = Depends(get_db)):
    q = org_scoped(ClientVariation, user)
    if project_id:
        q = q.where(ClientVariation.project_id == project_id)
    return [_var_out(v) for v in db.scalars(q.order_by(ClientVariation.created_at))]


def _decide_variation(db, user, var_id, status, comment, request, action):
    v = get_owned(db, ClientVariation, var_id, user)
    if v.status != VariationStatus.PENDING_APPROVAL:
        raise HTTPException(409, f"Variation is {v.status.value}; expected PENDING_APPROVAL")
    if status == VariationStatus.APPROVED:
        project = db.get(Project, v.project_id)
        floor = billed_gross(db, user.organization_id, project.id)
        if revised_contract_value(db, user.organization_id, project) + v.amount < floor:
            raise HTTPException(409, "This omission would take the contract value below what has already been billed")
    v.status, v.decided_by, v.decision_comment = status, user.id, comment
    db.commit()
    log_action(db, action=action, org_id=user.organization_id, user_id=user.id, entity="client_variation",
               entity_id=v.id, request=request, detail={"amount": str(v.amount)})
    return _var_out(v)


@router.post("/client-variations/{var_id}/approve", response_model=VariationOut)
def approve_variation(var_id: uuid.UUID, body: DecisionIn, request: Request, user: User = Depends(APPROVE), db: Session = Depends(get_db)):
    return _decide_variation(db, user, var_id, VariationStatus.APPROVED, body.comment, request, "variation.approve")


@router.post("/client-variations/{var_id}/reject", response_model=VariationOut)
def reject_variation(var_id: uuid.UUID, body: RejectIn, request: Request, user: User = Depends(APPROVE), db: Session = Depends(get_db)):
    return _decide_variation(db, user, var_id, VariationStatus.REJECTED, body.comment, request, "variation.reject")


# ------------------------------------------------------------------ receipts
def _pending_on_bill(db, org_id, bill_id, exclude_receipt_id=None) -> Decimal:
    q = (select(func.coalesce(func.sum(ReceiptAllocation.amount), 0))
         .join(ClientReceipt, ClientReceipt.id == ReceiptAllocation.receipt_id)
         .where(ReceiptAllocation.organization_id == org_id, ReceiptAllocation.bill_id == bill_id,
                ClientReceipt.status == ApprovalState.PENDING_APPROVAL))
    if exclude_receipt_id:
        q = q.where(ClientReceipt.id != exclude_receipt_id)
    return Decimal(db.scalar(q))


def _pending_releases(db, org_id, project_id, exclude_receipt_id=None) -> Decimal:
    q = select(func.coalesce(func.sum(ClientReceipt.amount), 0)).where(
        ClientReceipt.organization_id == org_id, ClientReceipt.project_id == project_id,
        ClientReceipt.kind == ReceiptKind.RETENTION_RELEASE, ClientReceipt.status == ApprovalState.PENDING_APPROVAL)
    if exclude_receipt_id:
        q = q.where(ClientReceipt.id != exclude_receipt_id)
    return Decimal(db.scalar(q))


def _validate_receipt(db, user, r: ClientReceipt, allocs: list[tuple[uuid.UUID, Decimal]], exclude_receipt_id=None):
    if r.kind == ReceiptKind.PAYMENT:
        seen = set()
        for bill_id, amt in allocs:
            if bill_id in seen:
                raise HTTPException(422, "A bill can appear once per receipt")
            seen.add(bill_id)
            bill = get_owned(db, ClientBill, bill_id, user, code=422)
            if bill.client_id != r.client_id:
                raise HTTPException(422, f"Bill {bill.number} belongs to a different client")
            if bill.status not in RECEIVABLE:
                raise HTTPException(409, f"Bill {bill.number} is {bill.status.value}; only certified, unpaid bills can receive payment")
            avail = bill.net_payable - bill.received_amount - _pending_on_bill(db, user.organization_id, bill.id, exclude_receipt_id)
            if amt > avail:
                raise HTTPException(409, f"Receipt of {amt} exceeds the outstanding amount of bill {bill.number} ({avail})")
    elif r.kind == ReceiptKind.RETENTION_RELEASE:
        avail = retention_held(db, user.organization_id, r.project_id) - _pending_releases(db, user.organization_id, r.project_id, exclude_receipt_id)
        if r.amount > avail:
            raise HTTPException(409, f"Retention release of {r.amount} exceeds the retention held ({avail})")


def _rec_out(db, r: ClientReceipt) -> ReceiptOut:
    al = db.scalars(select(ReceiptAllocation).where(ReceiptAllocation.receipt_id == r.id).order_by(ReceiptAllocation.created_at))
    return ReceiptOut(id=r.id, number=r.number, client_id=r.client_id, project_id=r.project_id, kind=r.kind,
                      account_id=r.account_id, amount=r.amount, receipt_date=r.receipt_date, status=r.status,
                      decision_comment=r.decision_comment, allocations=[RecAllocIn(bill_id=a.bill_id, amount=a.amount) for a in al])


@router.post("/client-receipts", response_model=ReceiptOut, status_code=201)
def create_receipt(body: ReceiptIn, request: Request, user: User = Depends(FIN_MANAGE), db: Session = Depends(get_db)):
    client = get_owned(db, Client, body.client_id, user, code=422)
    acc.ensure_accounts(db, user.organization_id)
    account = get_owned(db, Account, body.account_id, user, code=422)
    if not account.is_cash:
        raise HTTPException(422, "Receipts must be deposited to a cash or bank account")
    if body.project_id:
        get_owned(db, Project, body.project_id, user, code=422)
    if body.kind == ReceiptKind.PAYMENT:
        if not body.allocations or body.amount is not None:
            raise HTTPException(422, "A PAYMENT receipt needs allocations to bills (and no separate amount)")
        amount = sum((a.amount for a in body.allocations), Decimal("0"))
    else:
        if body.allocations or body.amount is None:
            raise HTTPException(422, f"A {body.kind.value} receipt needs an amount and no bill allocations")
        if body.kind == ReceiptKind.RETENTION_RELEASE and not body.project_id:
            raise HTTPException(422, "A retention release needs the project")
        amount = body.amount
    r = ClientReceipt(organization_id=user.organization_id, number=next_number(db, ClientReceipt, user.organization_id, "RCT"),
                      client_id=client.id, project_id=body.project_id, kind=body.kind, account_id=account.id, amount=amount,
                      receipt_date=body.receipt_date, method=body.method, reference=body.reference, created_by=user.id)
    try:
        _validate_receipt(db, user, r, [(a.bill_id, a.amount) for a in body.allocations])
        db.add(r)
        db.flush()
        for a in body.allocations:
            db.add(ReceiptAllocation(organization_id=user.organization_id, receipt_id=r.id, bill_id=a.bill_id, amount=a.amount))
        db.commit()
    except HTTPException:
        db.rollback()
        raise
    log_action(db, action="receipt.create", org_id=user.organization_id, user_id=user.id, entity="client_receipt",
               entity_id=r.id, request=request, detail={"amount": str(amount), "kind": r.kind.value})
    return _rec_out(db, r)


@router.get("/client-receipts", response_model=list[ReceiptOut])
def list_receipts(status: ApprovalState | None = None, client_id: uuid.UUID | None = None, limit: int = 100,
                  user: User = Depends(READ), db: Session = Depends(get_db)):
    q = org_scoped(ClientReceipt, user)
    if status:
        q = q.where(ClientReceipt.status == status)
    if client_id:
        q = q.where(ClientReceipt.client_id == client_id)
    return [_rec_out(db, r) for r in db.scalars(q.order_by(ClientReceipt.created_at.desc()).limit(min(limit, 200)))]


@router.get("/client-receipts/{receipt_id}", response_model=ReceiptOut)
def get_receipt(receipt_id: uuid.UUID, user: User = Depends(READ), db: Session = Depends(get_db)):
    return _rec_out(db, get_owned(db, ClientReceipt, receipt_id, user))


def _pending_receipt(r: ClientReceipt):
    if r.status != ApprovalState.PENDING_APPROVAL:
        raise HTTPException(409, f"Receipt is {r.status.value}; expected PENDING_APPROVAL")


@router.post("/client-receipts/{receipt_id}/approve", response_model=ReceiptOut)
def approve_receipt(receipt_id: uuid.UUID, body: DecisionIn, request: Request, user: User = Depends(FIN_APPROVE),
                    db: Session = Depends(get_db)):
    r = get_owned(db, ClientReceipt, receipt_id, user)
    _pending_receipt(r)
    if r.created_by == user.id:
        raise HTTPException(403, "A receipt cannot be approved by the person who created it")
    allocs = list(db.scalars(select(ReceiptAllocation).where(ReceiptAllocation.receipt_id == r.id)))
    try:
        _validate_receipt(db, user, r, [(a.bill_id, a.amount) for a in allocs], exclude_receipt_id=r.id)
        accounts = acc.ensure_accounts(db, user.organization_id)
        lines = [{"account_id": r.account_id, "debit": r.amount, "client_id": r.client_id, "memo": r.reference}]
        if r.kind == ReceiptKind.PAYMENT:
            for a in allocs:
                bill = db.get(ClientBill, a.bill_id)
                bill.received_amount += a.amount
                bill.status = BillStatus.PAID if bill.received_amount == bill.net_payable else BillStatus.PARTIALLY_PAID
                lines.append({"account_id": accounts["1100"].id, "credit": a.amount, "client_id": r.client_id,
                              "project_id": bill.project_id, "memo": bill.number})
        elif r.kind == ReceiptKind.ADVANCE:
            lines.append({"account_id": accounts["2300"].id, "credit": r.amount, "client_id": r.client_id,
                          "project_id": r.project_id, "memo": "Advance"})
        else:
            lines.append({"account_id": accounts["1300"].id, "credit": r.amount, "client_id": r.client_id,
                          "project_id": r.project_id, "memo": "Retention release"})
        e = acc.post_entry(db, org_id=user.organization_id, user_id=user.id, entry_date=r.receipt_date,
                           description=f"Receipt {r.number} ({r.kind.value})", lines=lines, source_type="RECEIPT", source_id=r.id)
        r.status, r.decided_by, r.decision_comment, r.journal_entry_id = ApprovalState.APPROVED, user.id, body.comment, e.id
        db.commit()
    except HTTPException:
        db.rollback()
        raise
    log_action(db, action="receipt.approve", org_id=user.organization_id, user_id=user.id, entity="client_receipt",
               entity_id=r.id, request=request, detail={"amount": str(r.amount), "kind": r.kind.value})
    return _rec_out(db, r)


@router.post("/client-receipts/{receipt_id}/reject", response_model=ReceiptOut)
def reject_receipt(receipt_id: uuid.UUID, body: RejectIn, request: Request, user: User = Depends(FIN_APPROVE),
                   db: Session = Depends(get_db)):
    r = get_owned(db, ClientReceipt, receipt_id, user)
    _pending_receipt(r)
    r.status, r.decided_by, r.decision_comment = ApprovalState.REJECTED, user.id, body.comment
    db.commit()
    log_action(db, action="receipt.reject", org_id=user.organization_id, user_id=user.id, entity="client_receipt",
               entity_id=r.id, request=request, detail={"comment": body.comment})
    return _rec_out(db, r)


@router.post("/client-receipts/{receipt_id}/cancel", response_model=ReceiptOut)
def cancel_receipt(receipt_id: uuid.UUID, request: Request, user: User = Depends(FIN_MANAGE), db: Session = Depends(get_db)):
    r = get_owned(db, ClientReceipt, receipt_id, user)
    _pending_receipt(r)
    r.status = ApprovalState.CANCELLED
    db.commit()
    log_action(db, action="receipt.cancel", org_id=user.organization_id, user_id=user.id, entity="client_receipt",
               entity_id=r.id, request=request)
    return _rec_out(db, r)
