"""Deterministic financial reporting straight from the journal (the single source of truth)."""
import uuid
from datetime import date
from decimal import Decimal

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.accounting import service as acc
from app.accounting.models import Account, AccountType, JournalEntry, JournalLine
from app.boq import calculations as boq_calc
from app.budgets.models import Budget, BudgetLine
from app.projects.models import Project

ZERO = Decimal("0")


def s(d: Decimal) -> str:
    return str(d)


def _period(q, d_from, d_to):
    if d_from:
        q = q.where(JournalEntry.entry_date >= d_from)
    if d_to:
        q = q.where(JournalEntry.entry_date <= d_to)
    return q


def _pnl_rows(db: Session, org_id, project_id, d_from, d_to):
    q = (select(Account.code, Account.name, Account.type, func.coalesce(func.sum(JournalLine.debit), 0),
                func.coalesce(func.sum(JournalLine.credit), 0))
         .join(JournalLine, JournalLine.account_id == Account.id)
         .join(JournalEntry, JournalEntry.id == JournalLine.entry_id)
         .where(JournalLine.organization_id == org_id, Account.type.in_([AccountType.INCOME, AccountType.EXPENSE])))
    q = q.where(JournalLine.project_id == project_id) if project_id else q.where(JournalLine.project_id.is_(None))
    return db.execute(_period(q, d_from, d_to).group_by(Account.id).order_by(Account.code)).all()


def project_figures(db: Session, org_id, project_id, d_from=None, d_to=None) -> dict:
    gross = deductions = ZERO
    costs: list[dict] = []
    for code, name, typ, d, c in _pnl_rows(db, org_id, project_id, d_from, d_to):
        d, c = Decimal(d), Decimal(c)
        if typ == AccountType.INCOME:
            if code == "4900":
                deductions += d - c
            else:
                gross += c - d
        elif d - c != 0:
            costs.append({"code": code, "name": name, "amount": d - c})
    net_rev = gross - deductions
    total_cost = sum((x["amount"] for x in costs), ZERO)
    return {"revenue": gross, "revenue_deductions": deductions, "net_revenue": net_rev, "costs": costs,
            "total_cost": total_cost, "gross_profit": net_rev - total_cost}


def unallocated_costs(db: Session, org_id, d_from=None, d_to=None) -> Decimal:
    return sum((Decimal(d) - Decimal(c) for _, _, t, d, c in _pnl_rows(db, org_id, None, d_from, d_to)
                if t == AccountType.EXPENSE), ZERO)


def active_project_ids(db: Session, org_id, d_from=None, d_to=None) -> list[uuid.UUID]:
    q = (select(JournalLine.project_id).join(JournalEntry, JournalEntry.id == JournalLine.entry_id)
         .join(Account, Account.id == JournalLine.account_id)
         .where(JournalLine.organization_id == org_id, JournalLine.project_id.is_not(None),
                Account.type.in_([AccountType.INCOME, AccountType.EXPENSE])).distinct())
    return list(db.scalars(_period(q, d_from, d_to)))


def overhead_shares(db: Session, org_id, d_from, d_to) -> dict[uuid.UUID, Decimal]:
    """Unallocated costs split across projects in proportion to net revenue for the period (to the cent)."""
    pool = unallocated_costs(db, org_id, d_from, d_to)
    weights = {}
    for pid in active_project_ids(db, org_id, d_from, d_to):
        nr = project_figures(db, org_id, pid, d_from, d_to)["net_revenue"]
        if nr > 0:
            weights[pid] = nr
    if pool == 0 or not weights:
        return {}
    return acc.allocate_pro_rata(pool, weights)


def budget_block(db: Session, org_id, project: Project, revised_contract: Decimal) -> dict | None:
    b = db.scalar(select(Budget).where(Budget.organization_id == org_id, Budget.project_id == project.id))
    if not b:
        return None
    sums = db.execute(select(*[func.coalesce(func.sum(getattr(BudgetLine, f)), 0) for f in
                               ("revised_amount", "committed_amount", "actual_amount", "paid_amount")])
                      .where(BudgetLine.budget_id == b.id)).one()
    rev, com, act, paid = (Decimal(x) for x in sums)
    margin = revised_contract - rev
    return {"revised": s(rev), "committed": s(com), "actual": s(act), "paid": s(paid),
            "planned_margin": s(margin),
            "planned_margin_pct": s(boq_calc.q2(margin / revised_contract * 100) if revised_contract else Decimal("0.00"))}
