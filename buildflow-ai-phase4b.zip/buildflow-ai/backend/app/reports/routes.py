import uuid
from collections import defaultdict
from datetime import date, timedelta
from decimal import Decimal

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.accounting import service as acc
from app.accounting.models import Account, JournalEntry, JournalLine
from app.billing.models import BILLED, RECEIVABLE, ClientBill, ClientReceipt, ReceiptKind
from app.billing.routes import billed_gross, retention_held, revised_contract_value
from app.boq import calculations as boq_calc
from app.dailylogs.service import project_progress
from app.db import get_db
from app.deps import get_owned, org_scoped, require_permission
from app.finance.models import ApprovalState, InvoiceStatus, Payment, SupplierInvoice
from app.models import User
from app.procurement.models import Supplier
from app.projects.models import Client, Project
from app.reports import service as rs
from app.timeutil import local_today

router = APIRouter(tags=["reports"])
READ = require_permission("finance.read")
ZERO = Decimal("0")
BUCKETS = ("not_due", "d1_30", "d31_60", "d61_90", "d90_plus")


def bucket(days_late: int) -> str:
    return BUCKETS[0] if days_late <= 0 else BUCKETS[1] if days_late <= 30 else BUCKETS[2] if days_late <= 60 else BUCKETS[3] if days_late <= 90 else BUCKETS[4]


@router.get("/reports/receivables-aging")
def receivables_aging(as_of: date | None = None, user: User = Depends(READ), db: Session = Depends(get_db)):
    as_of = as_of or local_today()
    clients = {c.id: c for c in db.scalars(org_scoped(Client, user))}
    rows: dict[uuid.UUID, dict] = {}
    for b in db.scalars(org_scoped(ClientBill, user).where(ClientBill.status.in_(RECEIVABLE))):
        out = b.net_payable - b.received_amount
        r = rows.setdefault(b.client_id, {"client_id": str(b.client_id), "client": clients[b.client_id].name,
                                          **{k: ZERO for k in BUCKETS}, "total": ZERO})
        r[bucket((as_of - b.due_date).days)] += out
        r["total"] += out
    fmt = [{k: (str(v) if isinstance(v, Decimal) else v) for k, v in r.items()} for r in sorted(rows.values(), key=lambda r: r["client"])]
    return {"as_of": str(as_of), "clients": fmt,
            "totals": {k: str(sum((Decimal(r[k]) for r in fmt), ZERO)) for k in (*BUCKETS, "total")}}


@router.get("/projects/{project_id}/billing-summary")
def billing_summary(project_id: uuid.UUID, user: User = Depends(READ), db: Session = Depends(get_db)):
    p = get_owned(db, Project, project_id, user)
    org = user.organization_id
    revised = revised_contract_value(db, org, p)
    billed = billed_gross(db, org, p.id)
    certified = db.execute(select(func.coalesce(func.sum(ClientBill.net_payable), 0), func.coalesce(func.sum(ClientBill.received_amount), 0))
                           .where(ClientBill.organization_id == org, ClientBill.project_id == p.id,
                                  ClientBill.status.in_(BILLED))).one()
    accounts = acc.ensure_accounts(db, org)
    db.commit()
    advance = acc.balance(db, org, accounts["2300"].id, client_id=p.client_id) if p.client_id else ZERO
    progress = project_progress(db, org, p.id)
    return {"project_id": str(p.id), "contract_value": str(p.contract_value),
            "approved_variations": str(revised - p.contract_value), "revised_contract_value": str(revised),
            "gross_billed_to_date": str(billed), "remaining_to_bill": str(revised - billed),
            "billed_percent": str(boq_calc.q2(billed / revised * 100) if revised else Decimal("0.00")),
            "retention_held": str(retention_held(db, org, p.id)),
            "net_certified": str(Decimal(certified[0])), "received_on_bills": str(Decimal(certified[1])),
            "receivable_outstanding": str(Decimal(certified[0]) - Decimal(certified[1])),
            "client_advance_balance": str(advance), "physical_progress_percent": progress["overall_percent"]}


# ------------------------------------------------------------------ profit & loss
def _fmt_pnl(f: dict, overhead: Decimal | None) -> dict:
    net_profit = f["gross_profit"] - (overhead or ZERO)
    margin = lambda x: str(boq_calc.q2(x / f["net_revenue"] * 100) if f["net_revenue"] else Decimal("0.00"))  # noqa: E731
    out = {"revenue": rs.s(f["revenue"]), "revenue_deductions": rs.s(f["revenue_deductions"]),
           "net_revenue": rs.s(f["net_revenue"]),
           "costs": [{"code": c["code"], "name": c["name"], "amount": rs.s(c["amount"])} for c in f["costs"]],
           "total_direct_cost": rs.s(f["total_cost"]), "gross_profit": rs.s(f["gross_profit"]),
           "gross_margin_pct": margin(f["gross_profit"])}
    if overhead is not None:
        out.update({"allocated_overhead": rs.s(overhead), "net_profit": rs.s(net_profit), "net_margin_pct": margin(net_profit)})
    return out


@router.get("/projects/{project_id}/pnl")
def project_pnl(project_id: uuid.UUID, date_from: date | None = None, date_to: date | None = None,
                allocate_overhead: bool = False, user: User = Depends(READ), db: Session = Depends(get_db)):
    p = get_owned(db, Project, project_id, user)
    org = user.organization_id
    f = rs.project_figures(db, org, p.id, date_from, date_to)
    overhead = rs.overhead_shares(db, org, date_from, date_to).get(p.id, ZERO) if allocate_overhead else None
    revised = revised_contract_value(db, org, p)
    return {"project": {"id": str(p.id), "code": p.code, "name": p.name}, "period": {"from": str(date_from) if date_from else None,
            "to": str(date_to) if date_to else None}, **_fmt_pnl(f, overhead),
            "contract": {"contract_value": str(p.contract_value), "revised_contract_value": str(revised)},
            "budget": rs.budget_block(db, org, p, revised),
            "basis": "accrual, from the journal (costs recognised when goods are received, labour approved, invoices posted or expenses approved)"}


@router.get("/reports/pnl")
def company_pnl(date_from: date | None = None, date_to: date | None = None, user: User = Depends(READ),
                db: Session = Depends(get_db)):
    org = user.organization_id
    shares = rs.overhead_shares(db, org, date_from, date_to)
    names = {p.id: p for p in db.scalars(org_scoped(Project, user))}
    rows, tot = [], defaultdict(lambda: ZERO)
    for pid in rs.active_project_ids(db, org, date_from, date_to):
        f = rs.project_figures(db, org, pid, date_from, date_to)
        oh = shares.get(pid, ZERO)
        rows.append({"project_id": str(pid), "code": names[pid].code, "name": names[pid].name, "net_revenue": rs.s(f["net_revenue"]),
                     "direct_cost": rs.s(f["total_cost"]), "gross_profit": rs.s(f["gross_profit"]),
                     "allocated_overhead": rs.s(oh), "net_profit": rs.s(f["gross_profit"] - oh)})
        for k, v in (("net_revenue", f["net_revenue"]), ("direct_cost", f["total_cost"]), ("gross_profit", f["gross_profit"])):
            tot[k] += v
    pool = rs.unallocated_costs(db, org, date_from, date_to)
    allocated = sum(shares.values(), ZERO)
    return {"period": {"from": str(date_from) if date_from else None, "to": str(date_to) if date_to else None},
            "projects": sorted(rows, key=lambda r: r["code"]),
            "totals": {"net_revenue": rs.s(tot["net_revenue"]), "direct_cost": rs.s(tot["direct_cost"]),
                       "gross_profit": rs.s(tot["gross_profit"]), "unallocated_costs": rs.s(pool),
                       "unallocated_not_distributed": rs.s(pool - allocated),
                       "company_net_profit": rs.s(tot["gross_profit"] - pool)}}


# ------------------------------------------------------------------ cash
CASH_LABEL = {"RECEIPT": "Client receipts", "PAYMENT": "Supplier payments", "EXPENSE": "Project expenses",
              "MANUAL": "Other (manual journals)"}


def _cash_ids(db, org_id) -> list[uuid.UUID]:
    acc.ensure_accounts(db, org_id)
    return list(db.scalars(select(Account.id).where(Account.organization_id == org_id, Account.is_cash.is_(True))))


@router.get("/reports/cash-flow")
def cash_flow(date_from: date | None = None, date_to: date | None = None, user: User = Depends(READ),
              db: Session = Depends(get_db)):
    today = local_today()
    date_to, date_from = date_to or today, date_from or today.replace(day=1)
    if date_to < date_from:
        raise HTTPException(422, "date_to cannot be before date_from")
    org, cash = user.organization_id, _cash_ids(db, user.organization_id)
    db.commit()
    base = (select(JournalEntry.entry_date, JournalEntry.source_type, JournalLine.debit, JournalLine.credit)
            .join(JournalEntry, JournalEntry.id == JournalLine.entry_id)
            .where(JournalLine.organization_id == org, JournalLine.account_id.in_(cash or [None])))
    od, oc = db.execute(select(func.coalesce(func.sum(JournalLine.debit), 0), func.coalesce(func.sum(JournalLine.credit), 0))
                        .join(JournalEntry, JournalEntry.id == JournalLine.entry_id)
                        .where(JournalLine.organization_id == org, JournalLine.account_id.in_(cash or [None]),
                               JournalEntry.entry_date < date_from)).one()
    opening = Decimal(od) - Decimal(oc)
    cats: dict[str, list[Decimal]] = defaultdict(lambda: [ZERO, ZERO])
    months: dict[str, list[Decimal]] = defaultdict(lambda: [ZERO, ZERO])
    for d, src, deb, cre in db.execute(base.where(JournalEntry.entry_date >= date_from, JournalEntry.entry_date <= date_to)):
        label = CASH_LABEL.get(src, src.title())
        cats[label][0] += deb
        cats[label][1] += cre
        m = months[d.strftime("%Y-%m")]
        m[0] += deb
        m[1] += cre
    inflow, outflow = sum((v[0] for v in cats.values()), ZERO), sum((v[1] for v in cats.values()), ZERO)
    per_account = []
    for a in db.scalars(select(Account).where(Account.id.in_(cash or [None])).order_by(Account.code)):
        per_account.append({"code": a.code, "name": a.name, "balance": rs.s(acc.balance(db, org, a.id, as_of=date_to))})
    return {"period": {"from": str(date_from), "to": str(date_to)}, "opening_cash": rs.s(opening),
            "categories": [{"category": k, "inflow": rs.s(v[0]), "outflow": rs.s(v[1]), "net": rs.s(v[0] - v[1])} for k, v in sorted(cats.items())],
            "total_inflow": rs.s(inflow), "total_outflow": rs.s(outflow), "net_cash_flow": rs.s(inflow - outflow),
            "closing_cash": rs.s(opening + inflow - outflow), "by_month": [
                {"month": k, "inflow": rs.s(v[0]), "outflow": rs.s(v[1]), "net": rs.s(v[0] - v[1])} for k, v in sorted(months.items())],
            "cash_accounts": per_account}


@router.get("/reports/cash-forecast")
def cash_forecast(days: int = 30, user: User = Depends(READ), db: Session = Depends(get_db)):
    """Contractual view: receivables and payables by due date, assuming they settle on time. Not a prediction."""
    if not 1 <= days <= 180:
        raise HTTPException(422, "days must be between 1 and 180")
    org, today = user.organization_id, local_today()
    horizon = today + timedelta(days=days)
    cash = _cash_ids(db, org)
    db.commit()
    opening = sum((acc.balance(db, org, a, as_of=today) for a in cash), ZERO)
    clients = {c.id: c.name for c in db.scalars(org_scoped(Client, user))}
    suppliers = {x.id: x.name for x in db.scalars(org_scoped(Supplier, user))}
    items = []
    for b in db.scalars(org_scoped(ClientBill, user).where(ClientBill.status.in_(RECEIVABLE), ClientBill.due_date <= horizon)):
        items.append({"direction": "IN", "ref": b.number, "party": clients[b.client_id], "due_date": b.due_date,
                      "amount": b.net_payable - b.received_amount})
    for i in db.scalars(org_scoped(SupplierInvoice, user).where(
            SupplierInvoice.status.in_((InvoiceStatus.POSTED, InvoiceStatus.PARTIALLY_PAID)), SupplierInvoice.due_date <= horizon)):
        items.append({"direction": "OUT", "ref": i.number, "party": suppliers[i.supplier_id], "due_date": i.due_date,
                      "amount": i.total_amount - i.paid_amount})
    tot = lambda d, overdue: sum((x["amount"] for x in items if x["direction"] == d and (x["due_date"] < today) == overdue), ZERO)  # noqa: E731
    r_over, r_due, p_over, p_due = tot("IN", True), tot("IN", False), tot("OUT", True), tot("OUT", False)
    pending_pay = db.scalar(select(func.coalesce(func.sum(Payment.amount), 0)).where(
        Payment.organization_id == org, Payment.status == ApprovalState.PENDING_APPROVAL))
    return {"as_of": str(today), "horizon": str(horizon), "opening_cash": rs.s(opening),
            "receivables": {"overdue": rs.s(r_over), "due_in_period": rs.s(r_due)},
            "payables": {"overdue": rs.s(p_over), "due_in_period": rs.s(p_due),
                         "payments_awaiting_approval": rs.s(Decimal(pending_pay))},
            "projected_closing_cash": rs.s(opening + r_over + r_due - p_over - p_due),
            "items": [{**x, "due_date": str(x["due_date"]), "amount": rs.s(x["amount"])} for x in sorted(items, key=lambda x: (x["due_date"], x["ref"]))][:200]}
