import uuid
from datetime import date
from decimal import Decimal

from pydantic import BaseModel, ConfigDict, Field

from app.accounting.models import AccountType

AMT = dict(ge=0, max_digits=18, decimal_places=2)


class AccountIn(BaseModel):
    code: str = Field(min_length=1, max_length=20)
    name: str = Field(min_length=2, max_length=200)
    type: AccountType
    is_cash: bool = False


class AccountOut(AccountIn):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    is_system: bool


class LineIn(BaseModel):
    account_id: uuid.UUID
    debit: Decimal = Field(default=Decimal("0"), **AMT)
    credit: Decimal = Field(default=Decimal("0"), **AMT)
    project_id: uuid.UUID | None = None
    cost_code_id: uuid.UUID | None = None
    memo: str = Field(default="", max_length=300)


class JournalIn(BaseModel):
    entry_date: date
    description: str = Field(min_length=3, max_length=500)
    lines: list[LineIn] = Field(min_length=2, max_length=100)


class ReverseIn(BaseModel):
    reason: str = Field(min_length=3, max_length=300)


class JLineOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    account_id: uuid.UUID
    debit: Decimal
    credit: Decimal
    project_id: uuid.UUID | None
    cost_code_id: uuid.UUID | None
    supplier_id: uuid.UUID | None
    client_id: uuid.UUID | None
    memo: str


class JournalOut(BaseModel):
    id: uuid.UUID
    number: str
    entry_date: date
    description: str
    source_type: str
    source_id: str
    reversal_of: uuid.UUID | None
    lines: list[JLineOut]
