import enum
import uuid
from datetime import date
from decimal import Decimal

from sqlalchemy import Boolean, Date, Enum, ForeignKey, Numeric, String, UniqueConstraint, Uuid
from sqlalchemy.orm import Mapped, mapped_column

from app.models import Base, BaseMixin

MONEY = Numeric(18, 2)


class AccountType(str, enum.Enum):
    ASSET = "ASSET"
    LIABILITY = "LIABILITY"
    EQUITY = "EQUITY"
    INCOME = "INCOME"
    EXPENSE = "EXPENSE"


DEBIT_NORMAL = {AccountType.ASSET, AccountType.EXPENSE}


class Account(BaseMixin, Base):
    __tablename__ = "accounts"
    __table_args__ = (UniqueConstraint("organization_id", "code"),)
    organization_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("organizations.id"), index=True)
    code: Mapped[str] = mapped_column(String(20))
    name: Mapped[str] = mapped_column(String(200))
    type: Mapped[AccountType] = mapped_column(Enum(AccountType, native_enum=False, length=20))
    is_cash: Mapped[bool] = mapped_column(Boolean, default=False)       # cash/bank accounts usable for payments
    is_system: Mapped[bool] = mapped_column(Boolean, default=False)     # referenced by automatic postings


class JournalEntry(BaseMixin, Base):
    """Immutable once posted. Corrections are made by a reversing entry."""
    __tablename__ = "journal_entries"
    __table_args__ = (UniqueConstraint("organization_id", "number"),)
    organization_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("organizations.id"), index=True)
    number: Mapped[str] = mapped_column(String(30))
    entry_date: Mapped[date] = mapped_column(Date, index=True)
    description: Mapped[str] = mapped_column(String(500))
    source_type: Mapped[str] = mapped_column(String(30), default="MANUAL")   # GRN, LABOUR, INVOICE, PAYMENT, EXPENSE, ...
    source_id: Mapped[str] = mapped_column(String(60), default="")
    reversal_of: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("journal_entries.id"), nullable=True)
    posted_by: Mapped[uuid.UUID | None] = mapped_column(Uuid, nullable=True)


class JournalLine(BaseMixin, Base):
    __tablename__ = "journal_lines"
    organization_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("organizations.id"), index=True)
    entry_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("journal_entries.id"), index=True)
    account_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("accounts.id"), index=True)
    debit: Mapped[Decimal] = mapped_column(MONEY, default=Decimal("0"))
    credit: Mapped[Decimal] = mapped_column(MONEY, default=Decimal("0"))
    project_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("projects.id"), nullable=True, index=True)
    cost_code_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("cost_codes.id"), nullable=True)
    supplier_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("suppliers.id"), nullable=True)
    client_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("clients.id"), nullable=True)
    memo: Mapped[str] = mapped_column(String(300), default="")
