"""Automatic journal postings triggered by operational events (GRN, approved attendance)."""
from decimal import Decimal

from sqlalchemy.orm import Session

from app.accounting import service as acc
from app.boq.models import CostCode
from app.timeutil import local_today


def cost_debit_lines(db: Session, org_id, project_id, pairs) -> list[dict]:
    """pairs: (cost_code_id, amount) -> one debit line per cost code, on the right expense account, project-coded."""
    from app.budgets.service import group
    lines = []
    for cc, amount in sorted(group(pairs).items(), key=lambda kv: str(kv[0])):
        if amount == 0:
            continue
        code = db.get(CostCode, cc)
        acct = acc.cost_account(db, org_id, code.category)
        line = {"account_id": acct.id, "project_id": project_id, "cost_code_id": cc, "memo": code.code}
        line["debit" if amount > 0 else "credit"] = abs(amount)
        lines.append(line)
    return lines


def post_goods_receipt(db: Session, org_id, user_id, *, project_id, grn_number, pairs) -> None:
    """Dr project cost (by cost code) / Cr Goods Received Not Invoiced, at PO rate x accepted quantity."""
    debits = cost_debit_lines(db, org_id, project_id, pairs)
    total = sum((l.get("debit", Decimal("0")) for l in debits), Decimal("0"))
    if total <= 0:
        return
    grni = acc.ensure_accounts(db, org_id)["2100"]
    acc.post_entry(db, org_id=org_id, user_id=user_id, entry_date=local_today(), description=f"Goods received {grn_number}",
                   lines=debits + [{"account_id": grni.id, "credit": total, "project_id": project_id}],
                   source_type="GRN", source_id=grn_number)


def post_labour(db: Session, org_id, user_id, *, project_id, sheet_id, work_date, pairs) -> None:
    """Dr Labour cost (by cost code) / Cr Wages Payable. Payroll settlement is a later phase."""
    debits = cost_debit_lines(db, org_id, project_id, pairs)
    total = sum((l.get("debit", Decimal("0")) for l in debits), Decimal("0"))
    if total <= 0:
        return
    wages = acc.ensure_accounts(db, org_id)["2200"]
    acc.post_entry(db, org_id=org_id, user_id=user_id, entry_date=work_date, description=f"Labour {work_date}",
                   lines=debits + [{"account_id": wages.id, "credit": total, "project_id": project_id}],
                   source_type="LABOUR", source_id=sheet_id)
