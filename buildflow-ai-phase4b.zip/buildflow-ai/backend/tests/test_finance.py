from datetime import timedelta
from decimal import Decimal as D

from app.db import SessionLocal
from app.models import Role
from app.timeutil import local_today
from tests.helpers import (accounts, add_user, bootstrap, budget_totals, closing, grn, invoice, mk_project, post,
                           received_po, register)

TODAY = str(local_today())


def setup(client, **kw):
    ctx = bootstrap(client, **kw)
    ctx["acct"] = add_user(client, ctx["h"], "acc@alpha.pk", "ACCOUNTANT")
    ctx["A"] = accounts(client, ctx["h"])
    return ctx


def tb(client, ctx):
    r = client.get("/trial-balance", headers=ctx["h"]).json()
    assert r["balanced"] is True and r["total_debit"] == r["total_credit"]
    return r


def test_grn_and_labour_post_balanced_project_coded_entries(client):
    ctx = setup(client, labour=True)
    A = ctx["A"]
    received_po(client, ctx, "100", "1000", "100")
    assert closing(client, ctx["h"], A["2100"]) == 100000                   # GRNI liability
    assert closing(client, ctx["h"], A["5000"], project_id=ctx["project"]["id"]) == 100000   # project material cost
    hr, fm = add_user(client, ctx["h"], "hr@alpha.pk", "HR_ADMIN"), add_user(client, ctx["h"], "fm@alpha.pk", "FOREMAN")
    w = post(client, hr, "/workers", {"code": "W1", "name": "Mason", "daily_rate": "1500", "cost_code_id": ctx["lab_cc"]}, 201)
    s = post(client, fm, "/attendance-sheets", {"project_id": ctx["project"]["id"], "work_date": TODAY,
                                                "entries": [{"worker_id": w["id"], "status": "PRESENT"}]}, 201)
    post(client, fm, f"/attendance-sheets/{s['id']}/submit")
    assert closing(client, ctx["h"], A["2200"]) == 0                        # nothing before approval
    post(client, ctx["u"]["PROJECT_MANAGER"], f"/attendance-sheets/{s['id']}/approve")
    assert closing(client, ctx["h"], A["2200"]) == 1500 and closing(client, ctx["h"], A["5100"]) == 1500
    kinds = {e["source_type"] for e in client.get("/journal-entries", headers=ctx["h"]).json()}
    assert {"GRN", "LABOUR"} <= kinds
    t = tb(client, ctx)
    assert D(t["total_debit"]) == 101500


def test_clean_three_way_match_posts_to_payables(client):
    ctx = setup(client)
    po, s = received_po(client, ctx, "100", "1000", "100")
    inv = invoice(client, ctx, po, "100", "1000", "SI-001")
    assert inv["status"] == "POSTED" and inv["exceptions"] == [] and D(inv["outstanding"]) == 100000
    assert closing(client, ctx["h"], ctx["A"]["2100"]) == 0                 # GRNI cleared
    assert closing(client, ctx["h"], ctx["A"]["2000"]) == 100000            # payable recognised
    dup = invoice(client, ctx, po, "100", "1000", "SI-001", expect=409)
    assert "duplicate" in dup["detail"].lower()
    bad = invoice(client, ctx, po, "10", "1000", "SI-002", stated="9000")   # stated total != lines
    assert bad["status"] == "MATCH_EXCEPTION" and bad["exceptions"][0]["type"] in ("TOTAL_MISMATCH", "QTY_EXCEEDS_RECEIVED")
    tb(client, ctx)


def test_spec_example_po_100_grn_100_invoice_120(client):
    ctx = setup(client)
    po, s = received_po(client, ctx, "100", "1000", "100")
    inv = invoice(client, ctx, po, "120", "1000", "SI-120")
    assert inv["status"] == "MATCH_EXCEPTION"
    assert [e["type"] for e in inv["exceptions"]] == ["QTY_EXCEEDS_RECEIVED"]
    assert inv["exceptions"][0]["message"] == "Invoice quantity exceeds received quantity by 20"
    assert closing(client, ctx["h"], ctx["A"]["2000"]) == 0                 # nothing posted, nothing payable
    assert D(inv["outstanding"]) == 0
    # cannot be paid, cannot be accepted (quantity problems are never waved through), accountant cannot resolve
    pay = {"supplier_id": s["id"], "account_id": ctx["A"]["1010"], "payment_date": TODAY,
           "allocations": [{"invoice_id": inv["id"], "amount": "1000"}]}
    assert client.post("/payments", headers=ctx["acct"], json=pay).status_code == 409
    res = {"action": "ACCEPT", "comment": "supplier says ok"}
    assert client.post(f"/supplier-invoices/{inv['id']}/resolve", headers=ctx["acct"], json=res).status_code == 403
    r = client.post(f"/supplier-invoices/{inv['id']}/resolve", headers=ctx["h"], json=res)
    assert r.status_code == 409 and "Only rate differences" in r.json()["detail"]
    rej = post(client, ctx["h"], f"/supplier-invoices/{inv['id']}/resolve", {"action": "REJECT", "comment": "over-billed"})
    assert rej["status"] == "REJECTED"
    ok = invoice(client, ctx, po, "100", "1000", "SI-120-CORR")             # rejected invoices do not consume quantity
    assert ok["status"] == "POSTED"
    assert client.post(f"/supplier-invoices/{ok['id']}/resolve", headers=ctx["h"], json=res).status_code == 409


def test_cumulative_invoicing_against_partial_receipts(client):
    ctx = setup(client)
    po, _ = received_po(client, ctx, "100", "1000", "60")
    assert invoice(client, ctx, po, "60", "1000", "A1")["status"] == "POSTED"
    e = invoice(client, ctx, po, "10", "1000", "A2")
    assert e["status"] == "MATCH_EXCEPTION" and e["exceptions"][0]["message"].endswith("by 10")
    grn(client, ctx, po, "40")
    assert invoice(client, ctx, po, "40", "1000", "A3")["status"] == "POSTED"
    assert invoice(client, ctx, po, "1", "1000", "A4")["status"] == "MATCH_EXCEPTION"


def test_rate_variance_accept_posts_variance_to_project_cost_and_budget(client):
    ctx = setup(client)
    po, _ = received_po(client, ctx, "100", "1000", "100")
    inv = invoice(client, ctx, po, "100", "1100", "SI-R")
    assert [e["type"] for e in inv["exceptions"]] == ["RATE_MISMATCH"] and inv["status"] == "MATCH_EXCEPTION"
    before = budget_totals(client, ctx)
    assert D(before["actual"]) == 100000
    ok = post(client, ctx["h"], f"/supplier-invoices/{inv['id']}/resolve", {"action": "ACCEPT", "comment": "price list updated"})
    assert ok["status"] == "POSTED" and D(ok["outstanding"]) == 110000
    A = ctx["A"]
    assert closing(client, ctx["h"], A["2000"]) == 110000 and closing(client, ctx["h"], A["2100"]) == 0
    assert closing(client, ctx["h"], A["5000"], project_id=ctx["project"]["id"]) == 110000   # 100,000 + 10,000 variance
    t = budget_totals(client, ctx)
    assert D(t["actual"]) == 110000 and D(t["committed"]) == 110000                            # variance counts as cost
    # cheaper invoice: variance is a credit and reduces cost
    po2, _ = received_po(client, ctx, "10", "1000", "10", supplier="Other Dealer")
    inv2 = invoice(client, ctx, po2, "10", "900", "SI-C")
    post(client, ctx["h"], f"/supplier-invoices/{inv2['id']}/resolve", {"action": "ACCEPT", "comment": "discount"})
    assert D(budget_totals(client, ctx)["actual"]) == 110000 + 10000 - 1000
    tb(client, ctx)


def test_payment_approval_controls_and_budget_paid(client):
    ctx = setup(client)
    A, h, pm = ctx["A"], ctx["h"], ctx["u"]["PROJECT_MANAGER"]
    po, s = received_po(client, ctx, "100", "1000", "100")
    inv = invoice(client, ctx, po, "100", "1000", "SI-P")
    mk = lambda amt, who=None: client.post("/payments", headers=who or ctx["acct"], json={  # noqa: E731
        "supplier_id": s["id"], "account_id": A["1010"], "payment_date": TODAY,
        "allocations": [{"invoice_id": inv["id"], "amount": amt}]})
    p1 = mk("40000").json()
    assert p1["status"] == "PENDING_APPROVAL" and D(p1["amount"]) == 40000
    assert mk("70000").status_code == 409                                   # 40k is reserved, only 60k available
    assert mk("60000").status_code == 201
    assert client.post("/payments", headers=ctx["acct"], json={"supplier_id": s["id"], "account_id": A["5000"], "payment_date": TODAY,
                                                              "allocations": [{"invoice_id": inv["id"], "amount": "1"}]}).status_code == 422
    assert client.post(f"/payments/{p1['id']}/approve", headers=pm, json={}).status_code == 403          # PM: no finance.approve
    assert D(budget_totals(client, ctx)["paid"]) == 0                       # nothing paid before approval
    done = post(client, h, f"/payments/{p1['id']}/approve", {"comment": "ok"})
    assert done["status"] == "APPROVED"
    after = client.get(f"/supplier-invoices/{inv['id']}", headers=h).json()
    assert after["status"] == "PARTIALLY_PAID" and D(after["outstanding"]) == 60000
    assert closing(client, h, A["2000"]) == 60000 and closing(client, h, A["1010"]) == -40000
    t = budget_totals(client, ctx)
    assert D(t["paid"]) == 40000 and D(t["paid"]) <= D(t["actual"]) <= D(t["committed"])
    p2 = client.get("/payments?status=PENDING_APPROVAL", headers=h).json()[0]
    post(client, h, f"/payments/{p2['id']}/approve")
    assert client.get(f"/supplier-invoices/{inv['id']}", headers=h).json()["status"] == "PAID"
    assert closing(client, h, A["2000"]) == 0 and D(budget_totals(client, ctx)["paid"]) == 100000
    assert client.post(f"/payments/{p2['id']}/approve", headers=h, json={}).status_code == 409           # not twice
    assert mk("1").status_code == 409                                       # paid invoices cannot be paid again
    tb(client, ctx)


def test_creator_cannot_approve_own_payment_and_limit_applies(client):
    ctx = setup(client)
    A, h = ctx["A"], ctx["h"]
    po, s = received_po(client, ctx, "100", "1000", "100")
    inv = invoice(client, ctx, po, "100", "1000", "SI-L")
    body = lambda amt: {"supplier_id": s["id"], "account_id": A["1010"], "payment_date": TODAY,   # noqa: E731
                        "allocations": [{"invoice_id": inv["id"], "amount": amt}]}
    mine = post(client, h, "/payments", body("10000"), 201)                 # owner creates...
    r = client.post(f"/payments/{mine['id']}/approve", headers=h, json={})
    assert r.status_code == 403 and "created it" in r.json()["detail"]         # ...but cannot approve own payment
    big = post(client, ctx["acct"], "/payments", body("60000"), 201)
    with SessionLocal() as db:                                              # tighten the owner's limit
        for role in db.query(Role).filter(Role.name == "OWNER"):
            role.approval_limit = 50000
        db.commit()
    r = client.post(f"/payments/{big['id']}/approve", headers=h, json={})
    assert r.status_code == 403 and "approval limit" in r.json()["detail"]
    rej = client.post(f"/payments/{big['id']}/reject", headers=h, json={"comment": ""})
    assert rej.status_code == 422
    post(client, h, f"/payments/{big['id']}/reject", {"comment": "needs second signature"})
    small = post(client, ctx["acct"], "/payments", body("30000"), 201)      # reservation freed by the rejection
    post(client, h, f"/payments/{small['id']}/approve")
    post(client, ctx["acct"], f"/payments/{mine['id']}/cancel")
    acts = {e["action"] for e in client.get("/audit-logs?limit=500", headers=h).json()}
    assert {"payment.create", "payment.approve", "payment.reject", "payment.cancel"} <= acts


def test_expenses_budget_cash_and_limits(client):
    ctx = setup(client, labour=True)
    A, h, pm, eng = ctx["A"], ctx["h"], ctx["u"]["PROJECT_MANAGER"], ctx["u"]["SITE_ENGINEER"]
    post(client, ctx["acct"], "/journal-entries", {"entry_date": TODAY, "description": "Opening capital", "lines": [
        {"account_id": A["1000"], "debit": "500000"}, {"account_id": A["3000"], "credit": "500000"}]}, 201)
    ex = lambda amt, cc=None, acct=None: client.post("/expenses", headers=eng, json={  # noqa: E731
        "project_id": ctx["project"]["id"], "cost_code_id": cc or ctx["lab_cc"], "expense_date": TODAY, "amount": amt,
        "payee": "Local contractor", "description": "Casual labour", "paid_from_account_id": acct or A["1000"]})
    small = ex("20000").json()
    assert small["status"] == "PENDING_APPROVAL"
    assert client.post(f"/expenses/{small['id']}/approve", headers=eng, json={}).status_code == 403   # engineer cannot approve
    post(client, pm, f"/expenses/{small['id']}/approve", {"comment": "ok"})
    t = budget_totals(client, ctx)
    assert D(t["actual"]) == 20000 and D(t["committed"]) == 20000 and D(t["paid"]) == 20000
    assert closing(client, h, A["1000"]) == 480000 and closing(client, h, A["5100"]) == 20000
    big = ex("60000").json()
    r = client.post(f"/expenses/{big['id']}/approve", headers=pm, json={})
    assert r.status_code == 403 and "approval limit" in r.json()["detail"]
    post(client, h, f"/expenses/{big['id']}/approve")
    oth = post(client, h, "/cost-codes", {"code": "C-OTH", "name": "Other", "category": "OTHER"}, 201)["id"]
    nobudget = ex("1000", cc=oth).json()
    r = client.post(f"/expenses/{nobudget['id']}/approve", headers=h, json={})
    assert r.status_code == 409 and "No approved budget line" in r.json()["detail"]
    assert client.get("/expenses?status=PENDING_APPROVAL", headers=h).json()[0]["id"] == nobudget["id"]   # still pending
    assert closing(client, h, A["1000"]) == 500000 - 80000                                                  # nothing leaked
    assert ex("500", acct=A["5000"]).status_code == 422                                                      # must be cash/bank
    post(client, pm, f"/expenses/{nobudget['id']}/reject", {"comment": "no budget"})
    assert client.post(f"/expenses/{nobudget['id']}/reject", headers=pm, json={"comment": "again"}).status_code == 409
    tb(client, ctx)


def test_manual_journal_rules_and_reversal(client):
    ctx = setup(client)
    A, h, acct = ctx["A"], ctx["h"], ctx["acct"]
    j = lambda lines, who=None: client.post("/journal-entries", headers=who or acct, json={  # noqa: E731
        "entry_date": TODAY, "description": "Test entry", "lines": lines})
    assert j([{"account_id": A["1000"], "debit": "100"}, {"account_id": A["3000"], "credit": "99"}]).status_code == 422
    assert j([{"account_id": A["1000"], "debit": "100", "credit": "100"}, {"account_id": A["3000"], "credit": "0"}]).status_code == 422
    r = j([{"account_id": A["2000"], "debit": "100"}, {"account_id": A["3000"], "credit": "100"}])
    assert r.status_code == 422 and "control account" in r.json()["detail"]
    ok = j([{"account_id": A["1010"], "debit": "250000"}, {"account_id": A["3000"], "credit": "250000"}])
    assert ok.status_code == 201
    e = ok.json()
    assert client.post(f"/journal-entries/{e['id']}/reverse", headers=acct, json={"reason": "wrong bank"}).status_code == 403
    rev = client.post(f"/journal-entries/{e['id']}/reverse", headers=h, json={"reason": "wrong bank"})
    assert rev.status_code == 201 and rev.json()["reversal_of"] == e["id"]
    assert closing(client, h, A["1010"]) == 0
    assert client.post(f"/journal-entries/{e['id']}/reverse", headers=h, json={"reason": "again"}).status_code == 409
    assert client.post(f"/journal-entries/{rev.json()['id']}/reverse", headers=h, json={"reason": "undo"}).status_code == 409
    received_po(client, ctx, "10", "1000", "10")
    grn_entry = client.get("/journal-entries?source_type=GRN", headers=h).json()[0]
    assert client.post(f"/journal-entries/{grn_entry['id']}/reverse", headers=h, json={"reason": "not allowed"}).status_code == 409
    led = client.get(f"/accounts/{A['3000']}/ledger", headers=h).json()
    assert [r["balance"] for r in led["rows"]] == ["250000.00", "0.00"]
    tb(client, ctx)


def test_payables_aging_buckets_and_ap_reconciliation(client):
    ctx = setup(client)
    po1, s1 = received_po(client, ctx, "10", "1000", "10", supplier="S1")
    po2, s2 = received_po(client, ctx, "20", "1000", "20", supplier="S2")
    po3, s3 = received_po(client, ctx, "30", "1000", "30", supplier="S3")
    late = str(local_today() - timedelta(days=45))
    invoice(client, ctx, po1, "10", "1000", "X1", due=late, date="2025-01-01")
    invoice(client, ctx, po2, "20", "1000", "X2", due=str(local_today() + timedelta(days=10)))
    invoice(client, ctx, po3, "30", "1000", "X3", due=str(local_today() - timedelta(days=400)), date="2024-01-01")
    a = client.get("/reports/payables-aging", headers=ctx["h"]).json()
    by = {r["supplier"]: r for r in a["suppliers"]}
    assert D(by["S1"]["d31_60"]) == 10000 and D(by["S2"]["not_due"]) == 20000 and D(by["S3"]["d90_plus"]) == 30000
    assert D(a["totals"]["total"]) == 60000
    assert closing(client, ctx["h"], ctx["A"]["2000"]) == D(a["totals"]["total"])          # sub-ledger == control account


def test_finance_isolation_and_rbac(client):
    ctx = setup(client)
    po, s = received_po(client, ctx, "10", "1000", "10")
    inv = invoice(client, ctx, po, "10", "1000", "ISO-1")
    pay = post(client, ctx["acct"], "/payments", {"supplier_id": s["id"], "account_id": ctx["A"]["1010"], "payment_date": TODAY,
                                                  "allocations": [{"invoice_id": inv["id"], "amount": "1000"}]}, 201)
    hb = register(client, "Beta", "b@beta.pk")
    for url in (f"/supplier-invoices/{inv['id']}", f"/payments/{pay['id']}"):
        assert client.get(url, headers=hb).status_code == 404
    assert client.post(f"/payments/{pay['id']}/approve", headers=hb, json={}).status_code == 404
    assert client.post(f"/supplier-invoices/{inv['id']}/resolve", headers=hb, json={"action": "REJECT", "comment": "xxx"}).status_code == 404
    assert client.get("/supplier-invoices", headers=hb).json() == [] and client.get("/payments", headers=hb).json() == []
    assert client.get(f"/accounts/{ctx['A']['1010']}/ledger", headers=hb).status_code == 404
    assert client.get("/journal-entries", headers=hb).json() == []
    B = accounts(client, hb)
    assert set(B.values()).isdisjoint(ctx["A"].values())                     # each organisation has its own chart
    assert client.post("/supplier-invoices", headers=hb, json={"po_id": po["id"], "supplier_invoice_no": "Z", "invoice_date": TODAY,
                                                              "due_date": TODAY, "stated_total": "1", "lines": [
                                                                  {"po_line_id": po["lines"][0]["id"], "quantity": "1", "unit_rate": "1"}]}).status_code == 422
    foreman = add_user(client, ctx["h"], "fm@alpha.pk", "FOREMAN")
    storekeeper = ctx["u"]["STOREKEEPER"]
    for who in (foreman, storekeeper):
        assert client.get("/trial-balance", headers=who).status_code == 403
        assert client.get("/supplier-invoices", headers=who).status_code == 403
    assert client.post("/supplier-invoices", headers=ctx["u"]["PROCUREMENT_OFFICER"], json={}).status_code == 403
