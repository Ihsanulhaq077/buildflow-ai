from datetime import timedelta
from decimal import Decimal as D
from io import BytesIO

from pypdf import PdfReader

from app.timeutil import local_today
from tests.helpers import accounts, add_user, bootstrap, closing, grn, invoice, mk_project, post, received_po, register

TODAY = local_today()
T = str(TODAY)


def setup(client, retention="5", **kw):
    ctx = bootstrap(client, **kw)
    h = ctx["h"]
    ctx["acct"] = add_user(client, h, "acc@alpha.pk", "ACCOUNTANT")
    ctx["pm"] = ctx["u"]["PROJECT_MANAGER"]
    ctx["A"] = accounts(client, h)
    c = post(client, h, "/clients", {"name": "Gulf Developers"}, 201)
    ctx["client_id"] = c["id"]
    assert client.patch(f"/projects/{ctx['project']['id']}", headers=h, json={"client_id": c["id"]}).status_code == 200
    post(client, h, f"/projects/{ctx['project']['id']}/contracts", {
        "contract_no": "C-1", "title": "Main contract", "value": "5000000", "retention_pct": retention}, 201)
    return ctx


def tb(client, ctx):
    r = client.get("/trial-balance", headers=ctx["h"]).json()
    assert r["balanced"] is True
    return r


def run_line(ctx, cum, rate=None):
    l = {"boq_item_id": ctx["boq_item"]["id"], "cumulative_quantity": cum}
    if rate:
        l["contract_rate"] = rate
    return l


def mk_bill(client, ctx, lines, deductions=None, who=None, bill_type="RUNNING", date=None, due=None, project_id=None, expect=201):
    return post(client, who or ctx["pm"], "/client-bills", {
        "project_id": project_id or ctx["project"]["id"], "bill_type": bill_type, "bill_date": date or T,
        "due_date": due or str(TODAY + timedelta(days=30)), "lines": lines, "deductions": deductions or []}, expect)


def milestone(amount, desc="Foundation complete"):
    return [{"description": desc, "amount": amount}]


def certify(client, ctx, bill):
    post(client, ctx["pm"], f"/client-bills/{bill['id']}/submit")
    return post(client, ctx["h"], f"/client-bills/{bill['id']}/approve", {"comment": "certified"})


def receipt(client, ctx, bill_allocs=None, kind="PAYMENT", amount=None, account="1010", project=True, approve=True, expect=201):
    body = {"client_id": ctx["client_id"], "kind": kind, "account_id": ctx["A"][account], "receipt_date": T}
    if bill_allocs:
        body["allocations"] = [{"bill_id": b, "amount": a} for b, a in bill_allocs]
    if amount:
        body["amount"] = amount
    if kind == "RETENTION_RELEASE" and project:
        body["project_id"] = ctx["project"]["id"]
    r = post(client, ctx["acct"], "/client-receipts", body, expect)
    if approve and expect == 201:
        r = post(client, ctx["h"], f"/client-receipts/{r['id']}/approve")
    return r


def test_running_bill_lifecycle_and_journal(client):
    ctx = setup(client)
    h, pm, A = ctx["h"], ctx["pm"], ctx["A"]
    noclient = mk_project(client, h, code="NC")
    r = client.post("/client-bills", headers=pm, json={"project_id": noclient["id"], "bill_type": "MILESTONE", "bill_date": T,
                                                     "due_date": T, "lines": milestone("1000")})
    assert r.status_code == 422 and "client" in r.json()["detail"]
    b = mk_bill(client, ctx, [run_line(ctx, "400", "2500")],
                [{"type": "TAX_WITHHELD", "description": "WHT 2%", "amount": "20000"}, {"type": "PENALTY", "amount": "10000"}])
    assert (D(b["gross_amount"]), D(b["retention_amount"]), D(b["deductions_total"]), D(b["net_payable"])) == (
        D("1000000"), D("50000"), D("30000"), D("920000"))
    assert b["status"] == "DRAFT" and b["bill_no"] == 1 and b["certificate_no"] == "" and D(b["lines"][0]["previous_quantity"]) == 0
    post(client, pm, f"/client-bills/{b['id']}/submit")
    assert client.post(f"/client-bills/{b['id']}/approve", headers=pm, json={}).status_code == 403          # PM cannot certify
    assert closing(client, h, A["4000"]) == 0                                                               # nothing before approval
    ok = post(client, h, f"/client-bills/{b['id']}/approve", {"comment": "certified"})
    assert ok["status"] == "APPROVED" and ok["certificate_no"] == "CERT-ABC-01-001" and D(ok["outstanding"]) == 920000
    assert closing(client, h, A["1100"]) == 920000 and closing(client, h, A["1300"]) == 50000
    assert closing(client, h, A["1400"]) == 20000 and closing(client, h, A["4900"]) == -10000   # contra-revenue: debit balance
    assert closing(client, h, A["4000"], project_id=ctx["project"]["id"]) == 1000000
    tb(client, ctx)
    # next bill continues from what was certified
    assert client.post("/client-bills", headers=pm, json={"project_id": ctx["project"]["id"], "bill_type": "RUNNING", "bill_date": T,
                                                         "due_date": T, "lines": [run_line(ctx, "400")]}).status_code == 422
    assert client.post("/client-bills", headers=pm, json={"project_id": ctx["project"]["id"], "bill_type": "RUNNING", "bill_date": T,
                                                         "due_date": T, "lines": [run_line(ctx, "1100")]}).status_code == 422
    b2 = mk_bill(client, ctx, [run_line(ctx, "1000", "2500")])
    assert D(b2["lines"][0]["previous_quantity"]) == 400 and D(b2["lines"][0]["quantity"]) == 600 and D(b2["gross_amount"]) == 1500000
    assert b2["bill_no"] == 2
    # default contract rate (BOQ has no mark-up here) = BOQ unit rate
    b3 = mk_bill(client, ctx, [run_line(ctx, "500")])
    assert D(b3["lines"][0]["contract_rate"]) == D("2000.00") and D(b3["gross_amount"]) == 200000
    # deductions larger than gross are refused; approved bills are frozen
    assert client.post("/client-bills", headers=pm, json={"project_id": ctx["project"]["id"], "bill_type": "MILESTONE", "bill_date": T,
                                                         "due_date": T, "lines": milestone("1000"),
                                                         "deductions": [{"type": "OTHER", "amount": "5000"}]}).status_code == 422
    assert client.put(f"/client-bills/{b['id']}", headers=pm, json={"lines": milestone("1")}).status_code == 409
    assert client.post(f"/client-bills/{b['id']}/cancel", headers=pm).status_code == 409


def test_stale_draft_bill_is_blocked(client):
    ctx = setup(client)
    a = mk_bill(client, ctx, [run_line(ctx, "500", "2500")])
    b = mk_bill(client, ctx, [run_line(ctx, "600", "2500")])                 # both prepared against 0 certified
    certify(client, ctx, a)
    r = client.post(f"/client-bills/{b['id']}/submit", headers=ctx["pm"])
    assert r.status_code == 409 and "recalculated" in r.json()["detail"]
    fixed = client.put(f"/client-bills/{b['id']}", headers=ctx["pm"], json={"lines": [run_line(ctx, "600", "2500")]}).json()
    assert D(fixed["lines"][0]["previous_quantity"]) == 500 and D(fixed["lines"][0]["quantity"]) == 100
    post(client, ctx["pm"], f"/client-bills/{b['id']}/submit")


def test_contract_ceiling_and_variations(client):
    ctx = setup(client)
    h, pm = ctx["h"], ctx["pm"]
    first = certify(client, ctx, mk_bill(client, ctx, milestone("4000000"), bill_type="MILESTONE"))
    assert D(first["retention_amount"]) == 200000
    big = mk_bill(client, ctx, milestone("1500000", "Slab"), bill_type="MILESTONE")
    r = client.post(f"/client-bills/{big['id']}/submit", headers=pm)
    assert r.status_code == 409 and "exceed the contract value" in r.json()["detail"]        # 5.5M > 5.0M
    v = post(client, pm, "/client-variations", {"project_id": ctx["project"]["id"], "title": "Extra basement", "amount": "1000000"}, 201)
    assert v["status"] == "PENDING_APPROVAL" and v["number"] == "VAR-00001"
    assert client.post(f"/client-variations/{v['id']}/approve", headers=pm, json={}).status_code == 403
    assert client.post(f"/client-variations/{v['id']}/reject", headers=h, json={"comment": ""}).status_code == 422
    post(client, h, f"/client-variations/{v['id']}/approve", {"comment": "client signed"})
    s = client.get(f"/projects/{ctx['project']['id']}/billing-summary", headers=h).json()
    assert D(s["revised_contract_value"]) == 6000000 and D(s["approved_variations"]) == 1000000
    assert D(s["gross_billed_to_date"]) == 4000000 and D(s["remaining_to_bill"]) == 2000000 and D(s["retention_held"]) == 200000
    post(client, pm, f"/client-bills/{big['id']}/submit")                                    # fits now
    omit = post(client, pm, "/client-variations", {"project_id": ctx["project"]["id"], "title": "Omit roof", "amount": "-3000000"}, 201)
    r = client.post(f"/client-variations/{omit['id']}/approve", headers=h, json={})
    assert r.status_code == 409 and "below what has already been billed" in r.json()["detail"]
    post(client, h, f"/client-variations/{omit['id']}/reject", {"comment": "not agreed"})
    assert client.post(f"/client-variations/{omit['id']}/reject", headers=h, json={"comment": "again"}).status_code == 409


def test_bill_reject_cancel_and_certificate_pdf(client):
    ctx = setup(client)
    h, pm = ctx["h"], ctx["pm"]
    b = mk_bill(client, ctx, milestone("1000000", "Plinth <beam> & columns"), bill_type="MILESTONE")
    assert client.get(f"/client-bills/{b['id']}/certificate", headers=h).status_code == 409   # not certified yet
    post(client, pm, f"/client-bills/{b['id']}/submit")
    assert client.post(f"/client-bills/{b['id']}/reject", headers=h, json={"comment": ""}).status_code == 422
    rej = post(client, h, f"/client-bills/{b['id']}/reject", {"comment": "quantities disputed"})
    assert rej["status"] == "REJECTED" and client.post(f"/client-bills/{b['id']}/submit", headers=pm).status_code == 409
    assert D(client.get(f"/projects/{ctx['project']['id']}/billing-summary", headers=h).json()["gross_billed_to_date"]) == 0
    c = mk_bill(client, ctx, milestone("1000000", "Plinth <beam> & columns"), bill_type="MILESTONE",
                deductions=[{"type": "TAX_WITHHELD", "description": "WHT", "amount": "10000"}])
    post(client, pm, f"/client-bills/{c['id']}/cancel")
    d = certify(client, ctx, mk_bill(client, ctx, milestone("1000000", "Plinth <beam> & columns"), bill_type="MILESTONE",
                                     deductions=[{"type": "TAX_WITHHELD", "description": "WHT", "amount": "10000"}]))
    r = client.get(f"/client-bills/{d['id']}/certificate", headers=h)
    assert r.status_code == 200 and r.content[:5] == b"%PDF-" and "CERT-ABC-01-003.pdf" in r.headers["content-disposition"]
    text = "\n".join(p.extract_text() for p in PdfReader(BytesIO(r.content)).pages)
    for needle in ("Payment Certificate", d["certificate_no"], "ABC-01 - ABC Plaza", "Gulf Developers", "Plinth <beam> & columns",
                   "940000.00"):
        assert needle in text, needle                                                          # net = 1,000,000 - 50,000 - 10,000
    hb = register(client, "Beta", "b@beta.pk")
    assert client.get(f"/client-bills/{d['id']}/certificate", headers=hb).status_code == 404


def test_receipts_settle_bills_and_reconcile_receivables(client):
    ctx = setup(client)
    h, A = ctx["h"], ctx["A"]
    b = certify(client, ctx, mk_bill(client, ctx, milestone("1000000"), bill_type="MILESTONE"))      # net 950,000
    assert D(b["net_payable"]) == 950000
    r1 = receipt(client, ctx, [(b["id"], "500000")], approve=False)
    assert r1["status"] == "PENDING_APPROVAL" and closing(client, h, A["1010"]) == 0
    assert client.post(f"/client-receipts/{r1['id']}/approve", headers=ctx["acct"], json={}).status_code == 403   # no finance.approve
    own = post(client, h, "/client-receipts", {"client_id": ctx["client_id"], "kind": "PAYMENT", "account_id": A["1010"],
                                              "receipt_date": T, "allocations": [{"bill_id": b["id"], "amount": "1000"}]}, 201)
    r = client.post(f"/client-receipts/{own['id']}/approve", headers=h, json={})
    assert r.status_code == 403 and "created it" in r.json()["detail"]
    over = client.post("/client-receipts", headers=ctx["acct"], json={"client_id": ctx["client_id"], "kind": "PAYMENT", "account_id": A["1010"],
                                                                    "receipt_date": T, "allocations": [{"bill_id": b["id"], "amount": "460000"}]})
    assert over.status_code == 409                                                                   # 500k + 1k pending leave 449k
    post(client, h, f"/client-receipts/{r1['id']}/approve", {"comment": "bank statement checked"})
    got = client.get(f"/client-bills/{b['id']}", headers=h).json()
    assert got["status"] == "PARTIALLY_PAID" and D(got["outstanding"]) == 450000
    assert closing(client, h, A["1010"]) == 500000 and closing(client, h, A["1100"]) == 450000
    post(client, ctx["acct"], f"/client-receipts/{own['id']}/cancel")
    receipt(client, ctx, [(b["id"], "450000")])
    assert client.get(f"/client-bills/{b['id']}", headers=h).json()["status"] == "PAID"
    assert closing(client, h, A["1100"]) == 0
    assert client.post("/client-receipts", headers=ctx["acct"], json={"client_id": ctx["client_id"], "kind": "PAYMENT", "account_id": A["1010"],
                                                                    "receipt_date": T, "allocations": [{"bill_id": b["id"], "amount": "1"}]}).status_code == 409
    other = post(client, h, "/clients", {"name": "Someone Else"}, 201)
    bad = client.post("/client-receipts", headers=ctx["acct"], json={"client_id": other["id"], "kind": "PAYMENT", "account_id": A["1010"],
                                                                   "receipt_date": T, "allocations": [{"bill_id": b["id"], "amount": "1"}]})
    assert bad.status_code in (409, 422)
    assert client.post("/client-receipts", headers=ctx["acct"], json={"client_id": ctx["client_id"], "kind": "ADVANCE", "account_id": A["4000"],
                                                                    "receipt_date": T, "amount": "10"}).status_code == 422    # not a cash account
    assert client.post("/client-receipts", headers=ctx["acct"], json={"client_id": ctx["client_id"], "kind": "PAYMENT", "account_id": A["1010"],
                                                                    "receipt_date": T, "amount": "5", "allocations": []}).status_code == 422
    tb(client, ctx)


def test_receivables_aging_buckets_reconcile_to_control_account(client):
    ctx = setup(client)
    h, A = ctx["h"], ctx["A"]
    old = certify(client, ctx, mk_bill(client, ctx, milestone("100000", "Old"), bill_type="MILESTONE", date="2025-01-01", due="2025-02-01"))
    mid = certify(client, ctx, mk_bill(client, ctx, milestone("200000", "Mid"), bill_type="MILESTONE", date="2026-06-01",
                                       due=str(TODAY - timedelta(days=45))))
    fut = certify(client, ctx, mk_bill(client, ctx, milestone("300000", "Future"), bill_type="MILESTONE", due=str(TODAY + timedelta(days=15))))
    receipt(client, ctx, [(old["id"], "35000")])
    a = client.get("/reports/receivables-aging", headers=h).json()
    row = a["clients"][0]
    assert row["client"] == "Gulf Developers" and D(row["d90_plus"]) == 60000 and D(row["d31_60"]) == 190000 and D(row["not_due"]) == 285000
    assert D(a["totals"]["total"]) == 535000
    assert closing(client, h, A["1100"]) == D(a["totals"]["total"])                                  # sub-ledger == control account


def test_advance_receipt_and_recovery_through_bill(client):
    ctx = setup(client)
    h, A = ctx["h"], ctx["A"]
    receipt(client, ctx, kind="ADVANCE", amount="300000")
    assert closing(client, h, A["2300"]) == 300000 and closing(client, h, A["1010"]) == 300000
    too_much = mk_bill(client, ctx, milestone("1000000"), bill_type="MILESTONE", deductions=[{"type": "ADVANCE_RECOVERY", "amount": "400000"}])
    post(client, ctx["pm"], f"/client-bills/{too_much['id']}/submit")
    r = client.post(f"/client-bills/{too_much['id']}/approve", headers=h, json={})
    assert r.status_code == 409 and "Advance recovery exceeds" in r.json()["detail"]
    assert closing(client, h, A["4000"]) == 0                                                         # rolled back cleanly
    post(client, ctx["pm"], f"/client-bills/{too_much['id']}/cancel")
    ok = certify(client, ctx, mk_bill(client, ctx, milestone("1000000"), bill_type="MILESTONE",
                                      deductions=[{"type": "ADVANCE_RECOVERY", "description": "20% recovery", "amount": "200000"}]))
    assert D(ok["net_payable"]) == 750000                                                              # 1,000,000 - 50,000 - 200,000
    assert closing(client, h, A["2300"]) == 100000
    s = client.get(f"/projects/{ctx['project']['id']}/billing-summary", headers=h).json()
    assert D(s["client_advance_balance"]) == 100000 and D(s["receivable_outstanding"]) == 750000
    tb(client, ctx)


def test_retention_release(client):
    ctx = setup(client)
    h, A = ctx["h"], ctx["A"]
    certify(client, ctx, mk_bill(client, ctx, milestone("1000000"), bill_type="MILESTONE"))           # retention 50,000
    assert closing(client, h, A["1300"]) == 50000
    assert client.post("/client-receipts", headers=ctx["acct"], json={"client_id": ctx["client_id"], "kind": "RETENTION_RELEASE",
                                                                    "account_id": A["1010"], "receipt_date": T, "amount": "10"}).status_code == 422  # project needed
    assert receipt(client, ctx, kind="RETENTION_RELEASE", amount="60000", expect=409)["detail"].startswith("Retention release of")
    r1 = receipt(client, ctx, kind="RETENTION_RELEASE", amount="30000", approve=False)
    assert receipt(client, ctx, kind="RETENTION_RELEASE", amount="30000", expect=409)                  # 30k already pending
    post(client, h, f"/client-receipts/{r1['id']}/approve")
    assert closing(client, h, A["1300"]) == 20000 and closing(client, h, A["1010"]) == 30000
    s = client.get(f"/projects/{ctx['project']['id']}/billing-summary", headers=h).json()
    assert D(s["retention_held"]) == 20000
    receipt(client, ctx, kind="RETENTION_RELEASE", amount="20000")
    assert closing(client, h, A["1300"]) == 0
    tb(client, ctx)


def test_project_and_company_pnl_with_overhead_allocation(client):
    ctx = setup(client)
    h, A = ctx["h"], ctx["A"]
    received_po(client, ctx, "100", "1000", "100")                                                    # 100,000 material cost
    certify(client, ctx, mk_bill(client, ctx, milestone("1000000"), bill_type="MILESTONE",
                                 deductions=[{"type": "PENALTY", "description": "delay LD", "amount": "10000"}]))
    p2 = mk_project(client, h, code="P2", contract_value="1000000")
    assert client.patch(f"/projects/{p2['id']}", headers=h, json={"client_id": ctx["client_id"]}).status_code == 200
    certify(client, ctx, mk_bill(client, ctx, milestone("500000", "P2 milestone"), bill_type="MILESTONE", project_id=p2["id"]))
    post(client, ctx["acct"], "/journal-entries", {"entry_date": T, "description": "Office rent", "lines": [
        {"account_id": A["6000"], "debit": "30000"}, {"account_id": A["1010"], "credit": "30000"}]}, 201)
    pid = ctx["project"]["id"]
    p = client.get(f"/projects/{pid}/pnl", headers=h).json()
    assert (D(p["revenue"]), D(p["revenue_deductions"]), D(p["net_revenue"])) == (1000000, 10000, 990000)
    assert D(p["total_direct_cost"]) == 100000 and D(p["gross_profit"]) == 890000 and D(p["gross_margin_pct"]) == D("89.90")
    assert [(c["code"], D(c["amount"])) for c in p["costs"]] == [("5000", D("100000"))]
    assert "allocated_overhead" not in p
    assert D(p["budget"]["revised"]) == 2000000 and D(p["budget"]["planned_margin"]) == 3000000 and D(p["budget"]["planned_margin_pct"]) == D("60.00")
    pa = client.get(f"/projects/{pid}/pnl", headers=h, params={"allocate_overhead": "true"}).json()
    pb = client.get(f"/projects/{p2['id']}/pnl", headers=h, params={"allocate_overhead": "true"}).json()
    assert D(pa["allocated_overhead"]) == D("19932.89") and D(pb["allocated_overhead"]) == D("10067.11")   # by net revenue share
    assert D(pa["allocated_overhead"]) + D(pb["allocated_overhead"]) == 30000
    assert D(pa["net_profit"]) == D("870067.11")
    c = client.get("/reports/pnl", headers=h).json()
    assert D(c["totals"]["net_revenue"]) == 1490000 and D(c["totals"]["gross_profit"]) == 1390000
    assert D(c["totals"]["unallocated_costs"]) == 30000 and D(c["totals"]["company_net_profit"]) == 1360000
    assert D(c["totals"]["unallocated_not_distributed"]) == 0 and [r["code"] for r in c["projects"]] == ["ABC-01", "P2"]
    future = client.get("/reports/pnl", headers=h, params={"date_from": str(TODAY + timedelta(days=5))}).json()
    assert future["projects"] == [] and D(future["totals"]["company_net_profit"]) == 0
    assert client.get(f"/projects/{pid}/pnl", headers=ctx["u"]["STOREKEEPER"]).status_code == 403


def test_cash_flow_and_forecast(client):
    ctx = setup(client, labour=True)
    h, A, eng, pm = ctx["h"], ctx["A"], ctx["u"]["SITE_ENGINEER"], ctx["pm"]
    post(client, ctx["acct"], "/journal-entries", {"entry_date": T, "description": "Opening capital", "lines": [
        {"account_id": A["1010"], "debit": "1000000"}, {"account_id": A["3000"], "credit": "1000000"}]}, 201)
    b = certify(client, ctx, mk_bill(client, ctx, milestone("1000000", "Slab"), bill_type="MILESTONE"))
    receipt(client, ctx, [(b["id"], "500000")])
    x = post(client, eng, "/expenses", {"project_id": ctx["project"]["id"], "cost_code_id": ctx["lab_cc"], "expense_date": T,
                                        "amount": "20000", "description": "Casual labour", "paid_from_account_id": A["1010"]}, 201)
    post(client, pm, f"/expenses/{x['id']}/approve")
    cf = client.get("/reports/cash-flow", headers=h).json()
    cats = {c["category"]: (D(c["inflow"]), D(c["outflow"])) for c in cf["categories"]}
    assert cats == {"Other (manual journals)": (1000000, 0), "Client receipts": (500000, 0), "Project expenses": (0, 20000)}
    assert D(cf["opening_cash"]) == 0 and D(cf["net_cash_flow"]) == 1480000 and D(cf["closing_cash"]) == 1480000
    bank = next(a for a in cf["cash_accounts"] if a["code"] == "1010")
    assert D(bank["balance"]) == 1480000 and cf["by_month"][-1]["month"] == TODAY.strftime("%Y-%m")
    later = client.get("/reports/cash-flow", headers=h, params={"date_from": str(TODAY + timedelta(days=1)),
                                                               "date_to": str(TODAY + timedelta(days=5))}).json()
    assert D(later["opening_cash"]) == 1480000 and D(later["net_cash_flow"]) == 0
    assert client.get("/reports/cash-flow", headers=h, params={"date_from": "2026-12-01", "date_to": "2026-01-01"}).status_code == 422
    # forecast: receivables and payables by due date (contractual, not a prediction)
    certify(client, ctx, mk_bill(client, ctx, milestone("100000", "Soon"), bill_type="MILESTONE", due=str(TODAY + timedelta(days=10))))
    certify(client, ctx, mk_bill(client, ctx, milestone("100000", "Later"), bill_type="MILESTONE", due=str(TODAY + timedelta(days=60))))
    certify(client, ctx, mk_bill(client, ctx, milestone("200000", "Late"), bill_type="MILESTONE", date="2025-01-01", due="2025-02-01"))
    po1, _ = received_po(client, ctx, "100", "1000", "100", supplier="S1")
    po2, _ = received_po(client, ctx, "10", "1000", "10", supplier="S2")
    invoice(client, ctx, po1, "100", "1000", "F1", due=str(TODAY + timedelta(days=5)), date=T)
    invoice(client, ctx, po2, "10", "1000", "F2", due="2025-03-01", date="2025-01-01")
    f = client.get("/reports/cash-forecast", headers=h).json()
    assert D(f["opening_cash"]) == 1480000
    assert D(f["receivables"]["overdue"]) == 190000 and D(f["receivables"]["due_in_period"]) == 95000 + 450000   # "Later" (60d) excluded
    assert D(f["payables"]["overdue"]) == 10000 and D(f["payables"]["due_in_period"]) == 100000
    due_refs = {i["party"] for i in f["items"]}
    assert "S1" in due_refs and "S2" in due_refs
    assert client.get("/reports/cash-forecast", headers=h, params={"days": 0}).status_code == 422
    seven = client.get("/reports/cash-forecast", headers=h, params={"days": 7}).json()
    assert D(seven["payables"]["due_in_period"]) == 100000 and D(seven["receivables"]["due_in_period"]) == 0
    assert D(seven["projected_closing_cash"]) == 1480000 + 190000 - 10000 - 100000


def test_billing_isolation_and_rbac(client):
    ctx = setup(client)
    h, A = ctx["h"], ctx["A"]
    b = certify(client, ctx, mk_bill(client, ctx, milestone("1000000"), bill_type="MILESTONE"))
    r = receipt(client, ctx, [(b["id"], "100000")], approve=False)
    v = post(client, ctx["pm"], "/client-variations", {"project_id": ctx["project"]["id"], "title": "Extra work", "amount": "5000"}, 201)
    hb = register(client, "Beta", "b@beta.pk")
    for url in (f"/client-bills/{b['id']}", f"/client-receipts/{r['id']}", f"/projects/{ctx['project']['id']}/pnl",
                f"/projects/{ctx['project']['id']}/billing-summary"):
        assert client.get(url, headers=hb).status_code == 404, url
    for url in (f"/client-bills/{b['id']}/cancel", f"/client-receipts/{r['id']}/approve", f"/client-variations/{v['id']}/approve"):
        assert client.post(url, headers=hb, json={}).status_code == 404, url
    for url in ("/client-bills", "/client-receipts", "/client-variations"):
        assert client.get(url, headers=hb).json() == []
    assert client.get("/reports/receivables-aging", headers=hb).json()["clients"] == []
    pb = mk_project(client, hb, code="B1")
    assert client.post("/client-bills", headers=hb, json={"project_id": ctx["project"]["id"], "bill_type": "MILESTONE", "bill_date": T,
                                                         "due_date": T, "lines": milestone("1")}).status_code == 422
    eng, store = ctx["u"]["SITE_ENGINEER"], ctx["u"]["STOREKEEPER"]
    assert client.post("/client-bills", headers=eng, json={}).status_code == 403
    assert client.get("/client-bills", headers=store).status_code == 403
    assert client.get("/reports/cash-flow", headers=store).status_code == 403
    assert client.post("/client-receipts", headers=ctx["pm"], json={}).status_code == 403              # PM cannot take cash
    assert client.post("/client-bills", headers=ctx["acct"], json={"project_id": ctx["project"]["id"], "bill_type": "MILESTONE",
                                                                  "bill_date": T, "due_date": T, "lines": milestone("5")}).status_code == 201
    acts = {e["action"] for e in client.get("/audit-logs?limit=500", headers=h).json()}
    assert {"clientbill.create", "clientbill.approve", "receipt.create", "variation.create"} <= acts
