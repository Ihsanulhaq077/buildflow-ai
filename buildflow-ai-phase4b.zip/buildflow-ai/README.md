# BuildFlow AI — Phase 1 Foundation

Auth (JWT access+refresh, Argon2), multi-tenant organizations, configurable RBAC, audit log, Docker.

## Run
```bash
cp .env.example .env        # set a long random JWT_SECRET
docker compose up --build   # API: http://localhost:8000/docs
```

## Test (no Docker needed)
```bash
cd backend && pip install -r requirements.txt && python -m pytest -q
```

## Try it
1. `POST /auth/register-organization` -> creates org, default roles, OWNER user, returns tokens
2. Authorize in /docs with the access token
3. `POST /users` to add a SITE_ENGINEER, `GET /users`, `GET /audit-logs`

## Phase 2 - Projects, BOQ, Budget
Clients, projects (status workflow), sites, contracts, cost codes, configurable units/conversions,
BOQ with exact Decimal rate analysis, budgets built from an approved BOQ.
- Money is Decimal end-to-end; no LLM/float arithmetic.
- Budget shows original / revised / committed / actual / paid separately (committed/actual/paid stay 0 until procurement, inventory and finance phases feed them).
- Budget increases/revisions need `budgets.approve` (OWNER by default) and a reason; every revision is stored and audited.
- CLIENT and SUBCONTRACTOR roles have no project access yet (project-level membership comes later).
- Flow: `POST /projects` -> `POST /cost-codes` -> `POST /boqs` + `/boqs/{id}/items` -> `POST /boqs/{id}/approve` -> `POST /budgets/from-boq` -> `POST /budgets/{id}/approve` -> `GET /projects/{id}/budget`

## Phase 3A - Procurement & Inventory
Suppliers (approval-gated), requisitions with live stock + BOQ checks, quotes and comparison (with price-anomaly flag),
purchase orders with approval limits, goods receipts, append-only stock ledger (weighted-average cost), site issues/returns,
transfers, adjustments, consumption per project.
- **Budget links:** approving a PO adds to *committed* (blocked if it would exceed the budget line); a GRN adds accepted qty x rate to *actual*. Issues to site do not touch actual again (cost was recognised at receipt).
- **Approval limits:** `Role.approval_limit` is enforced on PO approval (PM default 50,000 PKR; OWNER unlimited). Configurable per organization.
- **Stock rules:** no negative stock; rejected goods are not stocked; requisition buys only `requested - on hand - on order`; if stock is sufficient, submit is refused.
- **Not yet:** supplier invoices, three-way match and payments (Phase 4 finance); labour, attendance, daily reports (Phase 3B).
- Flow: `/warehouses` + `/inventory/items` -> `/requisitions` (submit/approve) -> `/requisitions/{id}/quotes` -> `/purchase-orders/from-quote` -> submit/approve -> `/goods-receipts` -> `/inventory/issues`

## Phase 3B - Labour, Attendance, Daily Site Reports
- **Workers** with daily and overtime rates (overtime rate is explicit, no assumed multiplier). Wage data is only visible with `labour.read`; foremen can pick workers but never see pay.
- **Attendance sheets** (DRAFT -> SUBMITTED -> APPROVED): PRESENT / HALF_DAY / ABSENT / LEAVE + overtime hours. Cost = days x daily rate + OT hours x OT rate, rounded half-up; rates are snapshotted per entry so later wage changes never rewrite history. A worker cannot be booked for more than one day in total across projects on the same date.
- **Approval posts labour cost to the budget as committed and actual together** (labour has no PO stage; needs a LABOUR cost code and an approved budget line, otherwise approval is refused and nothing is posted).
- **Daily site reports**: one per project per day. Workforce comes from submitted attendance and material received/issued/returned from the stock ledger (business day = UTC+5, `TZ_OFFSET_HOURS`), so they cannot drift from the system of record. Quantity progress per BOQ item and overall (weighted by item amount, each item capped at 100%). PDF export, lock on submit, manager reopen with reason, missing-report finder.
- Flow: `/workers` -> `/attendance-sheets` (+submit/approve) -> `/daily-logs` (+submit) -> `/daily-logs/{id}/pdf`, `/projects/{id}/progress`, `/labour/cost-summary`
- **Not yet:** payroll (advances, deductions, net payable) and photos/videos (need document storage, Phase 6); project-level permissions.

## Phase 4A - Accounting core, supplier invoices, payments, expenses
- **Double-entry ledger** with a default chart of accounts per organisation (created on first use), project- and cost-code-coded journal lines, immutable entries (corrections by reversal), trial balance, account ledger with running balance.
- **Automatic postings:** GRN -> Dr project cost / Cr Goods Received Not Invoiced (at PO rate); approved attendance -> Dr Labour cost / Cr Wages Payable; matched supplier invoice -> Dr GRNI / Cr Accounts Payable; approved payment -> Dr AP / Cr Cash-Bank; approved expense -> Dr project cost / Cr Cash-Bank. Control accounts (AP, AR, GRNI, wages, retention) cannot be posted manually.
- **Three-way match** (PO x accepted GRN quantity x invoice, cumulative across invoices): clean match posts to payables; otherwise an exception (`QTY_EXCEEDS_RECEIVED`, `RATE_MISMATCH`, `TOTAL_MISMATCH`) is raised and nothing is posted or payable. Only rate differences can be accepted (owner, `finance.approve`); the variance is posted to project cost and the budget. Quantity/total problems must be corrected or rejected. Duplicate supplier invoice numbers are refused.
- **Payments:** created by finance, approved by a different person with `finance.approve` within their approval limit; outstanding amounts are reserved by pending payments so an invoice cannot be double-paid. Approval fills the budget's **paid** column (pro-rata by cost code).
- **Expenses:** site/petty-cash style costs need an approved budget line, approval within limit, then post committed + actual + paid together.
- **Reports:** trial balance, account ledger, payables aging (sub-ledger reconciles to the AP control account).
- **Not yet (4B):** client billing/retention/receipts, receivables aging, project P&L, cash flow. **Not in scope yet:** tax (GST/withholding) on invoices, payroll settlement of wages payable, subcontractor bills, bank reconciliation.

## Phase 4B - Client billing, receipts, receivables, P&L, cash
- **Bills** (DRAFT -> PENDING_APPROVAL -> APPROVED/certified, then PARTIALLY_PAID/PAID): *running* bills certify cumulative quantities against approved-BOQ items at contract rates (default = BOQ unit rate marked up by the BOQ's own selling/direct ratio); *milestone* bills certify fixed amounts. Retention % is snapshotted from the project contract; deductions (tax withheld as stated by the client, penalty, advance recovery, other) are explicit lines. Net = gross - retention - deductions.
- **Controls:** only the owner (`billing.approve`) certifies; previous quantities are re-checked at submit/approve (stale drafts are refused); cumulative quantity cannot exceed the BOQ without an approved **variation**; total billing cannot exceed contract value + approved variations; advance recovery cannot exceed the advance received.
- **Journal on certification:** Dr Receivable (net) + Dr Retention Receivable + Dr Tax Withheld Recoverable + Dr Customer Advances (recovery) + Dr Client Deductions (contra-revenue) / Cr Contract Revenue (project-coded). Payment certificate PDF per certified bill.
- **Receipts** (PAYMENT against bills, ADVANCE, RETENTION_RELEASE) are created by finance and approved by a different person with `finance.approve`; pending receipts reserve the outstanding amount.
- **Reports:** receivables aging (reconciles to the AR control account), project billing summary (contract, variations, billed, retention held, receivable, advance, physical progress), **project and company P&L** straight from the journal (optional overhead allocation by net-revenue share, planned-vs-budget block), **cash flow** (by source and month, opening/closing per cash account), **cash forecast** (receivables and payables by due date; contractual, not a prediction).
- **Not yet:** voiding an approved receipt, tax computation (GST/WHT amounts are entered as stated), subcontractor bills and retention payable, bank reconciliation.

## Notes
- Every tenant-owned query must start from `deps.org_scoped(Model, user)`.
- Rate limiting and MFA are not implemented yet (schema is MFA-ready).
- Next: Phase 2 (projects, BOQ, budget). Add new tables via `alembic revision --autogenerate`.
