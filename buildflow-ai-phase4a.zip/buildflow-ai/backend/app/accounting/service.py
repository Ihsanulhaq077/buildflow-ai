"""Double-entry posting. Deterministic Decimal maths only; the LLM never touches the ledger."""
import uuid
from datetime import date
from decimal import Decimal

from fastapi import HTTPException
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.accounting.models import Account, AccountType, JournalEntry, JournalLine
from app.boq.models import CostCategory
from app.inventory.service import next_number

# code -> (name, type, is_cash)
SYSTEM_ACCOUNTS: dict[str, tuple[str, AccountType, bool]] = {
    "1000": ("Cash in Hand", AccountType.ASSET, True),
    "1010": ("Bank", AccountType.ASSET, True),
    "1100": ("Accounts Receivable", AccountType.ASSET, False),
    "1300": ("Retention Receivable", AccountType.ASSET, False),
    "2000": ("Accounts Payable", AccountType.LIABILITY, False),
    "2100": ("Goods Received Not Invoiced", AccountType.LIABILITY, False),
    "2200": ("Wages Payable", AccountType.LIABILITY, False),
    "3000": ("Owner's Capital", AccountType.EQUITY, False),
    "4000": ("Contract Revenue", AccountType.INCOME, False),
    "5000": ("Material Cost", AccountType.EXPENSE, False),
    "5100": ("Labour Cost", AccountType.EXPENSE, False),
    "5200": ("Equipment Cost", AccountType.EXPENSE, False),
    "5300": ("Subcontract Cost", AccountType.EXPENSE, False),
    "5400": ("Transport Cost", AccountType.EXPENSE, False),
    "5500": ("Site Expenses", AccountType.EXPENSE, False),
    "5900": ("Other Direct Cost", AccountType.EXPENSE, False),
    "6000": ("Office Overhead", AccountType.EXPENSE, False),
}
CATEGORY_ACCOUNT = {CostCategory.MATERIAL: "5000", CostCategory.LABOUR: "5100", CostCategory.EQUIPMENT: "5200",
                    CostCategory.SUBCONTRACT: "5300", CostCategory.TRANSPORT: "5400",
                    CostCategory.SITE_EXPENSE: "5500", CostCategory.OVERHEAD: "6000",
                    CostCategory.CONTINGENCY: "5900", CostCategory.OTHER: "5900"}
CENT = Decimal("0.01")


def ensure_accounts(db: Session, org_id) -> dict[str, Account]:
    """Idempotently create the default chart of accounts (works for organisations that pre-date accounting)."""
    have = {a.code: a for a in db.scalars(select(Account).where(Account.organization_id == org_id))}
    for code, (name, typ, cash) in SYSTEM_ACCOUNTS.items():
        if code not in have:
            have[code] = Account(organization_id=org_id, code=code, name=name, type=typ, is_cash=cash, is_system=True)
            db.add(have[code])
    db.flush()
    return have


def cost_account(db: Session, org_id, category: CostCategory) -> Account:
    return ensure_accounts(db, org_id)[CATEGORY_ACCOUNT[category]]


def q2(x: Decimal) -> Decimal:
    return x.quantize(CENT)


def post_entry(db: Session, *, org_id, user_id, entry_date: date, description: str, lines: list[dict],
               source_type: str = "MANUAL", source_id="", reversal_of=None) -> JournalEntry:
    """lines: dicts with account_id and debit|credit (+ optional project_id, cost_code_id, supplier_id, client_id, memo)."""
    debit = sum((Decimal(l.get("debit", 0)) for l in lines), Decimal("0"))
    credit = sum((Decimal(l.get("credit", 0)) for l in lines), Decimal("0"))
    if not lines or debit != credit or debit <= 0:
        raise HTTPException(422, f"Journal entry must balance and be non-zero (debit {debit}, credit {credit})")
    for l in lines:
        d, c = Decimal(l.get("debit", 0)), Decimal(l.get("credit", 0))
        if d < 0 or c < 0 or (d > 0) == (c > 0):
            raise HTTPException(422, "Each journal line must have exactly one positive side")
    entry = JournalEntry(organization_id=org_id, number=next_number(db, JournalEntry, org_id, "JV"),
                         entry_date=entry_date, description=description[:500], source_type=source_type,
                         source_id=str(source_id), reversal_of=reversal_of, posted_by=user_id)
    db.add(entry)
    db.flush()
    for l in lines:
        db.add(JournalLine(organization_id=org_id, entry_id=entry.id, account_id=l["account_id"],
                           debit=Decimal(l.get("debit", 0)), credit=Decimal(l.get("credit", 0)),
                           project_id=l.get("project_id"), cost_code_id=l.get("cost_code_id"),
                           supplier_id=l.get("supplier_id"), client_id=l.get("client_id"), memo=l.get("memo", "")))
    return entry


def balance(db: Session, org_id, account_id, as_of: date | None = None, **filters) -> Decimal:
    """Signed balance in the account's normal direction."""
    acct = db.get(Account, account_id)
    q = (select(func.coalesce(func.sum(JournalLine.debit), 0), func.coalesce(func.sum(JournalLine.credit), 0))
         .join(JournalEntry, JournalEntry.id == JournalLine.entry_id)
         .where(JournalLine.organization_id == org_id, JournalLine.account_id == account_id))
    if as_of:
        q = q.where(JournalEntry.entry_date <= as_of)
    for col, val in filters.items():
        q = q.where(getattr(JournalLine, col) == val)
    d, c = db.execute(q).one()
    d, c = Decimal(d), Decimal(c)
    return d - c if acct.type in {AccountType.ASSET, AccountType.EXPENSE} else c - d


def allocate_pro_rata(total: Decimal, weights: dict[uuid.UUID, Decimal]) -> dict[uuid.UUID, Decimal]:
    """Split `total` across keys in proportion to weights, to the cent; the last key absorbs rounding."""
    keys = sorted(weights, key=str)
    wsum = sum(weights.values(), Decimal("0"))
    out, used = {}, Decimal("0")
    for i, k in enumerate(keys):
        share = total - used if i == len(keys) - 1 else q2(total * weights[k] / wsum)
        out[k], used = share, used + share
    return out
