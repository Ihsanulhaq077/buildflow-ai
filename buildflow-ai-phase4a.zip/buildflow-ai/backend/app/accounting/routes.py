import uuid
from datetime import date
from decimal import Decimal

from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.accounting import service
from app.accounting.models import DEBIT_NORMAL, Account, JournalEntry, JournalLine
from app.accounting.schemas import AccountIn, AccountOut, JLineOut, JournalIn, JournalOut, ReverseIn
from app.audit import log_action
from app.boq.models import CostCode
from app.db import get_db
from app.deps import get_owned, org_scoped, require_permission
from app.models import User
from app.projects.models import Project

router = APIRouter(tags=["accounting"])
READ = require_permission("finance.read")
MANAGE = require_permission("finance.manage")
APPROVE = require_permission("finance.approve")
# Controlled by sub-ledgers (invoices, payments, receipts, GRN, labour): no manual postings.
CONTROL_CODES = {"1100", "1300", "2000", "2100", "2200"}


@router.get("/accounts", response_model=list[AccountOut])
def list_accounts(user: User = Depends(READ), db: Session = Depends(get_db)):
    service.ensure_accounts(db, user.organization_id)
    db.commit()
    return db.scalars(org_scoped(Account, user).order_by(Account.code)).all()


@router.post("/accounts", response_model=AccountOut, status_code=201)
def create_account(body: AccountIn, request: Request, user: User = Depends(MANAGE), db: Session = Depends(get_db)):
    service.ensure_accounts(db, user.organization_id)
    if db.scalar(org_scoped(Account, user).where(Account.code == body.code)):
        raise HTTPException(409, "Account code already exists")
    a = Account(organization_id=user.organization_id, **body.model_dump())
    db.add(a)
    db.commit()
    log_action(db, action="account.create", org_id=user.organization_id, user_id=user.id, entity="account",
               entity_id=a.id, request=request)
    return a


def _entry_out(db, e: JournalEntry) -> JournalOut:
    lines = db.scalars(select(JournalLine).where(JournalLine.entry_id == e.id).order_by(JournalLine.created_at))
    return JournalOut(id=e.id, number=e.number, entry_date=e.entry_date, description=e.description,
                      source_type=e.source_type, source_id=e.source_id, reversal_of=e.reversal_of,
                      lines=[JLineOut.model_validate(l) for l in lines])


@router.post("/journal-entries", response_model=JournalOut, status_code=201)
def manual_entry(body: JournalIn, request: Request, user: User = Depends(MANAGE), db: Session = Depends(get_db)):
    accounts = service.ensure_accounts(db, user.organization_id)
    control_ids = {accounts[c].id for c in CONTROL_CODES}
    lines = []
    for l in body.lines:
        a = get_owned(db, Account, l.account_id, user, code=422)
        if a.id in control_ids:
            raise HTTPException(422, f"Account {a.code} {a.name} is a control account; it is posted by invoices, payments and receipts only")
        if l.project_id:
            get_owned(db, Project, l.project_id, user, code=422)
        if l.cost_code_id:
            get_owned(db, CostCode, l.cost_code_id, user, code=422)
        lines.append(l.model_dump())
    try:
        e = service.post_entry(db, org_id=user.organization_id, user_id=user.id, entry_date=body.entry_date,
                               description=body.description, lines=lines)
        db.commit()
    except HTTPException:
        db.rollback()
        raise
    log_action(db, action="journal.create", org_id=user.organization_id, user_id=user.id, entity="journal_entry",
               entity_id=e.id, request=request, detail={"number": e.number})
    return _entry_out(db, e)


@router.post("/journal-entries/{entry_id}/reverse", response_model=JournalOut, status_code=201)
def reverse_entry(entry_id: uuid.UUID, body: ReverseIn, request: Request, user: User = Depends(APPROVE),
                  db: Session = Depends(get_db)):
    e = get_owned(db, JournalEntry, entry_id, user)
    if e.source_type != "MANUAL" or e.reversal_of:
        raise HTTPException(409, "Only manual entries can be reversed; reverse system postings through their own document")
    if db.scalar(org_scoped(JournalEntry, user).where(JournalEntry.reversal_of == e.id)):
        raise HTTPException(409, "Entry is already reversed")
    lines = [{"account_id": l.account_id, "debit": l.credit, "credit": l.debit, "project_id": l.project_id,
              "cost_code_id": l.cost_code_id, "memo": f"Reversal: {body.reason}"[:300]}
             for l in db.scalars(select(JournalLine).where(JournalLine.entry_id == e.id))]
    r = service.post_entry(db, org_id=user.organization_id, user_id=user.id, entry_date=e.entry_date,
                           description=f"Reversal of {e.number}: {body.reason}", lines=lines, source_type="MANUAL",
                           reversal_of=e.id)
    db.commit()
    log_action(db, action="journal.reverse", org_id=user.organization_id, user_id=user.id, entity="journal_entry",
               entity_id=r.id, request=request, detail={"reverses": e.number, "reason": body.reason})
    return _entry_out(db, r)


@router.get("/journal-entries", response_model=list[JournalOut])
def list_entries(source_type: str | None = None, date_from: date | None = None, date_to: date | None = None,
                 limit: int = 100, user: User = Depends(READ), db: Session = Depends(get_db)):
    q = org_scoped(JournalEntry, user)
    if source_type:
        q = q.where(JournalEntry.source_type == source_type)
    if date_from:
        q = q.where(JournalEntry.entry_date >= date_from)
    if date_to:
        q = q.where(JournalEntry.entry_date <= date_to)
    return [_entry_out(db, e) for e in db.scalars(q.order_by(JournalEntry.created_at.desc()).limit(min(limit, 500)))]


@router.get("/journal-entries/{entry_id}", response_model=JournalOut)
def get_entry(entry_id: uuid.UUID, user: User = Depends(READ), db: Session = Depends(get_db)):
    return _entry_out(db, get_owned(db, JournalEntry, entry_id, user))


@router.get("/accounts/{account_id}/ledger")
def ledger(account_id: uuid.UUID, date_from: date | None = None, date_to: date | None = None,
           project_id: uuid.UUID | None = None, user: User = Depends(READ), db: Session = Depends(get_db)):
    acct = get_owned(db, Account, account_id, user)
    sign = 1 if acct.type in DEBIT_NORMAL else -1
    base = (select(JournalLine, JournalEntry).join(JournalEntry, JournalEntry.id == JournalLine.entry_id)
            .where(JournalLine.organization_id == user.organization_id, JournalLine.account_id == acct.id))
    if project_id:
        base = base.where(JournalLine.project_id == project_id)
    opening = Decimal("0")
    if date_from:
        d, c = db.execute(select(func.coalesce(func.sum(JournalLine.debit), 0), func.coalesce(func.sum(JournalLine.credit), 0))
                          .join(JournalEntry, JournalEntry.id == JournalLine.entry_id)
                          .where(JournalLine.organization_id == user.organization_id, JournalLine.account_id == acct.id,
                                 JournalEntry.entry_date < date_from)).one()
        opening = sign * (Decimal(d) - Decimal(c))
        base = base.where(JournalEntry.entry_date >= date_from)
    if date_to:
        base = base.where(JournalEntry.entry_date <= date_to)
    run, rows = opening, []
    for l, e in db.execute(base.order_by(JournalEntry.entry_date, JournalEntry.created_at, JournalLine.created_at)):
        run += sign * (l.debit - l.credit)
        rows.append({"date": str(e.entry_date), "entry": e.number, "description": e.description, "memo": l.memo,
                     "debit": str(l.debit), "credit": str(l.credit), "balance": str(run),
                     "project_id": str(l.project_id) if l.project_id else None})
    return {"account": {"id": str(acct.id), "code": acct.code, "name": acct.name, "type": acct.type.value},
            "opening_balance": str(opening), "closing_balance": str(run), "rows": rows}


@router.get("/trial-balance")
def trial_balance(as_of: date | None = None, user: User = Depends(READ), db: Session = Depends(get_db)):
    service.ensure_accounts(db, user.organization_id)
    db.commit()
    q = (select(Account, func.coalesce(func.sum(JournalLine.debit), 0), func.coalesce(func.sum(JournalLine.credit), 0))
         .outerjoin(JournalLine, JournalLine.account_id == Account.id)
         .outerjoin(JournalEntry, JournalEntry.id == JournalLine.entry_id)
         .where(Account.organization_id == user.organization_id))
    if as_of:
        q = q.where((JournalEntry.entry_date <= as_of) | (JournalEntry.id.is_(None)))
    rows, td, tc = [], Decimal("0"), Decimal("0")
    for a, d, c in db.execute(q.group_by(Account.id).order_by(Account.code)):
        d, c = Decimal(d), Decimal(c)
        if d == 0 and c == 0:
            continue
        net = d - c
        rows.append({"code": a.code, "name": a.name, "type": a.type.value,
                     "debit": str(net if net > 0 else Decimal("0")), "credit": str(-net if net < 0 else Decimal("0"))})
        td += net if net > 0 else 0
        tc += -net if net < 0 else 0
    return {"as_of": str(as_of) if as_of else None, "rows": rows, "total_debit": str(td), "total_credit": str(tc),
            "balanced": td == tc}
